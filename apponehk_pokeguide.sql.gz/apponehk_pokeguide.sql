-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_pokeguide
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pokeguide_page`
--

DROP TABLE IF EXISTS `pokeguide_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pokeguide_page` (
  `order` int(255) NOT NULL AUTO_INCREMENT,
  `catalog` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `url` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`order`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pokeguide_page`
--

LOCK TABLES `pokeguide_page` WRITE;
/*!40000 ALTER TABLE `pokeguide_page` DISABLE KEYS */;
INSERT INTO `pokeguide_page` (`order`, `catalog`, `title`, `image`, `url`) VALUES (1,'item','13項道具功能話你知','http://www.gamepur.com/files/images/2014/pokemon-go-items.jpeg','http://appone.hk/developing/pokeguide/html/item/item-list.html'),(7,'level','LV40升級獎勵原來是...','http://hk.ulifestyle.com.hk/cms/images/topic/w600/201607/20160729191539_5_levelup-189155.png','http://appone.hk/developing/pokeguide/html/level/level-40lv.html'),(20,'tips','開局比卡超起手秘技公開！','http://www.thecountrycaller.com/public/images/uploads/1467920892-2820.jpg','https://youtu.be/5uyMPVdlP9E'),(5,'tips','萬能小精靈計算器','http://pokemon-world.com/wp-content/uploads/2016/07/pokemon-go-evolution-cp-calculator.jpg','https://translate.google.com.hk/translate?hl=zh-TW&sl=en&tl=zh-TW&u=https%3A%2F%2Fpokeassistant.com%2Fmain%2Fivcalculator'),(6,'tips','開放地區即時通知系統','http://appone.hk/developing/pokeguide/image/new1.png','https://www.ispokemongoavailableyet.com/'),(8,'news','James Bond 被揭是秘密特工！？','https://i1.wp.com/cn.hypebeast.com/files/2016/08/james-bond-secret-pokemon-go-agent1.jpg','http://appone.hk/developing/pokeguide/html/news/news-james.html'),(10,'news','首次重大更新引發玩家不滿','https://i1.wp.com/cn.hypebeast.com/files/2016/08/pokemon-go-update-1.jpg','http://appone.hk/developing/pokeguide/html/news/news-update.html'),(9,'news','下載量正式突破一億!!','https://i1.wp.com/cn.hypebeast.com/files/2016/08/pokemon-go-100-million-downloads-1.jpg','http://appone.hk/developing/pokeguide/html/news/news-hundredmillion.html'),(11,'news','玩家走到羅茲威爾 Area 51 捉超夢夢','https://i1.wp.com/cn.hypebeast.com/files/2016/08/pokemon-go-area-51.jpg','http://appone.hk/developing/pokeguide/html/news/news-law.html'),(12,'news','Paweł Kuczyński 新作諷刺《Pokémon Go》玩家','https://i1.wp.com/cn.hypebeast.com/files/2016/07/pokemon-go-artwork-by-pawel-kuczynski-t.jpg','http://appone.hk/developing/pokeguide/html/news/news-shame.html'),(13,'news','第1位集齊 145 隻精靈的玩家','https://i1.wp.com/cn.hypebeast.com/files/2016/07/robert-wallace-catches-all-145-pokemon-go-11.jpg','http://appone.hk/developing/pokeguide/html/news/news-topone.html'),(14,'tips','6大訓練員必備電話充電器','http://cn.hypebeast.com/files/2016/07/phone-charger-for-pokemon-go-07.jpg','http://appone.hk/developing/pokeguide/html/tips/tips-gear.html'),(15,'tips','大師之路！8 招必讀進階秘技！','https://i1.wp.com/cn.hypebeast.com/files/2016/07/everything-a-pokemon-master-should-know-1A.jpg','http://appone.hk/developing/pokeguide/html/tips/tips-master8.html'),(16,'tutorial','精讀！初心玩家必讀 10 個秘技！','https://i1.wp.com/cn.hypebeast.com/files/2016/07/pokemon-go-guide-secret-tips-11.jpg','http://appone.hk/developing/pokeguide/html/tutorial/tut-beginner.html'),(17,'news','震驚十三億人的消息','https://media.hiramlab.com/kocpc/2016/07/1468261403-1e22a49d9c93f466f16dfe4ce93d9840.jpg','http://appone.hk/developing/pokeguide/html/news/news-shocking.html'),(18,'news','日本傳出首例遭官方封鎖案例','https://i.kinja-img.com/gawker-media/image/upload/s--fIeg_ksc--/c_scale,fl_progressive,q_80,w_800/hr2klopgtgdvuu8pb5a6.jpg','http://appone.hk/developing/pokeguide/html/news/news-block.html'),(19,'tutorial','給新手玩家的重點技巧與建議','http://ytimg.googleusercontent.com/vi/j8alMzhWw20/mqdefault.jpg','http://appone.hk/developing/pokeguide/html/tutorial/tut-11tips.html');
/*!40000 ALTER TABLE `pokeguide_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_pokeguide'
--

--
-- Dumping routines for database 'apponehk_pokeguide'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:29
