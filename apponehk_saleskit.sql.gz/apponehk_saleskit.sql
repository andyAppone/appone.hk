-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_saleskit
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sk_categories`
--

DROP TABLE IF EXISTS `sk_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sk_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `parent_cat_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sk_categories`
--

LOCK TABLES `sk_categories` WRITE;
/*!40000 ALTER TABLE `sk_categories` DISABLE KEYS */;
INSERT INTO `sk_categories` (`id`, `name`, `parent_cat_id`, `created_at`, `updated_at`) VALUES (18,'設計, 攝影',0,'2016-07-12 02:49:18','2016-07-12 02:49:18'),(7,'藝術, 文化',0,'2016-07-12 02:48:20','2016-07-12 02:48:20'),(9,'商業服務',0,'2016-07-12 02:48:25','2016-07-12 02:48:25'),(10,'汽車, 摩托車',0,'2016-07-12 02:48:29','2016-07-12 02:48:29'),(11,'電腦, 互聯網',0,'2016-07-12 02:48:12','2016-07-12 02:48:12'),(12,'時尚, 美容',0,'2016-07-12 02:48:33','2016-07-12 02:48:33'),(13,'娛樂, 遊戲',0,'2016-07-12 02:48:37','2016-07-12 02:48:37'),(14,'食品, 餐廳',0,'2016-07-12 02:48:41','2016-07-12 02:48:41'),(15,'房地產',0,'2016-07-12 02:48:45','2016-07-12 02:48:45'),(16,'運動, 戶外, 旅遊',0,'2016-07-12 02:48:48','2016-07-12 02:48:48'),(17,'教育',0,'2016-07-12 02:48:51','2016-07-12 02:48:51');
/*!40000 ALTER TABLE `sk_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sk_products`
--

DROP TABLE IF EXISTS `sk_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sk_products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text NOT NULL,
  `link` text NOT NULL,
  `image` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `products_fk0` (`user_id`),
  CONSTRAINT `products_fk0` FOREIGN KEY (`user_id`) REFERENCES `sk_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sk_products`
--

LOCK TABLES `sk_products` WRITE;
/*!40000 ALTER TABLE `sk_products` DISABLE KEYS */;
INSERT INTO `sk_products` (`id`, `title`, `description`, `link`, `image`, `category_id`, `type_id`, `user_id`, `created_at`, `updated_at`) VALUES (16,'N/A','N/A','/public/assets/plugins/kcfinder/upload/images/Earth%20and%20Moon.jpg','#',18,9,5,'2016-07-13 06:26:02','2016-07-13 06:26:02');
/*!40000 ALTER TABLE `sk_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sk_site_types`
--

DROP TABLE IF EXISTS `sk_site_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sk_site_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sk_site_types`
--

LOCK TABLES `sk_site_types` WRITE;
/*!40000 ALTER TABLE `sk_site_types` DISABLE KEYS */;
INSERT INTO `sk_site_types` (`id`, `name`, `sort_order`, `created_at`, `updated_at`) VALUES (10,'購物網站',2,'2016-07-12 02:37:24','2016-07-12 02:37:24'),(9,'基本網站',1,'2016-07-12 02:37:13','2016-07-12 02:37:13');
/*!40000 ALTER TABLE `sk_site_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sk_users`
--

DROP TABLE IF EXISTS `sk_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sk_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1',
  `remember_token` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sk_users`
--

LOCK TABLES `sk_users` WRITE;
/*!40000 ALTER TABLE `sk_users` DISABLE KEYS */;
INSERT INTO `sk_users` (`id`, `username`, `password`, `name`, `email`, `created_at`, `updated_at`, `active`, `remember_token`) VALUES (1,'admin','$2y$10$iG.E/BylL2EPZ6l7yrc07umrSv/8S9eobfr.V4eLkiyPGcRxKVjnW','Siyana','siyana@appone.hk','2016-07-12 09:08:10','2016-07-12 09:08:10',1,'Za3d0KY17W0PRJVW52xiH5OvqzgVnV8zL2xhjA658esfyDv8T8VbZn6Oi1vE'),(5,'cyrus','$2y$10$iG.E/BylL2EPZ6l7yrc07umrSv/8S9eobfr.V4eLkiyPGcRxKVjnW','Cyrus','cyrus@appone.hk','2016-07-08 09:31:34','2016-07-08 09:31:34',1,'3nV8Ob509SfzkrHvOr8OJLUxZ2n3zRSO6lMrXXbAH1uLVCxrbCWTxmtnquvm'),(24,'billy','$2y$10$eyF8zzQYEZ4DoQbVese.we0s6QRsx/stIgD3AABJmnm1dMnTPiW.y','Billy','billy@appone.hk','2016-07-12 09:15:36','2016-07-12 09:15:36',1,''),(25,'simon','$2y$10$6LiPT9iwc6omDwnce0CCCeYdp6iX0t/4PqbES3pbWsYdlLlOAEUk6','Simon','simon@appone.hk','2016-08-05 09:52:00','2016-08-05 09:52:00',1,'');
/*!40000 ALTER TABLE `sk_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_saleskit'
--

--
-- Dumping routines for database 'apponehk_saleskit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:30
