-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_oni
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `FriendsList`
--

DROP TABLE IF EXISTS `FriendsList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FriendsList` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `user1` int(9) NOT NULL,
  `user2` int(9) NOT NULL,
  `invite_user` int(1) NOT NULL,
  `stateid` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FriendsList`
--

LOCK TABLES `FriendsList` WRITE;
/*!40000 ALTER TABLE `FriendsList` DISABLE KEYS */;
INSERT INTO `FriendsList` (`id`, `user1`, `user2`, `invite_user`, `stateid`) VALUES (12,100000006,100000008,1,0),(7,100000006,100000007,1,0),(9,100000008,100000007,1,1),(10,100000006,100000009,1,0);
/*!40000 ALTER TABLE `FriendsList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `lv` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=100000013 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` (`id`, `name`, `lv`) VALUES (100000008,'é›·ç¦ª',99),(100000006,'C4L',99),(100000007,'Cwing',99),(100000009,'AKB48',4),(100000010,'AKB48',4),(100000011,'AKB48',4),(100000012,'AKB48',4);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_account`
--

DROP TABLE IF EXISTS `tb_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(128) DEFAULT NULL,
  `socialid` varchar(100) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `cash` bigint(20) DEFAULT NULL,
  `storystate` smallint(6) DEFAULT NULL,
  `loginday` smallint(6) DEFAULT NULL,
  `eventscore` int(11) DEFAULT NULL,
  `friends` text,
  `uitem` text,
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  `canplay` tinyint(1) DEFAULT NULL,
  `friendpoint` smallint(6) DEFAULT NULL,
  `accexp` bigint(20) DEFAULT NULL,
  `hashkey` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_account`
--

LOCK TABLES `tb_account` WRITE;
/*!40000 ALTER TABLE `tb_account` DISABLE KEYS */;
INSERT INTO `tb_account` (`id`, `uid`, `socialid`, `name`, `cash`, `storystate`, `loginday`, `eventscore`, `friends`, `uitem`, `createtime`, `updatetime`, `canplay`, `friendpoint`, `accexp`, `hashkey`) VALUES (1,'929385jwsjfj22',NULL,'dummy1',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:40:37',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(2,'192jfjw92jd022',NULL,'dummy2',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:40:59',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(3,'58cb5ae9d89c4',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(4,'58cb5ae9d89c5',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(5,'58cb5ae9d89c6',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(6,'58cb5ae9d89c7',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(7,'58cb5ae9d89c8',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(8,'58cb5ae9d89c9',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(9,'58cb5ae9d89d4',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(10,'58cb5ae9d89d5',NULL,'dummy10',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:40:37',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(11,'58cb5ae9d89d6',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(12,'58cb5ae9d89d7',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(13,'58cb5ae9d89d8',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(14,'58cb5ae9d89d9',NULL,'dummy20',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:40:37',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(15,'58cb5ae9d89e1',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(16,'58cb5ae9d89e2',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(17,'58cb5ae9d89e3',NULL,'dummy3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 11:41:29',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(19,'58cb7bcac285f',NULL,'8898989',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 14:01:46',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(20,'58cb7c3e82789',NULL,'rtgtrg',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 14:03:42',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(21,'58cb7c78c8eff',NULL,'3e3e3',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 14:04:40',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(23,'58cb7da241305',NULL,'5554',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 14:09:38',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(24,'58cb7e9d51fd2',NULL,'hi',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 14:13:49',NULL,1,0,15,'443f020e9fc1234899f598a738ee1c5ae7f3a51a'),(25,'58cb8ac9a0f39','0','hi',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-17 15:05:45',NULL,1,0,15,'9f07efb945b3d675f1bc883ec3b8723529967315'),(38,'58d0d4c03ee09','10205605895667042','pk',0,0,0,0,'a:0:{}','a:4:{s:6:\"Weapon\";a:1:{i:0;a:3:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:6:\"Attack\";i:0;}}s:7:\"Defence\";a:1:{i:0;a:4:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;s:2:\"HP\";i:0;s:5:\"Armor\";i:0;}}s:4:\"Mark\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Level\";i:0;}}s:6:\"Source\";a:1:{i:0;a:2:{s:2:\"ID\";i:1;s:5:\"Value\";i:0;}}}','2017-03-21 15:22:40',NULL,1,0,15,'d7ca2a8c4d39fb4536968c78c0f16a4a90fb8ec2');
/*!40000 ALTER TABLE `tb_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_auction`
--

DROP TABLE IF EXISTS `tb_auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_auction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `acc_id` int(11) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `timelimit` smallint(2) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `selltype` tinyint(1) DEFAULT NULL,
  `lowprice` int(11) DEFAULT NULL,
  `sellprice` int(11) DEFAULT NULL,
  `perone` int(11) DEFAULT NULL,
  `currentprice` int(11) DEFAULT NULL,
  `bidid` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_auction`
--

LOCK TABLES `tb_auction` WRITE;
/*!40000 ALTER TABLE `tb_auction` DISABLE KEYS */;
INSERT INTO `tb_auction` (`id`, `pid`, `acc_id`, `type`, `type_id`, `timelimit`, `qty`, `selltype`, `lowprice`, `sellprice`, `perone`, `currentprice`, `bidid`, `createtime`, `status`) VALUES (1,1,7777,'Weapon',1,12,1,0,100,100000,100,0,0,'2017-01-25 09:48:07',4),(2,1,7777,'Weapon',1,12,1,0,100,100000,100,666,77,'2017-01-25 09:48:29',5),(3,1,7777,'Weapon',1,12,1,0,100,100000,100,999,88,'2017-01-25 09:48:48',5),(4,4,99887,'Weapon',1,23,1,0,100,100000,100,0,0,'2017-01-25 14:37:29',4),(5,5,99887,'Weapon',1,23,1,0,100,100000,100,0,0,'2017-01-25 14:37:31',4),(6,6,99887,'Weapon',1,23,1,0,100,100000,100,0,0,'2017-01-25 14:37:32',4),(7,7,99887,'Weapon',1,24,1,1,100,100000,100,0,0,'2017-01-25 14:40:40',4),(8,7,99887,'Weapon',1,24,1,1,100,100000,100,1000,99887,'2017-01-25 16:12:31',5),(9,7,99887,'Weapon',1,24,1,1,100,100000,100,1300,99887,'2017-01-25 16:14:34',5),(10,7,99887,'Weapon',1,24,1,1,100,100000,100,1600,99887,'2017-01-25 16:14:42',3),(11,6,99887,'Weapon',1,23,1,0,100,100000,100,400,99887,'2017-01-25 16:18:08',3),(12,5,99887,'Weapon',1,23,1,0,100,100000,100,300,99887,'2017-01-25 16:18:08',5),(13,4,99887,'Weapon',1,23,1,0,100,100000,100,600,99887,'2017-01-25 14:37:29',5),(14,4,99887,'Weapon',1,23,1,0,100,100000,100,2500,99887,'2017-01-25 14:37:29',3),(15,5,99887,'Weapon',1,23,1,0,100,100000,100,600,99887,'2017-01-25 14:37:31',5),(16,5,99887,'Weapon',1,23,1,0,100,100000,100,100000,99887,'2017-01-25 14:37:31',3),(17,17,5123,'Weapon',1,12,1,0,100,100000,100,0,0,'2017-01-27 13:36:53',2),(18,18,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 13:47:19',3),(19,19,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 14:25:50',4),(21,21,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 14:34:20',3),(22,19,99887,'Weapon',1,1,1,0,100,100000,100,300,99887,'2017-01-27 14:25:50',3),(23,23,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 14:46:11',4),(24,23,99887,'Weapon',1,1,1,0,100,100000,100,4700,99887,'2017-01-27 14:46:11',5),(25,23,99887,'Weapon',1,1,1,0,100,100000,100,5500,99887,'2017-01-27 14:46:11',5),(26,23,99887,'Weapon',1,1,1,0,100,100000,100,100000,99887,'2017-01-27 14:46:11',3),(27,27,99887,'Weapon',1,12,1,0,100,100000,100,0,0,'2017-01-27 15:47:04',3),(28,28,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:47:14',3),(29,29,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:47:47',3),(30,30,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:48:20',3),(31,31,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:49:12',3),(32,32,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:49:39',3),(33,33,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:49:59',3),(34,34,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:50:24',3),(35,35,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:50:57',3),(36,36,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:51:06',3),(37,37,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:51:46',3),(38,38,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:51:51',3),(39,39,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:53:45',3),(40,40,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:54:32',3),(41,41,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:54:41',3),(42,42,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 15:56:43',3),(43,43,99887,'Weapon',1,1,1,1,100,100000,100,0,0,'2017-01-27 15:59:14',3),(44,44,99887,'Weapon',1,1,1,1,100,100000,100,0,0,'2017-01-27 16:00:10',3),(45,45,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 16:00:16',3),(46,46,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 16:01:08',3),(47,47,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 16:01:44',3),(48,48,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-01-27 16:02:37',3),(49,49,99887,'Weapon',1,1,1,1,100,100000,100,0,0,'2017-01-27 16:02:48',3),(50,50,99887,'Weapon',1,1,1,1,100,100000,100,0,0,'2017-02-01 09:25:24',4),(51,50,99887,'Weapon',1,1,1,1,100,100000,100,500,99887,'2017-02-01 09:25:24',5),(52,50,99887,'Weapon',1,1,1,1,100,100000,100,600,99887,'2017-02-01 09:25:24',5),(53,50,99887,'Weapon',1,1,1,1,100,100000,100,700,99887,'2017-02-01 09:25:24',5),(54,50,99887,'Weapon',1,1,1,1,100,100000,100,800,99887,'2017-02-01 09:25:24',5),(55,50,99887,'Weapon',1,1,1,1,100,100000,100,900,99887,'2017-02-01 09:25:24',5),(56,50,99887,'Weapon',1,1,1,1,100,100000,100,1000,99887,'2017-02-01 09:25:24',5),(57,50,99887,'Weapon',1,1,1,1,100,100000,100,1100,99887,'2017-02-01 09:25:24',5),(58,50,99887,'Weapon',1,1,1,1,100,100000,100,1200,99887,'2017-02-01 09:25:24',3),(59,59,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-02-08 11:29:08',3),(60,60,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-02-08 14:48:20',3),(61,61,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-02-08 14:48:46',4),(62,61,99887,'Weapon',1,1,1,0,100,100000,100,200,99887,'2017-02-08 14:48:46',5),(63,63,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-02-08 15:00:16',3),(64,64,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-02-08 15:02:14',3),(65,65,99887,'Weapon',1,6,1,1,100,100000,100,0,0,'2017-03-17 14:20:08',4),(66,65,99887,'Weapon',1,6,1,1,100,100000,100,400,99887,'2017-03-17 14:20:08',5),(67,65,99887,'Weapon',1,6,1,1,100,100000,100,100000,9987,'2017-03-17 14:20:08',3),(68,68,99887,'Weapon',1,1,1,0,100,100000,100,0,0,'2017-04-20 11:11:52',0);
/*!40000 ALTER TABLE `tb_auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_cmsuser`
--

DROP TABLE IF EXISTS `tb_cmsuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_cmsuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(45) DEFAULT NULL,
  `hashpass` varchar(512) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `firstname` varchar(64) DEFAULT NULL,
  `lastname` varchar(64) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cmsuser`
--

LOCK TABLES `tb_cmsuser` WRITE;
/*!40000 ALTER TABLE `tb_cmsuser` DISABLE KEYS */;
INSERT INTO `tb_cmsuser` (`id`, `login`, `hashpass`, `email`, `firstname`, `lastname`, `active`, `createdate`, `updatedate`) VALUES (8,'testing02','7c4a8d09ca3762af61e59520943dc26494f8941b','ray.lam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(9,'testing01','7c4a8d09ca3762af61e59520943dc26494f8941b','ray.lam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(10,'testing03','7c4a8d09ca3762af61e59520943dc26494f8941b','ray.lam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(11,'testing04','7c4a8d09ca3762af61e59520943dc26494f8941b','ray.lam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(12,'testing05','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(13,'testing06','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(14,'testing07','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(15,'testing08','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(16,'testing09','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(17,'testing10','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(18,'testing','7c4a8d09ca3762af61e59520943dc26494f8941b','raylam@appone.hk','Dummy1','Dummy2',1,'2015-08-19 18:19:00','2015-08-19 18:20:00');
/*!40000 ALTER TABLE `tb_cmsuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_factor`
--

DROP TABLE IF EXISTS `tb_factor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_factor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `val` smallint(6) unsigned NOT NULL,
  `is_sign` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_factor`
--

LOCK TABLES `tb_factor` WRITE;
/*!40000 ALTER TABLE `tb_factor` DISABLE KEYS */;
INSERT INTO `tb_factor` (`id`, `name`, `val`, `is_sign`) VALUES (1,'整體意志力',10,1),(2,'整體控制力',10,0),(3,'整體反應力',0,1),(4,'整體潛在力',0,0),(5,'整體集中力',0,0);
/*!40000 ALTER TABLE `tb_factor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_initval`
--

DROP TABLE IF EXISTS `tb_initval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_initval` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `val` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_initval`
--

LOCK TABLES `tb_initval` WRITE;
/*!40000 ALTER TABLE `tb_initval` DISABLE KEYS */;
INSERT INTO `tb_initval` (`id`, `name`, `val`) VALUES (1,'FirePropertyProficiencyLevel',1),(2,'WaterPropertyProficiencyLevel',1),(3,'WindPropertyProficiencyLevel',1),(4,'EarthPropertyProficiencyLevel',1),(5,'MetalPropertyProficiencyLevel',1),(6,'symbolstoragesell',30),(7,'equipstoragesell',20),(8,'sourcestoragesell',100),(9,'charafield',3),(10,'diamond',0),(11,'friendlimit',10);
/*!40000 ALTER TABLE `tb_initval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item`
--

DROP TABLE IF EXISTS `tb_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `description` text,
  `imagesource` varchar(100) DEFAULT NULL,
  `stats` text,
  `slug` varchar(50) DEFAULT NULL,
  `stackable` tinyint(1) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `npcvalue` int(11) DEFAULT NULL,
  `stonevalue` int(11) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `val` smallint(6) DEFAULT NULL,
  `is_sign` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item`
--

LOCK TABLES `tb_item` WRITE;
/*!40000 ALTER TABLE `tb_item` DISABLE KEYS */;
INSERT INTO `tb_item` (`id`, `item_id`, `type_id`, `name`, `type`, `description`, `imagesource`, `stats`, `slug`, `stackable`, `value`, `npcvalue`, `stonevalue`, `createtime`, `val`, `is_sign`) VALUES (1,1,1,'無毀的湖光','blade','TheFirstWeapon','noneone','a:2:{s:5:\"power\";i:10;s:8:\"critical\";i:10;}','sword_01',1,5,100,5,'2017-03-30 18:12:41',0,0),(2,2,1,'噬血劍','blade','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','sword_02',1,6,100,5,'2017-03-30 18:12:41',0,0),(3,3,1,'干將莫邪','blade','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','sword_03',1,6,100,5,'2017-03-30 18:12:41',0,0),(4,4,1,'誓約勝利之劍','blade','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','sword_04',1,6,100,5,'2017-03-30 18:12:41',0,0),(5,5,1,'天叢雲劍','blade','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','sword_05',1,6,100,5,'2017-03-30 18:12:41',0,0),(6,6,1,'ストバーストストリーム','blade','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','sword_06',1,6,100,5,'2017-03-30 18:12:41',0,0),(7,7,1,'WeaponTwo','bow','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Bow1',1,6,100,5,'2017-03-30 18:12:41',0,0),(8,8,1,'WeaponTwo','bow','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Bow2',1,6,100,5,'2017-03-30 18:12:41',0,0),(9,9,1,'WeaponTwo','bow','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Bow3',1,6,100,5,'2017-03-30 18:12:41',0,0),(10,10,1,'WeaponTwo','bow','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Bow4',1,6,100,5,'2017-03-30 18:12:41',0,0),(11,11,1,'WeaponTwo','bow','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Bow5',1,6,100,5,'2017-03-30 18:12:41',0,0),(12,12,1,'巨魔之鎚','variant','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Hammer1',1,6,100,5,'2017-03-30 18:12:41',0,0),(13,13,1,'WeaponTwo','variant','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Hammer2',1,6,100,5,'2017-03-30 18:12:41',0,0),(14,14,1,'WeaponTwo','variant','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Hammer3',1,6,100,5,'2017-03-30 18:12:41',0,0),(15,15,1,'WeaponTwo','variant','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Hammer4',1,6,100,5,'2017-03-30 18:12:41',0,0),(16,16,1,'WeaponTwo','variant','TheSecondWeapon','nonetwo','a:2:{s:5:\"power\";i:20;s:8:\"critical\";i:20;}','Hammer5',1,6,100,5,'2017-03-30 18:12:41',0,0),(17,1,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(18,2,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(19,3,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(20,4,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(21,5,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(22,6,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(23,7,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(24,8,2,'defencesOne','clothes','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(25,9,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(26,10,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(27,11,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(28,12,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(29,13,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(30,14,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(31,15,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(32,16,2,'defencesOne','trousers','TheFirstDefences','nonethree','a:1:{s:5:\"armor\";i:10;}','Defences_01',1,7,100,5,'2017-03-30 18:12:41',0,0),(33,1,3,'markOne','mark','TheFirstMark','nonefour','a:1:{s:7:\"ability\";i:10;}','Mark_01',1,8,100,5,'2017-03-30 18:12:41',0,0),(34,1,4,'SourceOne','source','TheFirstSource','nonefive','a:0:{}','Source_01',1,9,100,5,'2017-03-30 18:12:41',0,0),(35,2,4,'SourceTwo','source','TheSecondSource','noneSix','a:0:{}','Source_02',1,10,100,5,'2017-03-30 18:12:41',0,0),(36,NULL,5,'整體意志力',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-30 18:12:41',0,0),(37,NULL,5,'整體控制力',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-30 18:12:41',0,0),(38,NULL,5,'整體反應力',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-30 18:12:41',0,0),(39,NULL,5,'整體潛在力',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-30 18:12:41',0,0),(40,NULL,5,'整體集中力',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-30 18:12:41',0,0);
/*!40000 ALTER TABLE `tb_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_message`
--

DROP TABLE IF EXISTS `tb_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text,
  `color` tinyint(1) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_message`
--

LOCK TABLES `tb_message` WRITE;
/*!40000 ALTER TABLE `tb_message` DISABLE KEYS */;
INSERT INTO `tb_message` (`id`, `content`, `color`, `createtime`) VALUES (1,'澳門首家線上賭場上線啦!',1,'2017-02-07 17:00:46'),(2,'新一派!\n東方不敗!\n王者之風!\n全新招式!\n石破天驚!\n看招!\n血染東方一片江!',1,'2017-02-08 17:33:21'),(3,'ルルーシュ．ヴェ．ブリタニアが命じろ，貴様達は、死ね！\n私はセロ、私は世界を壊す、世界を創造する男だ。\n',1,'2017-02-08 18:12:55'),(4,'I am the bone of my sword,\nsteel is my body,and fire is my blood,\nI have created over a thousand blade,\nUnknown to death,\nNor known to life,\nHave withstood to create many weapon,\nYet,those hands will never hold anything,\nSo as I pray,\nUnlimited Blade Works!',1,'2017-02-08 09:23:44'),(5,'測試大成功!',1,'2017-02-08 17:35:23'),(9,'hfghgfhxcvxcvxcvcxv',1,'2017-03-17 11:13:37'),(10,'rrrrrrrrrrrrrrrrrrrrrrrrrr',2,'2017-03-17 13:42:15'),(12,'hi',2,'2017-03-17 16:56:33');
/*!40000 ALTER TABLE `tb_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_monster`
--

DROP TABLE IF EXISTS `tb_monster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_monster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mid` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `icon` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `rank` tinyint(1) DEFAULT NULL,
  `itemlist` text,
  `itempra` text,
  `atk` mediumint(9) DEFAULT NULL,
  `speed` smallint(6) DEFAULT NULL,
  `hp` mediumint(9) DEFAULT NULL,
  `property` tinyint(1) DEFAULT NULL,
  `skill` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `remark` text CHARACTER SET utf8,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_monster`
--

LOCK TABLES `tb_monster` WRITE;
/*!40000 ALTER TABLE `tb_monster` DISABLE KEYS */;
INSERT INTO `tb_monster` (`id`, `mid`, `name`, `icon`, `rank`, `itemlist`, `itempra`, `atk`, `speed`, `hp`, `property`, `skill`, `remark`) VALUES (1,'A1','巨魔怨靈','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','第一隻面對的惡靈竟然是一隻巨人一樣的鬼怪，外觀十分兇殘。這惡靈性情十分兇猛，身體多處有骨組外露還有很強壯的一雙手，他全白的眼珠令他們五人都十分恐懼。這個地域裡的巨人是領域裡最低級，身型比較巨大但速度十分遲鈍。所以卓菲爾把巨魔怨靈讓五人做修行。'),(2,'A2','巨魔','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','巨魔怨靈的進化體。骨組也比前體還要多還要堅硬，速度也比前體提高了。'),(3,'A3','巨魔‧圖里奧','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','圖里奧的名稱來至於六徒消滅巨魔時在他身上取得資料所命名，受害者被殺害後身體也受惡靈佔用。擁有智慧和操控低等惡靈的策略靈體，堅硬的身體讓它更有霸氣。'),(4,'B1','瘋猿','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','據說瘋猿 在惡靈界視為 較被動的生物，只攻擊入侵它們領土者。跟巨人一樣有骨組露出但身體像人一般的身體，但有一雙長長骨組手臂可以在峽谷中自如爬行和跳躍。'),(5,'B2','噬血瘋猿','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','噬血瘋猿是瘋猿吸收活人鮮血後進化的第二身份，性情十分暴躁。只要小許血腥就能讓它沙魚般瘋狂。'),(6,'B3','血猿‧莎莉亞','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','血猿.莎莉亞 是 噬血瘋猿的進化的第三身份，外表美麗誘惑的噬血者。巨有良好跳躍力準確捕獲目標。除了腳部是骨組 上身基本和女性沒有分別，背脊有兩支長長的骨組手臂作用於跳躍和殘殺目標。'),(7,'C1','音瘋','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','音瘋是來至於結界外的山洞裡淒生的一隻惡靈它們都只會在夜間行動巨有良好的聽覺力，因此我們可能在晚宴中發出的音量過高所以無意中激發了這場戰爭。聽覺十分好的生物在日間都在睡眠狀態。。身型細小 但長出一對翼像蝙蝠一樣骨組主要在腳部和翼部。'),(8,'C2','聲瘋','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','據說比音瘋的聽覺更靈敏，骨組還要多。速度比音瘋更快。'),(9,'C3','聲瘋‧萊恩斯','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它原身也是音瘋。後來因吸收眾多活人鮮血後所脫變成擁有人類智慧的惡靈，它的聽覺比音瘋還要強，下身長滿鋒利骨組。據說卓菲爾的七徒中的一人萊恩斯在這洞穴裡被聲瘋殺害，後來卓菲爾在驅魔行動中失去七位愛徒後，返回結界時把經已變了聲瘋的萊恩斯殺掉後，命名〘聲瘋.萊恩斯〙。'),(10,'D1','伏靈','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','根據師父所說這裡有一種惡靈。它們以四支爬行喜歡伏擊和群體出現。伏靈，人類身體但以四支爬行，四支和頭部都長出骨組。速度十分靈敏。'),(11,'D2','伏擊者','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','伏擊者是伏靈的進化屬於第二身份，進化後擁有戰略智慧和超越人類的警覺性。足部的骨組尖銳無比輕易刺穿人類組織。'),(12,'D3','暗殺者‧法諾貝','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','暗殺者.法諾貝 是伏靈的第三身份，擁有極高敏捷，令人難以捕捉動向，以人型態出現身體有小許骨組，感覺像專業殺手一樣，它可以在身體每一處取出骨組武器。法諾貝的肉體被佔用所以名稱和樣貌和法諾貝也一樣。'),(13,'E1','山脈‧守護者','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','山脈.守護者 啟動刻印後所出現之惡靈，身體以岩石組成 四支有小數骨組看起來十分堅固。'),(14,'E2','山脈‧護門者','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','山脈.護門者 是守護者脫變已成的第二身份 一職守護印門的惡靈，身體的岩石脫落後剩下的骨組惡靈。巨有破壞力也十分堅硬。'),(15,'E3','門主‧勞克特','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','山脈.守護者的第三身份，擁有高破壞力同時擁有堅硬無比的身體，受到攻擊時岩石自然造出防禦。能力操作岩石保護任何攻擊。'),(16,'F1','降咒師','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','降咒師 以人類肉體設下咒語作木偶一樣利用肉體攻擊目標，被下咒的目標需要活人但失去理智。被稱為活偶。'),(17,'F2','屍咒者','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','屍咒者 殺戮人類後封鎖靈魂，利用靈魂召喚相似死者的行屍被稱為活死人。'),(18,'F3','操作者‧羅福','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','操作者. 羅福 它是降咒師的第三身份，已血液制造大量亡人惡靈。稱為再造人。羅福 已人型態出現頭部的上一部份是骨組，能看見眼睛以下的面孔，樣子滿帶邪氣。它的行縱難以觸摸，常常在黑暗中消失。能夠看得見它的每根手指帶著半光半透的絲線，意味著控制再造人的可能。羅福 的手指就像音樂家一樣揮動，再造人就像音樂團隊一樣在戰鬥中依照指令完成每一個演出。'),(19,'G1','活偶','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是活捉的人類肉體設下咒語作木偶一樣利用肉體攻擊目標，被下咒的目標需要活人但失去理智。被稱為活偶。   '),(20,'G2','活死人','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','屍咒者殺戮的人類後被召喚出來的靈魂行屍被稱為活死人。'),(21,'G3','再造人','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','再造人 擁有不死軀殼在戰鬥中帶有永不倒下的惡靈稱號。再造人的名稱來自於卓菲爾和愛徒在戰鬥中命名的。再造人能夠在戰鬥中破壞後以秒速還原軀殼再次出現。難以對付。'),(22,'H1','穴靈','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','在地底生存的惡靈，它們基本一整天也在地底，感應力十分強，只要有生物在它們領土立足，它們馬上集合起來驅逐外敵。即使對方是惡靈也被當作敵人。喜歡在地底裡突襲對手。樣貌十分不好看以四支步行，瘦削的身型和骨組， 手和腳巨有長已尖銳的骨組很容易把泥土和人類組織切割，速度十分靈敏。'),(23,'H2','穴襲魔靈','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是穴靈的第二身份，身軀長滿骨組班甲殼，仍然是四支爬行的它變得更堅硬更巨危機感。活力十分好很會閃避攻擊，它們會看機會向我進攻。樣子十分不好看的它讓人感覺恐懼，四支利爪讓大家不能和它近距離作出攻擊，十分容易被反擊。'),(24,'H3','祖穴靈人‧克迪羅','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是穴靈中地位最高級的穴靈，同時也是穴靈之首。它是的外表像一個老頭子，身體十分巨大，像人一般的體型。白色長長的邊子髮型，它看來沒有那麼大的傷害力，這是它經已成精了。它會不斷召喚穴靈再戰鬥中更難和它接觸，同時某時段會再地上破出爪牙攻擊目標。'),(25,'I1','髏蛛','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','髏蛛 它像人也像蜘蛛 四支長長的骨組足手 身體是人類骨組 沒皮也沒有肉  行動跟蜘蛛一樣。頭部有六支眼 ，有兩支眼是依照人類結構生成。它很喜歡跳躍後展開胸部的骨組 一擊捕獲目標。'),(26,'I2','毒刃髏蛛','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','毒刃髏蛛  經成長後長出四支骨組足手同時帶有令人痛苦的毒素。樣貌更像蜘蛛身體全也是骨組。眼睛比髏蛛小了三支。'),(27,'I3','蛛皇‧卡頓','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','因血液排斥骨組，把四支骨組蛛足手排斥到背後脊椎有支足手化成人類手臂，身體脫變成完美男性。長長頭髮，一對骨組耳朵，表情冷靜帶著邪惡的微笑身體帶有輕微骨組，雙腿雙手和胸膛帶著黑印。'),(28,'J1','血蠍魔像','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','血蠍魔像 本應是雕像，突然雕刻的色彩慢慢脫變成滿滿骨組和活力十足的蠍子。同時對血液十分敏感。骨組尾段帶有能一擊把目標擊殺的毒刺，速度還比得上伏擊者。'),(29,'J2','七刃魔蠍','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','七刃魔蠍 它是血蠍魔像的第二身份，擁有極高臭覺，只有血腥在它臭覺範圍內會立刻展開追捕。它們的骨組十分堅硬和花巧，外觀十分帥氣每一段骨組也帶有刺狀骨組，像仙人掌一般的保護。令人難以至信的是，它的尾段竟進化成七條長長的刺針。。。。被刺捕捉後必定不能幸存。'),(30,'J3','飆蠍‧伊妮爾','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它的來歷是經由魔蠍的尾端卵子進入人體內，無聲無色地在體內繫殖，血液是魔蠍的最佳營養慢慢魔蠍會佔用人類整個軀體，最後會驅逐身體以外的組織。它是女性，擁有完美的女性結構同時帶蠍子的尾部，蠍子的一雙骨組鉗被排斥到腰部的後背段。頭部的耳朵有小量骨組，手和腳部也有輕微骨組。 長長的髮型更美麗。伸縮自如的尾巴更難對付，速度也十分高。在戰鬥中看得見她巨有超強的自我復完能力。'),(31,'K1','惡臭屍蟲','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','名正言順的確是多臭，體型十分巨大是人類的三培體型。身體每一處也有骨組同時帶著皮肉能見骨能見肉，令人嘔吐驚心的外表身長與蛇一般那麼長。它擁有數不完的尖銳足部可以輕易爪著不平的地型向前走動。頭部看來是沒有眼睛，但有很多的尖細密集的骨齒。尾端會圏起目標以便用餐。。。'),(32,'K2','腐臭魔蟲','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是惡臭屍蟲的第二身份，身上的腐皮完整脫落成 深紫紅色的皮膚身體上滿是骨刺。活動能力明顯提升了，口部會噴濺讓人刺痛的腐蝕性液體。'),(33,'K3','屍蟲‧費蘭度','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是腐臭屍蟲的進化體，但屍蟲進化十分艱難因為需要大量能量同時會失去所有行動。當屍蟲有機會進化時，它的同伴就像服務國王一樣得到一定的地位所有糧食也是同伴供應，，，，，還有更重要的事，另類的惡靈吸血鬼會食用屍蟲的同伴帶來的食物作為一個交換保護的條件。屍蟲進化後身型得到很大變動，再不是身長長動作緩慢的蟲，，，是全身長滿十分堅硬盔甲的怪蟲。外型十分像螳螂但下身像蠍子，上半身有四支像螳螂的手刃二支長二支短的，，下半身有八至十支像蠍子的後足。在泥土中任意穿梭速度遠遠超越前體。它的下半身長時間都在泥土裡，上半身會在地面上攻擊，，時機成熟時尾巴會分散多支骨刺從地底破出穿刺目標。'),(34,'L1','斷頭髏','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是全身體都是骨組像骷髏一樣，攻擊靠著可飛躍的頭部連帶著脊椎飛向目標，身體除後立刻跳躍到目標身邊發射出刺針型的骨組彈粒。被擊中的目標身邊立刻變得十分虛弱或以致命。'),(35,'L2','斷頭髏戰士','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','全身骨組的它經突變後所有骨組驚變為裝甲一樣的骷髏戰士，飛躍的頭部可作遠程攻擊剩下的軀殼也無堅不摧。它拿著從自身取出的兩片大型骨組合併後就是一個大大的骨刺盾牌，斷頭成功固定目標後身體立刻像跑車一樣撞向目標。'),(36,'L3','骷髏王‧阿塔曼','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','dummy'),(37,'M1','奪魄','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','他是一道靈魂一樣沒有軀殼，讓人難以捉摸但是在靈魂能看得見裡面像有三個頭骨。一個頭骨帶著惡意一個頭骨帶著恐懼最後的帶著喜悅。只要被靈魂擊中立刻受到三大效果，虛弱 恐懼 沉默。'),(38,'M2','奪魂','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是奪魄的第二身份，它們奪取足夠的靈魂後演變了追求新的需求，現在它們需要的是魂魄。三魂七魄收集足夠後它們將會再渡進化。它現在經已進化半虛實體，同時看得見七個頭骨靈魂。擁有多元化的效果十分難以應付的對手。'),(39,'M3','奪魂者‧拉多利娜','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','dummy'),(40,'N1','血鬼','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是基本上是一支殭屍，巨有十分好的復原能力，但它們沒有把人類變作殭屍的能力。可是，只要它們吸收了人類血液後能力立即馬上增強，每吸收一定數量能力會再一次升幅。身體像干屍一樣，沒有完整的身體結構，當目標距離適當時會立刻沖刺，攻擊目標以牙和爪吸收血液。'),(41,'N2','吸血鬼','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是血鬼的第二身份，擁有高速度和堅硬的身體和和高輸出的惡靈。它的外表十分像人類，身體各部破出輕微骨組，它們只要感覺血液會瘋狂起來。每吸取一定血液量能力也得到提升和轉變，更令人難以置信的是它的智慧和策略。'),(42,'N3','屍王‧約德卡爾遜','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','穿著高貴衣服, 是吸血鬼之中的王者, 樣貌與人無異'),(43,'O1','假像怨靈','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它是欺詐師派出的分支骨偶，利用法力慢慢進入人體影響思維產生幻象。它是受欺詐師的骨偶，髏骨的身體穿上了黑色的道袍。活動能力不高但很像會看穿對方一樣能作出回避。它會隱藏自己在區域內利用假像使目標進入絕景，假像怨靈數量越多被騙效果更佳。'),(44,'O2','幻像魔人','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','它也是欺詐師中的一個骨偶，比假像還利害它可以數秒內把一個意志不堅定人類立刻墮入魔人產生的幻象內。它還有一種特別的能力，是把失去理智的人類操控。外表比假象怨靈更神秘更兇險。'),(45,'O3','欺詐師‧瑪丁','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','把自己的身體變化出和其他人類，軀體十分入型入格，能操控著假象怨靈和幻象魔人兩種骨偶同時變化，更易欺騙目標。當身份被識破後是穿著黑色連帽抱衣帶著帥氣的深紅色的印記繡花，頭部帶著骨組面具。'),(46,'BOSS1','卓菲爾‧立德','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','dummy'),(47,'BOSS2','異界領主','Default',1,'1,2','0.5,0.8',10,10,10,1,'dummy','dummy');
/*!40000 ALTER TABLE `tb_monster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_player`
--

DROP TABLE IF EXISTS `tb_player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_player` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `acc_id` int(10) unsigned DEFAULT NULL,
  `CharID` tinyint(1) unsigned DEFAULT NULL,
  `StatPoint` int(10) unsigned DEFAULT NULL,
  `Icon` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Level` smallint(5) unsigned DEFAULT NULL,
  `Exp` int(10) unsigned DEFAULT NULL,
  `Willpower` smallint(5) unsigned DEFAULT NULL,
  `Control` smallint(5) unsigned DEFAULT NULL,
  `Reaction` smallint(5) unsigned DEFAULT NULL,
  `Pontential` smallint(5) unsigned DEFAULT NULL,
  `Concentration` smallint(5) unsigned DEFAULT NULL,
  `DrawCountDown` smallint(5) unsigned DEFAULT NULL,
  `DrawShake` smallint(5) unsigned DEFAULT NULL,
  `Attack` int(10) unsigned DEFAULT NULL,
  `HP` int(10) unsigned DEFAULT NULL,
  `Defence` int(10) unsigned DEFAULT NULL,
  `Critiral` int(10) unsigned DEFAULT NULL,
  `FirePropertyProficiencyLevel` smallint(5) unsigned DEFAULT NULL,
  `WaterPropertyProficiencyLevel` smallint(5) unsigned DEFAULT NULL,
  `WindPropertyProficiencyLevel` smallint(5) unsigned DEFAULT NULL,
  `EarthPropertyProficiencyLevel` smallint(5) unsigned DEFAULT NULL,
  `MetalPropertyProficiencyLevel` smallint(5) unsigned DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `updatetime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_player`
--

LOCK TABLES `tb_player` WRITE;
/*!40000 ALTER TABLE `tb_player` DISABLE KEYS */;
INSERT INTO `tb_player` (`id`, `acc_id`, `CharID`, `StatPoint`, `Icon`, `Name`, `Level`, `Exp`, `Willpower`, `Control`, `Reaction`, `Pontential`, `Concentration`, `DrawCountDown`, `DrawShake`, `Attack`, `HP`, `Defence`, `Critiral`, `FirePropertyProficiencyLevel`, `WaterPropertyProficiencyLevel`, `WindPropertyProficiencyLevel`, `EarthPropertyProficiencyLevel`, `MetalPropertyProficiencyLevel`, `createtime`, `updatetime`) VALUES (1,35,1,110,'C_1','神原太一',1,0,110,0,1,1,1,1,1,10,200,10,10,0,0,0,0,0,'2017-03-21 10:12:43',NULL),(2,37,1,0,'C_1','神原太一',1,0,11,1,1,1,1,1,1,10,200,10,10,0,0,0,0,0,'2017-03-21 13:53:19',NULL),(3,38,1,0,'C_1','神原太一',1,0,11,1,1,1,1,1,1,10,200,10,10,0,0,0,0,0,'2017-03-21 15:22:46',NULL),(4,38,2,0,'C_1','神原太一',15,0,11,1,1,1,1,1,1,10,200,10,10,0,0,0,0,0,'2017-03-21 15:22:46',NULL);
/*!40000 ALTER TABLE `tb_player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_test`
--

DROP TABLE IF EXISTS `tb_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v1` text,
  `v2` text,
  `v3` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_test`
--

LOCK TABLES `tb_test` WRITE;
/*!40000 ALTER TABLE `tb_test` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_oni'
--

--
-- Dumping routines for database 'apponehk_oni'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:27
