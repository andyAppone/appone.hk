-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_client
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `999_1_admin`
--

DROP TABLE IF EXISTS `999_1_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `logintime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_admin`
--

LOCK TABLES `999_1_admin` WRITE;
/*!40000 ALTER TABLE `999_1_admin` DISABLE KEYS */;
INSERT INTO `999_1_admin` (`id`, `admin_name`, `admin_password`, `salt`, `logintime`) VALUES (1,'admin','aceb9d1b944261b9470a6b80ed32df6c','1145',1450246040);
/*!40000 ALTER TABLE `999_1_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_category`
--

DROP TABLE IF EXISTS `999_1_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_category` (
  `cat_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_category`
--

LOCK TABLES `999_1_category` WRITE;
/*!40000 ALTER TABLE `999_1_category` DISABLE KEYS */;
INSERT INTO `999_1_category` (`cat_id`, `cat_name`, `sort_order`, `image_link`, `is_show`) VALUES (128,'精華素',0,'undefined',0),(139,'洗头水',0,'undefined',0),(140,'染髮素',0,'undefined',0);
/*!40000 ALTER TABLE `999_1_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_companyinfo`
--

DROP TABLE IF EXISTS `999_1_companyinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_companyinfo` (
  `company_name` varchar(200) NOT NULL,
  `company_desc` text NOT NULL,
  `address` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chuanzhen` varchar(200) NOT NULL,
  `wangye` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_companyinfo`
--

LOCK TABLES `999_1_companyinfo` WRITE;
/*!40000 ALTER TABLE `999_1_companyinfo` DISABLE KEYS */;
INSERT INTO `999_1_companyinfo` (`company_name`, `company_desc`, `address`, `tel`, `email`, `company_logo`, `id`, `chuanzhen`, `wangye`) VALUES ('ff beauty salon','一站式香港美髮, 剪髮, 理髮服務資訊及優惠著數平台: 精選推介好髮型師, 髮型屋, 剪髮課程, 剪髮電髮染髮負離子著數優惠.','中環威靈頓街76號地下','2369-7864','info@ff.hk','/upload/company/20151217/1450322768.jpg',1,'2369-7864','http://www.ff.hk');
/*!40000 ALTER TABLE `999_1_companyinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_order`
--

DROP TABLE IF EXISTS `999_1_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(100) NOT NULL,
  `order_status` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `user_randid` varchar(100) NOT NULL COMMENT '随机的用户ID',
  `order_amount` decimal(10,2) NOT NULL COMMENT '订单价格',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_order`
--

LOCK TABLES `999_1_order` WRITE;
/*!40000 ALTER TABLE `999_1_order` DISABLE KEYS */;
INSERT INTO `999_1_order` (`order_id`, `order_sn`, `order_status`, `add_time`, `user_randid`, `order_amount`) VALUES (15,'O1450252394156',0,0,'1450252394156',0.00),(16,'O1450252695243',0,0,'1450252695243',0.00),(17,'O1450253031027',0,0,'1450253031027',0.00),(18,'O1450253178821',0,0,'1450253178821',0.00),(19,'O1450253377590',0,0,'1450253377590',0.00),(20,'O1450253503009',0,0,'1450253503009',0.00),(21,'O1450253627435',1,1450253726,'1450253627435',0.00),(22,'O1450254276677',1,1450254291,'1450254276677',0.00),(23,'O1450254644564',0,0,'1450254644564',0.00),(24,'O1450347145950',0,0,'1450347145950',0.00),(25,'O1450347875198',0,0,'1450347875198',0.00),(26,'O1450348065563',0,0,'1450348065563',0.00),(27,'O1450845645381',1,1450845653,'1450845645381',43750.00),(28,'O1450845742596',1,1450845763,'1450845742596',92530.00),(29,'O1450846867182',1,1450846868,'1450846867182',234.00),(30,'O1450847128797',1,1450847130,'1450847128797',50.00);
/*!40000 ALTER TABLE `999_1_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_order_product`
--

DROP TABLE IF EXISTS `999_1_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_sn` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_goodsnumber` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_order_product`
--

LOCK TABLES `999_1_order_product` WRITE;
/*!40000 ALTER TABLE `999_1_order_product` DISABLE KEYS */;
INSERT INTO `999_1_order_product` (`id`, `order_id`, `order_sn`, `product_id`, `product_name`, `product_price`, `product_goodsnumber`) VALUES (27,28,'O1450845742596',140,'七號精華素',234.00,1),(26,27,'O1450845645381',125,'深法洗头水',350.00,1),(28,28,'O1450845742596',139,'金色染发素',430.00,1),(29,29,'O1450846867182',140,'七號精華素',234.00,1),(30,30,'O1450847128797',141,'六號精華素',50.00,1);
/*!40000 ALTER TABLE `999_1_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_product`
--

DROP TABLE IF EXISTS `999_1_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,1) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `chengben` double(10,1) NOT NULL,
  `goodsnumber` int(11) NOT NULL,
  `goodsn` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_product`
--

LOCK TABLES `999_1_product` WRITE;
/*!40000 ALTER TABLE `999_1_product` DISABLE KEYS */;
INSERT INTO `999_1_product` (`product_id`, `cat_id`, `description`, `price`, `image_link`, `product_name`, `chengben`, `goodsnumber`, `goodsn`) VALUES (127,139,'沈香  洗头水',235.0,'upload/images/20151217/1450323351.png','沈香洗头水',2.0,11,'A000000127'),(125,139,'深法  洗头水',350.0,'upload/images/20151217/1450323352.png','深法洗头水',1.0,1,'A000000125'),(138,140,'黑色  染发素',100.0,'upload/images/20151217/1450323428.jpg','黑色染发素',1.0,100,'A000000138'),(139,140,'金色  染发素',430.0,'upload/images/20151217/1450323588.jpg','金色染发素',10.0,1000,'A000000139'),(140,128,'七號精華素',234.0,'upload/images/20151217/1450323490.jpg','七號精華素',3.0,0,'A000000140'),(141,128,'六號精華素',50.0,'upload/images/20151217/1450323606.jpg','六號精華素',10.0,999,'A000000141');
/*!40000 ALTER TABLE `999_1_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_1_step`
--

DROP TABLE IF EXISTS `999_1_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_1_step` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_1_step`
--

LOCK TABLES `999_1_step` WRITE;
/*!40000 ALTER TABLE `999_1_step` DISABLE KEYS */;
INSERT INTO `999_1_step` (`id`, `name`) VALUES (12,'下单'),(15,'包装'),(16,'送出');
/*!40000 ALTER TABLE `999_1_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_admin`
--

DROP TABLE IF EXISTS `999_2_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `logintime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_admin`
--

LOCK TABLES `999_2_admin` WRITE;
/*!40000 ALTER TABLE `999_2_admin` DISABLE KEYS */;
INSERT INTO `999_2_admin` (`id`, `admin_name`, `admin_password`, `salt`, `logintime`) VALUES (1,'admin','aceb9d1b944261b9470a6b80ed32df6c','1145',1450246040);
/*!40000 ALTER TABLE `999_2_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_category`
--

DROP TABLE IF EXISTS `999_2_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_category` (
  `cat_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_category`
--

LOCK TABLES `999_2_category` WRITE;
/*!40000 ALTER TABLE `999_2_category` DISABLE KEYS */;
INSERT INTO `999_2_category` (`cat_id`, `cat_name`, `sort_order`, `image_link`, `is_show`) VALUES (139,'男装',0,'undefined',0),(140,'女装',0,'undefined',0),(142,'童装',0,'',0);
/*!40000 ALTER TABLE `999_2_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_companyinfo`
--

DROP TABLE IF EXISTS `999_2_companyinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_companyinfo` (
  `company_name` varchar(200) NOT NULL,
  `company_desc` text NOT NULL,
  `address` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chuanzhen` varchar(200) NOT NULL,
  `wangye` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_companyinfo`
--

LOCK TABLES `999_2_companyinfo` WRITE;
/*!40000 ALTER TABLE `999_2_companyinfo` DISABLE KEYS */;
INSERT INTO `999_2_companyinfo` (`company_name`, `company_desc`, `address`, `tel`, `email`, `company_logo`, `id`, `chuanzhen`, `wangye`) VALUES ('VP','欢迎浏览VP网站, 你的一站式时装和鞋履专门店。 VP让你身处香港就能饱览世界各地时尚潮流, 同时为你搜罗全香港质素最高的时装','中環威靈頓街76號地下','2810 5533','info@VP.hk','upload/company/20151216/1450280076.jpg',1,'2810 5533','http://www.VP.hk');
/*!40000 ALTER TABLE `999_2_companyinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_order`
--

DROP TABLE IF EXISTS `999_2_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(100) NOT NULL,
  `order_status` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `user_randid` varchar(100) NOT NULL COMMENT '随机的用户ID',
  `order_amount` decimal(10,2) NOT NULL COMMENT '订单价格',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_order`
--

LOCK TABLES `999_2_order` WRITE;
/*!40000 ALTER TABLE `999_2_order` DISABLE KEYS */;
INSERT INTO `999_2_order` (`order_id`, `order_sn`, `order_status`, `add_time`, `user_randid`, `order_amount`) VALUES (14,'O566fc9450642c',1,1450166809,'566fc9450642c',99999999.99),(15,'O1450252394156',0,0,'1450252394156',0.00),(16,'O1450252695243',2,0,'1450252695243',0.00),(17,'O1450253031027',0,0,'1450253031027',0.00),(18,'O1450253178821',0,0,'1450253178821',0.00),(19,'O1450253377590',0,0,'1450253377590',0.00),(20,'O1450253503009',0,0,'1450253503009',0.00),(21,'O1450253627435',1,1450253726,'1450253627435',0.00),(22,'O1450254276677',1,1450254291,'1450254276677',0.00),(23,'O1450254644564',0,0,'1450254644564',0.00);
/*!40000 ALTER TABLE `999_2_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_order_product`
--

DROP TABLE IF EXISTS `999_2_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_sn` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_goodsnumber` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_order_product`
--

LOCK TABLES `999_2_order_product` WRITE;
/*!40000 ALTER TABLE `999_2_order_product` DISABLE KEYS */;
INSERT INTO `999_2_order_product` (`id`, `order_id`, `order_sn`, `product_id`, `product_name`, `product_price`, `product_goodsnumber`) VALUES (25,14,'O566fc9450642c',125,'home',10000000.00,125);
/*!40000 ALTER TABLE `999_2_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_product`
--

DROP TABLE IF EXISTS `999_2_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,1) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `chengben` double(10,1) NOT NULL,
  `goodsnumber` int(11) NOT NULL,
  `goodsn` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_product`
--

LOCK TABLES `999_2_product` WRITE;
/*!40000 ALTER TABLE `999_2_product` DISABLE KEYS */;
INSERT INTO `999_2_product` (`product_id`, `cat_id`, `description`, `price`, `image_link`, `product_name`, `chengben`, `goodsnumber`, `goodsn`) VALUES (143,139,'套裝-2 ',368.0,'upload/images/20151217/1450333140.jpg','套裝2',300.0,100,'A000000143'),(138,139,'套裝-1',100.0,'upload/images/20151217/1450333119.jpg','套裝1',50.0,100,'A000000138'),(139,140,'套裝-1',236.0,'upload/images/20151217/1450282996.jpg','套裝1',200.0,1000,'A000000139'),(140,140,'套裝-2 ',368.0,'upload/images/20151217/1450283000.jpg','套裝2',300.0,0,'A000000140'),(141,142,'欣童     服饰',50.0,'upload/images/20151217/1450332981.jpg','欣童服饰',10.0,100,'A000000141');
/*!40000 ALTER TABLE `999_2_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_2_step`
--

DROP TABLE IF EXISTS `999_2_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_2_step` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_2_step`
--

LOCK TABLES `999_2_step` WRITE;
/*!40000 ALTER TABLE `999_2_step` DISABLE KEYS */;
INSERT INTO `999_2_step` (`id`, `name`) VALUES (12,'下单'),(13,'加工'),(15,'包装'),(16,'送出');
/*!40000 ALTER TABLE `999_2_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_admin`
--

DROP TABLE IF EXISTS `999_3_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `logintime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_admin`
--

LOCK TABLES `999_3_admin` WRITE;
/*!40000 ALTER TABLE `999_3_admin` DISABLE KEYS */;
INSERT INTO `999_3_admin` (`id`, `admin_name`, `admin_password`, `salt`, `logintime`) VALUES (1,'admin','aceb9d1b944261b9470a6b80ed32df6c','1145',1450246040);
/*!40000 ALTER TABLE `999_3_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_category`
--

DROP TABLE IF EXISTS `999_3_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_category` (
  `cat_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=149 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_category`
--

LOCK TABLES `999_3_category` WRITE;
/*!40000 ALTER TABLE `999_3_category` DISABLE KEYS */;
INSERT INTO `999_3_category` (`cat_id`, `cat_name`, `sort_order`, `image_link`, `is_show`) VALUES (128,'奶粉',0,'undefined',0),(139,'鈣片',0,'undefined',0),(140,'疫苗',0,'undefined',0);
/*!40000 ALTER TABLE `999_3_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_companyinfo`
--

DROP TABLE IF EXISTS `999_3_companyinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_companyinfo` (
  `company_name` varchar(200) NOT NULL,
  `company_desc` text NOT NULL,
  `address` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chuanzhen` varchar(200) NOT NULL,
  `wangye` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_companyinfo`
--

LOCK TABLES `999_3_companyinfo` WRITE;
/*!40000 ALTER TABLE `999_3_companyinfo` DISABLE KEYS */;
INSERT INTO `999_3_companyinfo` (`company_name`, `company_desc`, `address`, `tel`, `email`, `company_logo`, `id`, `chuanzhen`, `wangye`) VALUES ('OGDEN CLINIC','本院自1919年創立已開始為市民提供中醫診療服務，近年更致力落實一系列的中醫服務發展計劃，二零零四年開始設立綜合中醫專科診所、增添診療設備.','中環威靈頓街76號地下','2810 5533','info@ogdenclinic.hk','upload/company/20151217/1450331323.jpg',1,'2810 5533','http://www.ogdenclinic.hk');
/*!40000 ALTER TABLE `999_3_companyinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_order`
--

DROP TABLE IF EXISTS `999_3_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(100) NOT NULL,
  `order_status` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `user_randid` varchar(100) NOT NULL COMMENT '随机的用户ID',
  `order_amount` decimal(10,2) NOT NULL COMMENT '订单价格',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_order`
--

LOCK TABLES `999_3_order` WRITE;
/*!40000 ALTER TABLE `999_3_order` DISABLE KEYS */;
INSERT INTO `999_3_order` (`order_id`, `order_sn`, `order_status`, `add_time`, `user_randid`, `order_amount`) VALUES (14,'O566fc9450642c',1,1450166809,'566fc9450642c',99999999.99),(15,'O1450252394156',0,0,'1450252394156',0.00),(16,'O1450252695243',0,0,'1450252695243',0.00),(17,'O1450253031027',0,0,'1450253031027',0.00),(18,'O1450253178821',0,0,'1450253178821',0.00),(19,'O1450253377590',0,0,'1450253377590',0.00),(20,'O1450253503009',0,0,'1450253503009',0.00),(21,'O1450253627435',1,1450253726,'1450253627435',0.00),(22,'O1450254276677',1,1450254291,'1450254276677',0.00),(23,'O1450254644564',0,0,'1450254644564',0.00);
/*!40000 ALTER TABLE `999_3_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_order_product`
--

DROP TABLE IF EXISTS `999_3_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_sn` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_goodsnumber` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_order_product`
--

LOCK TABLES `999_3_order_product` WRITE;
/*!40000 ALTER TABLE `999_3_order_product` DISABLE KEYS */;
INSERT INTO `999_3_order_product` (`id`, `order_id`, `order_sn`, `product_id`, `product_name`, `product_price`, `product_goodsnumber`) VALUES (25,14,'O566fc9450642c',125,'home',10000000.00,125);
/*!40000 ALTER TABLE `999_3_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_product`
--

DROP TABLE IF EXISTS `999_3_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,1) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `chengben` double(10,1) NOT NULL,
  `goodsnumber` int(11) NOT NULL,
  `goodsn` varchar(100) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_product`
--

LOCK TABLES `999_3_product` WRITE;
/*!40000 ALTER TABLE `999_3_product` DISABLE KEYS */;
INSERT INTO `999_3_product` (`product_id`, `cat_id`, `description`, `price`, `image_link`, `product_name`, `chengben`, `goodsnumber`, `goodsn`) VALUES (127,128,'牛欄牌    奶粉',369.0,'upload/images/20151217/1450329994.jpg','牛蘭板奶粉',292.0,2,'A000000127'),(125,128,'荷蘭板    奶粉',369.0,'upload/images/20151217/1450329900.png','荷欄牌奶粉',234.0,1,'A000000125'),(138,139,'7色  鈣片',100.0,'upload/images/20151217/1450330263.jpg','7色鈣片',23.0,100,'A000000138'),(139,140,'玫瑰疹    疫苗',430.0,'upload/images/20151217/1450330543.jpg','玫瑰疹疫苗',150.0,1000,'A000000139'),(140,140,'肺炎    疫苗',500.0,'upload/images/20151217/1450330542.jpg','肺炎疫苗',250.0,0,'A000000140'),(143,139,'可可    鈣片',635.0,'upload/images/20151217/1450330617.jpg','可可鈣片',500.0,100,'A000000143');
/*!40000 ALTER TABLE `999_3_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_3_step`
--

DROP TABLE IF EXISTS `999_3_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_3_step` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_3_step`
--

LOCK TABLES `999_3_step` WRITE;
/*!40000 ALTER TABLE `999_3_step` DISABLE KEYS */;
INSERT INTO `999_3_step` (`id`, `name`) VALUES (12,'下单'),(15,'包装'),(16,'送出');
/*!40000 ALTER TABLE `999_3_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_admin`
--

DROP TABLE IF EXISTS `999_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `admin_password` varchar(100) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `logintime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_admin`
--

LOCK TABLES `999_admin` WRITE;
/*!40000 ALTER TABLE `999_admin` DISABLE KEYS */;
INSERT INTO `999_admin` (`id`, `admin_name`, `admin_password`, `salt`, `logintime`) VALUES (1,'admin','aceb9d1b944261b9470a6b80ed32df6c','1145',1484729995);
/*!40000 ALTER TABLE `999_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_article`
--

DROP TABLE IF EXISTS `999_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `article_title` varchar(200) NOT NULL,
  `article_content` text NOT NULL COMMENT '排序',
  `sort_order` int(11) NOT NULL DEFAULT '0',
  `show_menu` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示在侧边栏',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_article`
--

LOCK TABLES `999_article` WRITE;
/*!40000 ALTER TABLE `999_article` DISABLE KEYS */;
INSERT INTO `999_article` (`id`, `article_title`, `article_content`, `sort_order`, `show_menu`, `is_show`, `add_time`) VALUES (7,'店铺地址','<p><img src=\"/999client/upload/image/20160304/1457064356311765.png\" title=\"1457064356311765.png\" alt=\"ass-bone.png\"/>123123123123123</p>',48,1,1,1457064359),(6,'联络我们','<p style=\"text-align:center\"></p><p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3691.1211615187112!2d114.22472771544034!3d22.311257048134078!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3404014fff1c7c71%3A0x26a09d3dfdd13020!2z6KeA5aGY6KeA5aGY6YGTNDM2LTQ0NuiZn-WumOWhmOW3pealreS4reW_gzTmnJ8!5e0!3m2!1szh-TW!2shk!4v1452832500340\" width=\"1700\" height=\"500\" scrolling=\"no\" frameborder=\"0\" align=\"\"></iframe></p><ul class=\" list-paddingleft-2\" style=\"list-style-type: none;\"><li><p><span style=\"box-sizing: border-box; margin: 5px 0px 0px 10px; padding: 0px; border: 0px; vertical-align: top;\">Address：Room K ,4th floor, Kwun Tong Industrial Centre no.4, Hong Kong</span></p></li><li><p><span class=\"fa fa-clock-o\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; transition: 0.2s ease-in-out; display: inline-block; font-family: FontAwesome; line-height: 1; -webkit-font-smoothing: antialiased;\"></span><span style=\"box-sizing: border-box; margin: 5px 0px 0px 10px; padding: 0px; border: 0px; vertical-align: top;\">Working Hour：10:00am to 6:00pm , Monday to Friday</span></p></li><li><p><span class=\"fa fa-phone\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; transition: 0.2s ease-in-out; display: inline-block; font-family: FontAwesome; line-height: 1; -webkit-font-smoothing: antialiased;\"></span><span style=\"box-sizing: border-box; margin: 5px 0px 0px 10px; padding: 0px; border: 0px; vertical-align: top;\">Phone：<a href=\"tel:21520198\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; color: rgb(254, 185, 2); text-decoration: none; outline: none; transition: 0.2s ease-in-out; background: transparent;\">852-21520198</a></span></p></li><li><p><span class=\"fa fa-phone\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; transition: 0.2s ease-in-out; display: inline-block; font-family: FontAwesome; line-height: 1; -webkit-font-smoothing: antialiased;\"></span><span style=\"box-sizing: border-box; margin: 5px 0px 0px 10px; padding: 0px; border: 0px; vertical-align: top;\">Whatspp/Wechat/Line: 852-96005138</span></p></li><li><p><span class=\"fa fa-envelope\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; transition: 0.2s ease-in-out; display: inline-block; font-family: FontAwesome; line-height: 1; -webkit-font-smoothing: antialiased;\"></span><span style=\"box-sizing: border-box; margin: 5px 0px 0px 10px; padding: 0px; border: 0px; vertical-align: top;\">Email：<a href=\"mailto:your-email@your-domain.com\" style=\"box-sizing: border-box; margin: 0px; padding: 0px; border: 0px; vertical-align: top; color: rgb(254, 185, 2); text-decoration: none; outline: none; transition: 0.2s ease-in-out; background: transparent;\">info@appone.hk</a></span></p></li></ul><p><br/></p>',49,1,1,1457064315),(5,'关于我们','<p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; padding: 0px; border: 0px; font-size: 13px; vertical-align: top; line-height: 2em; color: rgb(18, 18, 18); font-family: Montserrat, sans-serif; white-space: normal; text-align: center; background-color: rgb(255, 255, 255);\"><img src=\"/999client/upload/image/20160304/1457075285136931.png\" title=\"1457075285136931.png\" alt=\"googlelogo_color_272x92dp.png\"/></p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; padding: 0px; border: 0px; font-size: 13px; vertical-align: top; line-height: 2em; color: rgb(18, 18, 18); font-family: Montserrat, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">AppOne Esolution Limited, the precursors of AppOne Mobile Solution, is one of the members of eprint group (HKEX:1884). We are one of the leading app company in Hong Kong, specialized in iOS/Android, Website and System development with the aim to provide best quality and competitive cost of IT solutions that improves companies&#39; business and brand reputation as well as supports their integration into the global marketplace and global community. We have reached world-class standard and pending the award of iSO9001.</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; padding: 0px; border: 0px; font-size: 13px; vertical-align: top; line-height: 2em; color: rgb(18, 18, 18); font-family: Montserrat, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">We are honored that we have the privilege of working with some of the world leading companies like Ove Arup &amp; Partners Hong Kong Ltd, Fuji Xerox Co., Ltd. and L&#39;occitane. We have not only worked with some of the most famous companies in Hong Kong, for example, Jetour Mice Services Ltd., Konew Financial Express, Chung Yuen Electrical co ltd, Snowbrand (Hong Kong) ltd. and Asian Film Award Academy, but also numbers of local organizations such as Hong Kong Play Association and Association of Hong Kong Visual Arts and Culture Education Limited.</p><p style=\"box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; padding: 0px; border: 0px; font-size: 13px; vertical-align: top; line-height: 2em; color: rgb(18, 18, 18); font-family: Montserrat, sans-serif; white-space: normal; background-color: rgb(255, 255, 255);\">We thank our clients for placing trust on us and we will keep enhancing our quality and services in our continuous pursuit for quality and service excellence.</p><p><br/></p>',50,1,1,1457064299);
/*!40000 ALTER TABLE `999_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_attribute`
--

DROP TABLE IF EXISTS `999_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) NOT NULL COMMENT '屬性名稱',
  `attribute_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '屬性價格',
  `attribute_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '屬性類型(1->單選,2->複選)',
  `sort_order` int(11) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_attribute`
--

LOCK TABLES `999_attribute` WRITE;
/*!40000 ALTER TABLE `999_attribute` DISABLE KEYS */;
INSERT INTO `999_attribute` (`id`, `attribute_name`, `attribute_price`, `attribute_type`, `sort_order`, `is_show`) VALUES (10,'多饭',0.00,1,100,1),(11,'少饭',0.00,1,99,1),(12,'冻',2.00,1,98,1),(13,'多汁',0.00,1,98,1),(14,'少冰',0.00,1,0,1),(15,'多冰',0.00,1,0,1);
/*!40000 ALTER TABLE `999_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_boss`
--

DROP TABLE IF EXISTS `999_boss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_boss` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `boss_name` varchar(100) NOT NULL,
  `boss_password` varchar(100) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `logintime` int(11) NOT NULL,
  `logout_limit` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_boss`
--

LOCK TABLES `999_boss` WRITE;
/*!40000 ALTER TABLE `999_boss` DISABLE KEYS */;
INSERT INTO `999_boss` (`id`, `boss_name`, `boss_password`, `salt`, `logintime`, `logout_limit`) VALUES (4,'boss','96e79218965eb72c92a549dd5a330112','',0,0);
/*!40000 ALTER TABLE `999_boss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_boss_setting`
--

DROP TABLE IF EXISTS `999_boss_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_boss_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `boss_data_list` varchar(200) NOT NULL COMMENT 'boss版数据列表参数',
  `boss_order_step_list` varchar(200) NOT NULL COMMENT 'boss版总单数，总产品数，步骤总和',
  `boss_order_list` varchar(200) NOT NULL COMMENT 'boss版订单列表',
  `bg` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_boss_setting`
--

LOCK TABLES `999_boss_setting` WRITE;
/*!40000 ALTER TABLE `999_boss_setting` DISABLE KEYS */;
INSERT INTO `999_boss_setting` (`id`, `boss_data_list`, `boss_order_step_list`, `boss_order_list`, `bg`) VALUES (1,'','','','FFF8A6');
/*!40000 ALTER TABLE `999_boss_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_boss_table`
--

DROP TABLE IF EXISTS `999_boss_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_boss_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(200) NOT NULL,
  `add_time` int(11) NOT NULL,
  `options` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_boss_table`
--

LOCK TABLES `999_boss_table` WRITE;
/*!40000 ALTER TABLE `999_boss_table` DISABLE KEYS */;
INSERT INTO `999_boss_table` (`id`, `table_name`, `add_time`, `options`) VALUES (47,'ȡ�47',1464948951,'{\"timetype\":3,\"starttime\":1454256000,\"endtime\":\"1466092800\",\"dataType\":2,\"saletype\":2,\"pcttype\":21,\"cat_id\":22,\"liketype\":1}'),(46,'圖表46',1464948694,'{\"timetype\":3,\"starttime\":1451577600,\"endtime\":\"1466438400\",\"dataType\":1,\"saletype\":2,\"pcttype\":21,\"cat_id\":0,\"liketype\":1}'),(45,'table45',1464948081,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464948064\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":2}'),(44,'Table44',1464943615,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464883200\",\"dataType\":2,\"saletype\":1,\"pcttype\":1,\"cat_id\":22,\"liketype\":1}'),(48,'圖表48',1465177593,'{\"timetype\":3,\"starttime\":1451577600,\"endtime\":\"1465488000\",\"dataType\":2,\"saletype\":1,\"pcttype\":1,\"cat_id\":22,\"liketype\":2}'),(43,'Table43',1464939271,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464883200\",\"dataType\":2,\"saletype\":1,\"pcttype\":1,\"cat_id\":25,\"liketype\":2}'),(41,'table41',1464843782,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464843781\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(40,'Table40',1464672943,'{\"timetype\":2,\"starttime\":0,\"endtime\":\"1464624000\",\"dataType\":1,\"saletype\":2,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(39,'Test',1464589644,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1465164000\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(36,'Table36',1464260132,'{\"timetype\":1,\"starttime\":1462377600,\"endtime\":\"1464537600\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":22,\"liketype\":2}'),(37,'Table37',1464333441,'{\"timetype\":1,\"starttime\":1136217600,\"endtime\":\"1464624000\",\"dataType\":2,\"saletype\":1,\"pcttype\":1,\"cat_id\":22,\"liketype\":1}'),(35,'table35',1464249088,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464249086\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(56,'圖表56',1466152051,'{\"timetype\":1,\"starttime\":0,\"endtime\":\"1464278400\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":2}'),(34,'Table34',1464243493,'{\"timetype\":3,\"starttime\":1464710400,\"endtime\":\"1464883200\",\"dataType\":1,\"saletype\":1,\"pcttype\":21,\"cat_id\":0,\"liketype\":1}'),(53,'圖表53',1466131677,'{\"timetype\":1,\"starttime\":1370448000,\"endtime\":\"1465142400\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(51,'圖表51',1465213432,'{\"timetype\":3,\"starttime\":1464710400,\"endtime\":\"1465574400\",\"dataType\":1,\"saletype\":2,\"pcttype\":1,\"cat_id\":0,\"liketype\":3}'),(52,'圖表52',1465882555,'{\"timetype\":3,\"starttime\":1362412800,\"endtime\":\"1465833600\",\"dataType\":1,\"saletype\":2,\"pcttype\":21,\"cat_id\":0,\"liketype\":1}'),(54,'圖表54',1466144781,'{\"timetype\":1,\"starttime\":1371398400,\"endtime\":\"1466092800\",\"dataType\":1,\"saletype\":1,\"pcttype\":1,\"cat_id\":0,\"liketype\":1}'),(55,'圖表55',1466151624,'{\"timetype\":3,\"starttime\":1454256000,\"endtime\":\"1466006400\",\"dataType\":2,\"saletype\":1,\"pcttype\":12,\"cat_id\":22,\"liketype\":1}'),(57,'圖表57',1466153626,'{\"timetype\":3,\"starttime\":1371398400,\"endtime\":\"1466092800\",\"dataType\":1,\"saletype\":2,\"pcttype\":21,\"cat_id\":0,\"liketype\":3}');
/*!40000 ALTER TABLE `999_boss_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_cart`
--

DROP TABLE IF EXISTS `999_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desk_id` int(11) NOT NULL COMMENT '台ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `product_name` varchar(200) NOT NULL COMMENT '产品名称',
  `price` int(11) NOT NULL COMMENT '原价',
  `is_time_price` tinyint(1) NOT NULL COMMENT '是否时价',
  `time_price` decimal(10,1) NOT NULL COMMENT '时价',
  `hitmeal` tinyint(1) NOT NULL COMMENT '是否撞餐',
  `hitmeal_price` decimal(10,1) NOT NULL COMMENT '撞餐价格',
  `jump` tinyint(1) NOT NULL COMMENT '是否跳价',
  `jumpprice` decimal(10,1) NOT NULL COMMENT '跳价',
  `setmeal_id` int(11) NOT NULL COMMENT '套餐ID',
  `setmeal_select` text NOT NULL COMMENT '选中的套餐（JSON）',
  `attr` text NOT NULL COMMENT '选择的属性',
  `msg` varchar(200) NOT NULL COMMENT '提示信息',
  `item_total` decimal(10,1) NOT NULL,
  `buycount` int(11) NOT NULL COMMENT '购买数量',
  `tmpcartname` varchar(100) NOT NULL COMMENT '临时的cartname',
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `desk_id` (`desk_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6449 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_cart`
--

LOCK TABLES `999_cart` WRITE;
/*!40000 ALTER TABLE `999_cart` DISABLE KEYS */;
INSERT INTO `999_cart` (`id`, `desk_id`, `product_id`, `product_name`, `price`, `is_time_price`, `time_price`, `hitmeal`, `hitmeal_price`, `jump`, `jumpprice`, `setmeal_id`, `setmeal_select`, `attr`, `msg`, `item_total`, `buycount`, `tmpcartname`, `cat_id`) VALUES (4165,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_c',35),(4164,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_b_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4163,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(204,0,411,'三文魚卷',16,0,0.0,0,0.0,0,0.0,0,'','null','',16.0,1,'p411',27),(4162,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_d_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4161,0,434,'檸啡',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p434_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4160,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_b_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4159,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4158,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_d_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4157,0,434,'檸啡',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p434_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4156,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4155,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_d_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4154,0,434,'檸啡',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p434_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4153,0,440,'檸檬水',11,0,0.0,0,0.0,0,0.0,0,'','null','',11.0,1,'p440_d_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(4152,0,434,'檸啡',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p434_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(3538,9,325,'油占多士',30,0,0.0,0,0.0,0,0.0,0,'','null','',30.0,1,'p325',25),(4151,0,434,'檸啡',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p434_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a_a',35),(6448,8,416,'出前一丁',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p416_a',34),(6447,8,422,'烏冬',13,0,0.0,0,0.0,0,0.0,0,'','null','',13.0,1,'p422_a',34),(6446,8,416,'出前一丁',15,0,0.0,0,0.0,0,0.0,0,'','null','',15.0,1,'p416',34),(6445,8,422,'烏冬',13,0,0.0,0,0.0,0,0.0,0,'','null','',13.0,1,'p422',34);
/*!40000 ALTER TABLE `999_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_category`
--

DROP TABLE IF EXISTS `999_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_category` (
  `cat_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(200) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `show_colspan` tinyint(4) NOT NULL COMMENT '分类显示在第几列',
  `show_colspan_sort` int(11) NOT NULL COMMENT '分类显示在第几列的排序',
  PRIMARY KEY (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_category`
--

LOCK TABLES `999_category` WRITE;
/*!40000 ALTER TABLE `999_category` DISABLE KEYS */;
INSERT INTO `999_category` (`cat_id`, `cat_name`, `sort_order`, `image_link`, `is_show`, `show_colspan`, `show_colspan_sort`) VALUES (23,'腌列类',0,'undefined',0,1,2),(22,'蛋类',0,'undefined',0,1,1),(25,'多士类',0,'undefined',0,2,1),(26,'脆飞碟类',0,'undefined',0,2,2),(24,'麦皮类',0,'undefined',0,1,3),(27,'三文治类单拼',0,'undefined',0,2,3),(28,'双拼',0,'undefined',0,2,4),(29,'其他要求',0,'undefined',0,2,5),(30,'包类',0,'undefined',0,3,1),(31,'任選一項',0,'undefined',0,4,1),(32,'出炉面包',0,'undefined',0,3,2),(33,'任選二項',0,'undefined',0,4,2),(34,'通粉／麵類',0,'undefined',0,5,1),(35,'飲品類',0,'undefined',0,6,1),(36,'罐裝汽水',0,'undefined',0,6,2),(37,'凍飲刨冰',0,'undefined',0,6,3),(38,'特色飲品',0,'undefined',0,6,4),(39,'其他要求',0,'undefined',0,6,5);
/*!40000 ALTER TABLE `999_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_companyinfo`
--

DROP TABLE IF EXISTS `999_companyinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_companyinfo` (
  `company_name` varchar(200) NOT NULL,
  `company_desc` text NOT NULL,
  `address` text NOT NULL,
  `tel` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `chuanzhen` varchar(200) NOT NULL,
  `wangye` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_companyinfo`
--

LOCK TABLES `999_companyinfo` WRITE;
/*!40000 ALTER TABLE `999_companyinfo` DISABLE KEYS */;
INSERT INTO `999_companyinfo` (`company_name`, `company_desc`, `address`, `tel`, `email`, `company_logo`, `id`, `chuanzhen`, `wangye`) VALUES ('公司名稱','   公司详情公司详情公司详情公司详情公司详情公司详情公司详情公司详情公司详情公司详情公司详情','03/20F, Sin Building ,Tak Tin Estate, Kwun Tong','88908272','bpcs04054a30@yahoo.com.hk','upload/company/20160216/1455589140.png',1,'8888 0000','http://www.baidu.com');
/*!40000 ALTER TABLE `999_companyinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_desk`
--

DROP TABLE IF EXISTS `999_desk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_desk` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `desk_name` varchar(200) NOT NULL,
  `is_use` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否正在使用',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '餐桌状态(1.下单,2.用餐,3.结账)',
  `addtime` int(11) NOT NULL COMMENT '占座的时间',
  `staff_id` int(11) NOT NULL COMMENT '当前进入的职员',
  `staff_lasttime` int(11) NOT NULL COMMENT '职员最后操作的时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_desk`
--

LOCK TABLES `999_desk` WRITE;
/*!40000 ALTER TABLE `999_desk` DISABLE KEYS */;
INSERT INTO `999_desk` (`id`, `desk_name`, `is_use`, `status`, `addtime`, `staff_id`, `staff_lasttime`) VALUES (1,'1',0,0,0,11,1484733060),(2,'2',1,1,1484723619,11,1484723562),(7,'1b',1,1,1479358466,11,1479358461),(6,'1a',1,1,1484723625,11,1484723621),(8,'1c',1,1,1484723752,11,1484724790),(9,'2a',0,0,0,5,1476433107),(10,'3',1,1,1479358486,11,1479358481),(11,'4',0,0,0,11,1479357371),(12,'5',0,0,0,11,1479357324),(13,'6',1,1,1466476663,5,1476881974),(14,'7',0,0,0,11,1465872609),(15,'8',1,1,1479358500,11,1479358496),(16,'9',0,0,0,5,1476696187),(17,'10',1,1,1479106628,5,1479106624),(18,'11',0,0,0,5,1476758098),(19,'12',0,0,0,11,1465872576),(20,'13',0,0,0,11,1465872620),(21,'14',1,1,1465547581,5,1476697009),(22,'15',0,0,0,5,1476696995),(23,'16',1,1,1479358494,11,1479358488);
/*!40000 ALTER TABLE `999_desk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_hitmeal`
--

DROP TABLE IF EXISTS `999_hitmeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_hitmeal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hitmeal_rule` varchar(200) NOT NULL,
  `c1` int(11) NOT NULL COMMENT '第一个分类的ID',
  `c2` int(11) NOT NULL COMMENT '第二个分类的ID',
  `c_select` int(11) NOT NULL COMMENT '获取价格的field',
  `price_type` int(11) NOT NULL COMMENT '价格类型',
  `is_use` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `rule_type` tinyint(1) NOT NULL COMMENT '规则类型,1->撞餐,2->跳餐',
  `c3` int(11) NOT NULL COMMENT '跳餐分类',
  `c3_price_type` int(112) NOT NULL COMMENT '跳餐的价格类型',
  `c3_rule` varchar(100) NOT NULL COMMENT '跳餐的规则',
  `rule_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_hitmeal`
--

LOCK TABLES `999_hitmeal` WRITE;
/*!40000 ALTER TABLE `999_hitmeal` DISABLE KEYS */;
/*!40000 ALTER TABLE `999_hitmeal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_menu`
--

DROP TABLE IF EXISTS `999_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(200) NOT NULL COMMENT 'MENU名称',
  `sort_order` int(11) NOT NULL COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `color` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_menu`
--

LOCK TABLES `999_menu` WRITE;
/*!40000 ALTER TABLE `999_menu` DISABLE KEYS */;
INSERT INTO `999_menu` (`id`, `menu_name`, `sort_order`, `is_show`, `color`) VALUES (11,'西式早餐',99,0,'#ffb76f'),(10,'精选早餐',100,1,'#ffff00'),(12,'麦皮早餐',98,1,'#00ffff'),(13,'三文治早餐',97,1,'#c0c0c0'),(14,'汤面早餐',96,1,'#dfbfff'),(15,'脆包早餐',95,1,'#83e16f');
/*!40000 ALTER TABLE `999_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_menu_category`
--

DROP TABLE IF EXISTS `999_menu_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_menu_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_menu_category`
--

LOCK TABLES `999_menu_category` WRITE;
/*!40000 ALTER TABLE `999_menu_category` DISABLE KEYS */;
INSERT INTO `999_menu_category` (`id`, `menu_id`, `cat_id`) VALUES (16,1,5),(15,1,11);
/*!40000 ALTER TABLE `999_menu_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_menu_position`
--

DROP TABLE IF EXISTS `999_menu_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_menu_position` (
  `position_` int(11) NOT NULL COMMENT '位置',
  `is_cat` tinyint(1) NOT NULL COMMENT '是否分类',
  `cat_id` int(11) NOT NULL COMMENT '分类ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `menu_id` int(11) NOT NULL COMMENT '菜单ID',
  `in_cat_id` int(11) NOT NULL COMMENT '在哪个分类下面显示',
  `page_` int(11) NOT NULL COMMENT '页面',
  KEY `product_id` (`product_id`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_menu_position`
--

LOCK TABLES `999_menu_position` WRITE;
/*!40000 ALTER TABLE `999_menu_position` DISABLE KEYS */;
INSERT INTO `999_menu_position` (`position_`, `is_cat`, `cat_id`, `product_id`, `menu_id`, `in_cat_id`, `page_`) VALUES (4,0,0,491,8,0,1),(2,0,0,544,10,0,1),(0,0,0,451,11,0,1),(3,0,0,308,11,0,1),(1,0,0,544,8,0,1),(3,0,0,491,8,0,1),(1,0,0,542,10,0,1),(4,0,0,539,10,0,1),(2,0,0,453,11,0,1),(0,0,0,542,8,0,1),(4,0,0,306,11,0,1),(1,0,0,452,11,0,1),(3,0,0,539,10,0,1),(0,0,0,561,10,0,1),(2,0,0,569,8,0,1);
/*!40000 ALTER TABLE `999_menu_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_menu_product`
--

DROP TABLE IF EXISTS `999_menu_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_menu_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL COMMENT 'meun_id',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `cat_id` int(11) NOT NULL COMMENT '产品ID对应的分类ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=997 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_menu_product`
--

LOCK TABLES `999_menu_product` WRITE;
/*!40000 ALTER TABLE `999_menu_product` DISABLE KEYS */;
INSERT INTO `999_menu_product` (`id`, `menu_id`, `product_id`, `cat_id`) VALUES (228,10,420,34),(229,10,421,34),(230,10,422,34),(231,10,423,34),(232,10,424,34),(233,10,430,35),(234,10,431,35),(235,10,432,35),(236,10,433,35),(237,10,434,35),(238,10,435,35),(239,10,436,35),(240,10,437,35),(241,10,438,35),(205,10,324,25),(204,10,323,25),(203,10,322,25),(206,10,398,33),(207,10,399,33),(208,10,400,33),(209,10,401,33),(210,10,402,33),(211,10,403,33),(212,10,404,33),(213,10,405,33),(214,10,406,33),(215,10,407,33),(216,10,408,33),(217,10,409,33),(218,10,410,33),(219,10,411,33),(220,10,412,33),(221,10,413,33),(222,10,414,33),(223,10,415,33),(224,10,416,34),(225,10,417,34),(226,10,418,34),(227,10,419,34),(202,10,321,25),(201,10,326,25),(200,10,325,25),(199,10,327,25),(198,10,306,22),(197,10,307,22),(196,10,308,22),(195,10,311,22),(194,10,310,22),(193,10,309,22),(242,10,439,35),(243,10,440,35),(244,10,441,35),(245,10,442,35),(246,10,444,35),(247,10,446,36),(248,10,447,36),(249,10,448,36),(250,10,449,36),(251,10,450,36),(252,10,457,38),(253,10,458,38),(254,10,459,38),(255,10,460,38),(256,10,461,38),(257,10,462,38),(258,10,463,38),(259,10,464,38),(260,10,465,38),(261,10,466,38),(262,10,467,38),(263,10,468,38),(264,10,469,38),(265,10,470,39),(266,10,471,39),(267,10,472,39),(268,10,473,39),(269,10,474,39),(996,11,474,39),(995,11,473,39),(994,11,472,39),(993,11,471,39),(992,11,470,39),(991,11,469,38),(990,11,468,38),(989,11,467,38),(988,11,466,38),(987,11,465,38),(986,11,464,38),(985,11,463,38),(984,11,462,38),(983,11,461,38),(982,11,460,38),(981,11,459,38),(980,11,458,38),(979,11,457,38),(978,11,450,36),(977,11,449,36),(976,11,448,36),(975,11,447,36),(974,11,446,36),(973,11,444,35),(972,11,442,35),(971,11,441,35),(970,11,440,35),(969,11,439,35),(968,11,438,35),(967,11,437,35),(966,11,436,35),(965,11,435,35),(964,11,434,35),(963,11,433,35),(962,11,432,35),(961,11,431,35),(960,11,430,35),(959,11,397,31),(958,11,396,31),(957,11,395,31),(956,11,394,31),(955,11,393,31),(954,11,392,31),(953,11,391,31),(952,11,390,31),(951,11,389,31),(950,11,324,25),(949,11,323,25),(948,11,322,25),(947,11,321,25),(946,11,326,25),(945,11,325,25),(944,11,327,25),(943,11,328,25),(942,11,306,22),(941,11,307,22),(940,11,308,22),(939,11,311,22),(938,11,310,22),(937,11,309,22),(330,12,319,24),(331,12,320,24),(332,12,317,24),(333,12,318,24),(334,12,352,27),(335,12,351,27),(336,12,350,27),(337,12,349,27),(338,12,348,27),(339,12,347,27),(340,12,346,27),(341,12,345,27),(342,12,358,28),(343,12,359,28),(344,12,353,28),(345,12,354,28),(346,12,355,28),(347,12,356,28),(348,12,357,28),(349,12,360,28),(350,12,361,28),(351,12,362,28),(352,12,364,29),(353,12,430,35),(354,12,431,35),(355,12,432,35),(356,12,433,35),(357,12,434,35),(358,12,435,35),(359,12,436,35),(360,12,437,35),(361,12,438,35),(362,12,439,35),(363,12,440,35),(364,12,441,35),(365,12,442,35),(366,12,443,35),(367,12,444,35),(368,12,445,35),(369,12,446,36),(370,12,447,36),(371,12,448,36),(372,12,449,36),(373,12,450,36),(374,12,457,38),(375,12,458,38),(376,12,459,38),(377,12,460,38),(378,12,461,38),(379,12,462,38),(380,12,463,38),(381,12,464,38),(382,12,465,38),(383,12,466,38),(384,12,467,38),(385,12,468,38),(386,12,469,38),(387,12,470,39),(388,12,471,39),(389,12,472,39),(390,12,473,39),(391,13,352,27),(392,13,351,27),(393,13,350,27),(394,13,349,27),(395,13,348,27),(396,13,347,27),(397,13,346,27),(398,13,345,27),(399,13,358,28),(400,13,359,28),(401,13,353,28),(402,13,354,28),(403,13,355,28),(404,13,356,28),(405,13,357,28),(406,13,360,28),(407,13,361,28),(408,13,362,28),(409,13,364,29),(410,13,430,35),(411,13,431,35),(412,13,432,35),(413,13,433,35),(414,13,434,35),(415,13,435,35),(416,13,436,35),(417,13,437,35),(418,13,438,35),(419,13,439,35),(420,13,440,35),(421,13,441,35),(422,13,442,35),(423,13,443,35),(424,13,444,35),(425,13,445,35),(426,13,446,36),(427,13,447,36),(428,13,448,36),(429,13,449,36),(430,13,450,36),(431,13,457,38),(432,13,458,38),(433,13,459,38),(434,13,460,38),(435,13,461,38),(436,13,462,38),(437,13,463,38),(438,13,464,38),(439,13,465,38),(440,13,466,38),(441,13,467,38),(442,13,468,38),(443,13,469,38),(444,13,470,39),(445,13,471,39),(446,13,472,39),(447,13,473,39),(723,14,469,38),(722,14,468,38),(721,14,467,38),(720,14,466,38),(719,14,465,38),(718,14,464,38),(717,14,463,38),(716,14,462,38),(715,14,461,38),(714,14,460,38),(713,14,459,38),(712,14,458,38),(711,14,457,38),(710,14,450,36),(709,14,449,36),(708,14,448,36),(707,14,447,36),(706,14,446,36),(705,14,445,35),(704,14,444,35),(703,14,443,35),(702,14,442,35),(701,14,441,35),(700,14,440,35),(699,14,439,35),(698,14,438,35),(697,14,437,35),(696,14,436,35),(695,14,435,35),(694,14,434,35),(693,14,433,35),(692,14,432,35),(691,14,431,35),(690,14,430,35),(689,14,429,34),(688,14,428,34),(687,14,427,34),(686,14,426,34),(685,14,425,34),(684,14,424,34),(683,14,423,34),(682,14,422,34),(681,14,421,34),(680,14,420,34),(679,14,419,34),(678,14,418,34),(677,14,417,34),(676,14,416,34),(675,14,415,33),(674,14,414,33),(673,14,413,33),(672,14,412,33),(671,14,411,33),(670,14,410,33),(669,14,409,33),(668,14,408,33),(667,14,407,33),(666,14,406,33),(665,14,405,33),(664,14,404,33),(663,14,403,33),(662,14,402,33),(661,14,401,33),(660,14,400,33),(659,14,399,33),(658,14,398,33),(657,14,397,31),(656,14,396,31),(655,14,395,31),(654,14,394,31),(653,14,393,31),(652,14,392,31),(651,14,391,31),(650,14,390,31),(649,14,389,31),(876,15,474,39),(875,15,473,39),(874,15,472,39),(873,15,471,39),(872,15,470,39),(871,15,469,38),(870,15,468,38),(869,15,467,38),(868,15,466,38),(867,15,465,38),(866,15,464,38),(865,15,463,38),(864,15,462,38),(863,15,461,38),(862,15,460,38),(861,15,459,38),(860,15,458,38),(859,15,457,38),(858,15,450,36),(857,15,449,36),(856,15,448,36),(855,15,447,36),(854,15,446,36),(853,15,445,35),(852,15,444,35),(851,15,443,35),(850,15,442,35),(849,15,441,35),(848,15,440,35),(847,15,439,35),(846,15,438,35),(845,15,437,35),(844,15,436,35),(843,15,435,35),(842,15,434,35),(841,15,433,35),(840,15,432,35),(839,15,431,35),(838,15,430,35),(837,15,377,30),(836,15,376,30),(835,15,375,30),(834,15,374,30),(833,15,373,30),(832,15,372,30),(831,15,371,30),(830,15,370,30),(829,15,369,30),(828,15,368,30),(827,15,367,30),(826,15,366,30);
/*!40000 ALTER TABLE `999_menu_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_moui_setting`
--

DROP TABLE IF EXISTS `999_moui_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_moui_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `show_style` text NOT NULL COMMENT '显示的项目集合',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_moui_setting`
--

LOCK TABLES `999_moui_setting` WRITE;
/*!40000 ALTER TABLE `999_moui_setting` DISABLE KEYS */;
INSERT INTO `999_moui_setting` (`id`, `show_style`) VALUES (1,'[\"progress_1\",\"progress_2\",\"progress_3\",\"progress_4\",\"mulit\"]');
/*!40000 ALTER TABLE `999_moui_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_order`
--

DROP TABLE IF EXISTS `999_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(100) NOT NULL,
  `order_status` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `user_randid` varchar(100) NOT NULL COMMENT '随机的用户ID',
  `order_amount` decimal(10,2) NOT NULL COMMENT '订单价格',
  `order_step` tinyint(1) NOT NULL DEFAULT '1' COMMENT '訂單的緊急情況',
  `pay_id` int(11) NOT NULL COMMENT '支付方式',
  `pay_time` int(11) NOT NULL COMMENT '支付时间',
  `order_remark` text NOT NULL,
  `desk_name` varchar(200) NOT NULL COMMENT '台号',
  `desk_id` int(11) NOT NULL COMMENT '台面ID',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_order`
--

LOCK TABLES `999_order` WRITE;
/*!40000 ALTER TABLE `999_order` DISABLE KEYS */;
INSERT INTO `999_order` (`order_id`, `order_sn`, `order_status`, `add_time`, `user_randid`, `order_amount`, `order_step`, `pay_id`, `pay_time`, `order_remark`, `desk_name`, `desk_id`) VALUES (1,'A00001',2,1465872527,'',60.00,4,0,1465872533,'','1',1),(2,'A00002',2,1465872541,'',85.00,4,0,1465872541,'','3',10),(3,'A00003',2,1465872548,'',37.00,4,0,1465872548,'','2',2),(4,'A00004',2,1465872555,'',90.00,4,0,1465872555,'','11',18),(5,'A00005',2,1465872565,'',37.00,4,0,1465872565,'','16',23),(6,'A00006',2,1465872584,'',60.00,4,0,1465872584,'','12',19),(7,'A00007',2,1465872593,'',130.00,4,0,1465872593,'','1',1),(8,'A00008',2,1465872605,'',73.00,4,0,1465872605,'','1',1),(9,'A00009',2,1465872614,'',110.00,4,0,1465872614,'','7',14),(10,'A00010',2,1465872629,'',205.00,4,0,1465872629,'','13',20),(11,'A00011',0,1466476663,'',60.00,4,0,0,'','6',13),(12,'A00012',0,1466476685,'',49.00,4,0,0,'','外卖',-1),(13,'A00013',0,1466476745,'',50.00,4,0,0,'','外卖',-1),(14,'A00014',2,1476433075,'',304.00,4,0,1476868931,'','1',1),(15,'A00015',2,1476433137,'',86.00,4,0,1476696185,'','16',23),(16,'A00016',2,1476433157,'',285.00,4,0,1476696502,'','1a',6),(17,'A00017',2,1476433164,'',123.00,4,0,1476696195,'','4',11),(18,'A00018',2,1476673919,'',285.00,4,0,1476696227,'','1c',8),(19,'A00019',2,1476674331,'',250.00,4,0,1476696486,'','5',12),(20,'A00020',2,1476696189,'',20.00,4,0,1476696189,'','9',16),(21,'A00021',2,1476881508,'',48.00,4,0,1476881599,'','5',12),(22,'1477098043',0,1477098043,'',20.00,4,2,0,'','',0),(23,'A00023',0,1479106628,'',20.00,4,0,0,'','10',17),(24,'A00024',0,1479358466,'',80.00,1,0,0,'','1b',7),(25,'A00025',0,1479358486,'',78.00,1,0,0,'','3',10),(26,'A00026',0,1479358494,'',80.00,1,0,0,'','16',23),(27,'A00027',0,1479358500,'',41.00,1,0,0,'','8',15),(28,'A00028',2,1484723388,'',98.00,1,0,1484733073,'','1',1),(29,'A00029',0,1484723619,'',390.00,1,0,0,'','2',2),(30,'A00030',0,1484723625,'',44.00,1,0,0,'','1a',6),(31,'A00031',0,1484723752,'',53.00,1,0,0,'','1c',8);
/*!40000 ALTER TABLE `999_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_order_product`
--

DROP TABLE IF EXISTS `999_order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_order_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_sn` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL COMMENT '最终的单价',
  `product_goodsnumber` int(11) NOT NULL,
  `product_attribute` text NOT NULL COMMENT '商品屬性（放字符串）',
  `attr` text NOT NULL COMMENT '保存产品的属性的数据',
  `product_step` varchar(200) NOT NULL COMMENT '緊急程度',
  `chengben` decimal(10,2) NOT NULL,
  `cat_id` int(11) NOT NULL COMMENT '分类ID',
  `product_done` tinyint(1) NOT NULL,
  `current_step` smallint(4) NOT NULL COMMENT '当前步骤',
  `is_setmeal_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否套餐内的产品',
  `setmeal_id` int(11) NOT NULL COMMENT '套餐ID',
  `is_time_price` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否时价',
  `time_price` decimal(10,1) NOT NULL,
  `buycount` int(11) NOT NULL COMMENT '购买数量',
  `item_total` int(11) NOT NULL COMMENT '该产品的总价格',
  `hitmeal` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否撞餐',
  `hitmeal_price` decimal(10,1) NOT NULL COMMENT '撞餐后的价格',
  `msg` varchar(200) NOT NULL COMMENT '撞餐后的提示文字',
  `setmeal_select` text NOT NULL COMMENT '选择套餐的数据（json）',
  `jump` tinyint(4) NOT NULL,
  `jumpprice` decimal(10,1) NOT NULL,
  `price` decimal(10,1) NOT NULL COMMENT '原价',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `order_id_2` (`order_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=191 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_order_product`
--

LOCK TABLES `999_order_product` WRITE;
/*!40000 ALTER TABLE `999_order_product` DISABLE KEYS */;
INSERT INTO `999_order_product` (`id`, `order_id`, `order_sn`, `product_id`, `product_name`, `product_price`, `product_goodsnumber`, `product_attribute`, `attr`, `product_step`, `chengben`, `cat_id`, `product_done`, `current_step`, `is_setmeal_product`, `setmeal_id`, `is_time_price`, `time_price`, `buycount`, `item_total`, `hitmeal`, `hitmeal_price`, `msg`, `setmeal_select`, `jump`, `jumpprice`, `price`) VALUES (1,1,'',306,'炒蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(2,1,'',308,'煎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(3,1,'',323,'奶昔多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(4,2,'',391,'牛扒',40.00,1,'','[]','4',35.00,31,0,0,0,0,0,0.0,1,40,0,0.0,'','',0,0.0,40.0),(5,2,'',394,'漢堡扒',15.00,1,'','[]','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(6,2,'',389,'豬扒',30.00,1,'','[]','4',25.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(7,3,'',444,'鮮奶',8.00,1,'','[]','4',3.00,35,0,0,0,0,0,0.0,1,8,0,0.0,'','',0,0.0,8.0),(8,3,'',437,'朱古力',11.00,1,'','[]','4',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(9,3,'',432,'香滑鴛鴦',18.00,1,'','[]','4',13.00,35,0,0,0,0,0,0.0,1,18,0,0.0,'','',0,0.0,18.0),(10,4,'',321,'牛油多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(11,4,'',321,'牛油多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(12,4,'',328,'法兰西多士',30.00,1,'','[]','4',11.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(13,4,'',322,'奶油多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(14,5,'',437,'朱古力',11.00,1,'','[]','4',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(15,5,'',444,'鮮奶',8.00,1,'','[]','4',3.00,35,0,0,0,0,0,0.0,1,8,0,0.0,'','',0,0.0,8.0),(16,5,'',432,'香滑鴛鴦',18.00,1,'','[]','4',13.00,35,0,0,0,0,0,0.0,1,18,0,0.0,'','',0,0.0,18.0),(17,6,'',307,'太阳蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(18,6,'',309,'熟蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(19,6,'',311,'什菌炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(20,7,'',327,'鲜油多士',30.00,1,'','[]','4',12.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(21,7,'',323,'奶昔多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(22,7,'',325,'油占多士',30.00,1,'','[]','4',15.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(23,7,'',326,'油酱多士',30.00,1,'','[]','4',11.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(24,7,'',324,'占酱多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(25,8,'',402,'午餐肉',15.00,1,'','[]','4',10.00,33,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(26,8,'',415,'豬肉丸',11.00,1,'','[]','4',6.00,33,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(27,8,'',403,'五香肉丁',17.00,1,'','[]','4',12.00,33,0,0,0,0,0,0.0,1,17,0,0.0,'','',0,0.0,17.0),(28,8,'',410,'炸菜肉絲',20.00,1,'','[]','4',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(29,8,'',398,'腸仔',10.00,1,'','[]','4',5.00,33,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(30,9,'',319,'火腿麦皮',30.00,1,'','[]','4',10.00,24,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(31,9,'',320,'鲜奶麦皮',20.00,1,'','[]','4',10.00,24,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(32,9,'',317,'牛奶麦皮',30.00,1,'','[]','4',15.00,24,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(33,9,'',318,'窝蛋麦皮',30.00,1,'','[]','4',10.00,24,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(34,10,'',396,'鮮什菌',10.00,1,'','[]','4',5.00,31,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(35,10,'',390,'雞扒',30.00,1,'','[]','4',25.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(36,10,'',397,'吉列魚柳',35.00,1,'','[]','4',30.00,31,0,0,0,0,0,0.0,1,35,0,0.0,'','',0,0.0,35.0),(37,10,'',391,'牛扒',40.00,1,'','[]','4',35.00,31,0,0,0,0,0,0.0,1,40,0,0.0,'','',0,0.0,40.0),(38,10,'',393,'西冷牛扒',45.00,1,'','[]','4',40.00,31,0,0,0,0,0,0.0,1,45,0,0.0,'','',0,0.0,45.0),(39,10,'',395,'豬柳',15.00,1,'','[]','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(40,10,'',389,'豬扒',30.00,1,'','[]','4',25.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(132,22,'',308,'煎蛋',20.00,1,'','','4',10.00,22,0,0,0,0,0,0.0,0,0,0,0.0,'','',0,0.0,0.0),(133,23,'',413,'觧牛肉',20.00,1,'','[]','4',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(134,24,'',309,'熟蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(44,12,'',440,'檸檬水',11.00,1,'','[]','4',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(45,12,'',434,'檸啡',15.00,1,'','[]','4',10.00,35,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(46,12,'',435,'阿華田',10.00,1,'','[]','4',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(47,12,'',441,'西洋菜蜜',13.00,1,'','[]','4',8.00,35,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(48,13,'',321,'牛油多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(49,13,'',328,'法兰西多士',30.00,1,'','[]','4',11.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(50,14,'',323,'奶昔多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(51,14,'',325,'油占多士',30.00,1,'','[]','4',15.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(52,14,'',396,'鮮什菌',10.00,1,'','[]','4',5.00,31,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(53,14,'',392,'吉列豬扒',35.00,1,'','[]','4',30.00,31,0,0,0,0,0,0.0,1,35,0,0.0,'','',0,0.0,35.0),(54,14,'',394,'漢堡扒',15.00,1,'','[]','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(55,14,'',391,'牛扒',40.00,1,'','[]','4',35.00,31,0,0,0,0,0,0.0,1,40,0,0.0,'','',0,0.0,40.0),(56,14,'',461,'柑桔檸蜜',15.00,1,'','[]','4',10.00,38,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(57,14,'',468,'話梅可樂',13.00,1,'','[]','4',8.00,38,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(58,14,'',467,'川貝杏仁茶',18.00,1,'','[]','4',13.00,38,0,0,0,0,0,0.0,1,18,0,0.0,'','',0,0.0,18.0),(59,14,'',460,'柑桔蜜',11.00,1,'','[]','4',6.00,38,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(60,14,'',457,'柚子茶',10.00,1,'','[]','4',5.00,38,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(61,14,'',458,'生薑茶',10.00,1,'','[]','4',5.00,38,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(62,14,'',459,'柚子蜜',11.00,1,'','[]','4',6.00,38,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(63,14,'',474,'茶走(煉奶)',1.00,1,'','[]','4',1.00,39,0,0,0,0,0,0.0,1,1,0,0.0,'','',0,0.0,1.0),(64,14,'',471,'熱飲',3.00,1,'','[]','4',2.00,39,0,0,0,0,0,0.0,1,3,0,0.0,'','',0,0.0,3.0),(65,14,'',473,'少冰',2.00,1,'','[]','4',1.00,39,0,0,0,0,0,0.0,1,2,0,0.0,'','',0,0.0,2.0),(66,14,'',311,'什菌炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(67,14,'',309,'熟蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(68,14,'',307,'太阳蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(69,15,'',326,'油酱多士',30.00,1,'','[]','4',11.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(70,15,'',308,'煎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(71,15,'',395,'豬柳',15.00,1,'','[]','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(72,15,'',435,'阿華田',10.00,1,'','[]','4',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(73,15,'',460,'柑桔蜜',11.00,1,'','[]','4',6.00,38,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(74,16,'',311,'什菌炒蛋',20.00,1,'','','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(75,16,'',328,'法兰西多士',30.00,1,'','','4',11.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(76,16,'',323,'奶昔多士',20.00,1,'','','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(77,16,'',396,'鮮什菌',10.00,1,'','','4',5.00,31,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(78,16,'',433,'香滑奶茶',15.00,1,'','','4',10.00,35,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(79,16,'',450,'忌廉',10.00,1,'','','4',5.00,36,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(80,17,'',310,'碎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(81,17,'',392,'吉列豬扒',35.00,1,'','[]','4',30.00,31,0,0,0,0,0,0.0,1,35,0,0.0,'','',0,0.0,35.0),(82,17,'',389,'豬扒',30.00,1,'','[]','4',25.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(83,17,'',438,'杏仁霜',12.00,1,'','[]','4',7.00,35,0,0,0,0,0,0.0,1,12,0,0.0,'','',0,0.0,12.0),(84,17,'',440,'檸檬水',11.00,1,'','[]','4',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(85,17,'',434,'檸啡',15.00,1,'','[]','4',10.00,35,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(86,18,'',389,'豬扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(87,18,'',395,'豬柳',15.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(88,18,'',390,'雞扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(89,18,'',390,'雞扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(90,18,'',395,'豬柳',15.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(91,18,'',395,'豬柳',15.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(92,18,'',389,'豬扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(93,18,'',389,'豬扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(94,18,'',389,'豬扒',30.00,1,'','[]','4',0.00,31,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(95,18,'',307,'太阳蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(96,18,'',306,'炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(97,18,'',309,'熟蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(98,19,'',306,'炒蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(99,19,'',310,'碎蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(100,19,'',307,'太阳蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(101,19,'',415,'豬肉丸',11.00,1,'','[]','4',0.00,33,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(102,19,'',414,'豬頸肉',23.00,1,'','[]','4',0.00,33,0,0,0,0,0,0.0,1,23,0,0.0,'','',0,0.0,23.0),(103,19,'',306,'炒蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(104,19,'',309,'熟蛋',20.00,1,'','[]','4',0.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(105,19,'',323,'奶昔多士',20.00,1,'','[]','4',0.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(106,19,'',323,'奶昔多士',20.00,1,'','[]','4',0.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(107,19,'',324,'占酱多士',20.00,1,'','[]','4',0.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(108,19,'',326,'油酱多士',30.00,1,'','[]','4',0.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(109,19,'',457,'柚子茶',10.00,1,'','[]','4',0.00,38,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(110,19,'',468,'話梅可樂',13.00,1,'','[]','4',0.00,38,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(111,19,'',472,'少甜',1.00,1,'','[]','4',0.00,39,0,0,0,0,0,0.0,1,1,0,0.0,'','',0,0.0,1.0),(112,19,'',473,'少冰',2.00,1,'','[]','4',0.00,39,0,0,0,0,0,0.0,1,2,0,0.0,'','',0,0.0,2.0),(113,20,'',323,'奶昔多士',20.00,1,'','[]','4',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(114,16,'',308,'煎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(115,16,'',308,'煎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(116,16,'',308,'煎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(117,16,'',307,'太阳蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(118,16,'',306,'炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(119,16,'',306,'炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(120,16,'',306,'炒蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(121,16,'',309,'熟蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(122,16,'',310,'碎蛋',20.00,1,'','[]','4',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(131,21,'',432,'香滑鴛鴦',18.00,1,'','[]','4',0.00,35,0,0,0,0,0,0.0,1,18,0,0.0,'','',0,0.0,18.0),(135,24,'',310,'碎蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(136,24,'',308,'煎蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(137,24,'',306,'炒蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(128,21,'',394,'漢堡扒',15.00,1,'','','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(138,25,'',423,'公仔麵',10.00,1,'','[]','1',5.00,34,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(130,21,'',394,'漢堡扒',15.00,1,'','','4',10.00,31,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(139,25,'',417,'米粉',13.00,1,'','[]','1',8.00,34,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(140,25,'',424,'螺絲粉',13.00,1,'','[]','1',8.00,34,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(141,25,'',418,'米線',11.00,1,'','[]','1',6.00,34,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(142,25,'',415,'豬肉丸',11.00,1,'','[]','1',6.00,33,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(143,25,'',410,'炸菜肉絲',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(144,26,'',322,'奶油多士',20.00,1,'','[]','1',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(145,26,'',423,'公仔麵',10.00,1,'','[]','1',5.00,34,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(146,26,'',407,'鮑魚絲',15.00,1,'','[]','1',10.00,33,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(147,26,'',402,'午餐肉',15.00,1,'','[]','1',10.00,33,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(148,26,'',404,'雞翼',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(149,27,'',444,'鮮奶',8.00,1,'','[]','1',3.00,35,0,0,0,0,0,0.0,1,8,0,0.0,'','',0,0.0,8.0),(150,27,'',439,'檸檬茶',13.00,1,'','[]','1',8.00,35,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(151,27,'',435,'阿華田',10.00,1,'','[]','1',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(152,27,'',436,'好立克',10.00,1,'','[]','1',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(153,28,'',421,'意粉',12.00,1,'','[]','1',7.00,34,0,0,0,0,0,0.0,1,12,0,0.0,'','',0,0.0,12.0),(154,28,'',422,'烏冬',13.00,1,'','[]','1',8.00,34,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(155,28,'',422,'烏冬',13.00,1,'','[]','1',8.00,34,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(156,28,'',416,'出前一丁',15.00,1,'','[]','1',10.00,34,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(157,28,'',423,'公仔麵',10.00,1,'','[]','1',5.00,34,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(158,28,'',424,'螺絲粉',13.00,1,'','[]','1',8.00,34,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(159,28,'',419,'河粉',11.00,1,'','[]','1',6.00,34,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(160,28,'',419,'河粉',11.00,1,'','[]','1',6.00,34,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(161,29,'',430,'西冷紅茶',10.00,1,'','[]','1',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(162,29,'',437,'朱古力',11.00,1,'','[]','1',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(163,29,'',437,'朱古力',11.00,1,'','[]','1',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(164,29,'',438,'杏仁霜',12.00,1,'','[]','1',7.00,35,0,0,0,0,0,0.0,1,12,0,0.0,'','',0,0.0,12.0),(165,29,'',432,'香滑鴛鴦',18.00,1,'','[]','1',13.00,35,0,0,0,0,0,0.0,1,18,0,0.0,'','',0,0.0,18.0),(166,29,'',327,'鲜油多士',30.00,1,'','[]','1',12.00,25,0,0,0,0,0,0.0,1,30,0,0.0,'','',0,0.0,30.0),(167,29,'',322,'奶油多士',20.00,1,'','[]','1',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(168,29,'',321,'牛油多士',20.00,1,'','[]','1',10.00,25,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(169,29,'',309,'熟蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(170,29,'',310,'碎蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(171,29,'',311,'什菌炒蛋',20.00,1,'','[]','1',10.00,22,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(172,29,'',399,'司華力腸',12.00,1,'','[]','1',7.00,33,0,0,0,0,0,0.0,1,12,0,0.0,'','',0,0.0,12.0),(173,29,'',406,'煙鴨胸',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(174,29,'',407,'鮑魚絲',15.00,1,'','[]','1',10.00,33,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(175,29,'',402,'午餐肉',15.00,1,'','[]','1',10.00,33,0,0,0,0,0,0.0,1,15,0,0.0,'','',0,0.0,15.0),(176,29,'',409,'雪菜肉絲',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(177,29,'',410,'炸菜肉絲',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(178,29,'',408,'鹹牛肉',20.00,1,'','[]','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0),(179,29,'',412,'回鍋肉',21.00,1,'','[]','1',16.00,33,0,0,0,0,0,0.0,1,21,0,0.0,'','',0,0.0,21.0),(180,29,'',398,'腸仔',10.00,1,'','[]','1',5.00,33,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(181,29,'',398,'腸仔',10.00,1,'','[]','1',5.00,33,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(182,29,'',411,'沙嗲牛肉',23.00,1,'','[]','1',18.00,33,0,0,0,0,0,0.0,1,23,0,0.0,'','',0,0.0,23.0),(183,29,'',399,'司華力腸',12.00,1,'','[]','1',7.00,33,0,0,0,0,0,0.0,1,12,0,0.0,'','',0,0.0,12.0),(184,30,'',440,'檸檬水',11.00,1,'','[]','1',6.00,35,0,0,0,0,0,0.0,1,11,0,0.0,'','',0,0.0,11.0),(185,30,'',441,'西洋菜蜜',13.00,1,'','[]','1',8.00,35,0,0,0,0,0,0.0,1,13,0,0.0,'','',0,0.0,13.0),(186,30,'',442,'利賓立',10.00,1,'','[]','1',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(187,30,'',430,'西冷紅茶',10.00,1,'','[]','1',5.00,35,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(188,31,'',401,'火腿',10.00,1,'','','1',5.00,33,0,0,0,0,0,0.0,1,10,0,0.0,'','',0,0.0,10.0),(189,31,'',414,'豬頸肉',23.00,1,'','','1',18.00,33,0,0,0,0,0,0.0,1,23,0,0.0,'','',0,0.0,23.0),(190,31,'',408,'鹹牛肉',20.00,1,'','','1',15.00,33,0,0,0,0,0,0.0,1,20,0,0.0,'','',0,0.0,20.0);
/*!40000 ALTER TABLE `999_order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_payment`
--

DROP TABLE IF EXISTS `999_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_payment` (
  `pay_id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `pay_code` varchar(20) NOT NULL DEFAULT '',
  `pay_name` varchar(120) NOT NULL DEFAULT '',
  `pay_fee` varchar(10) NOT NULL DEFAULT '0',
  `pay_desc` text NOT NULL,
  `pay_order` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `pay_config` text NOT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_online` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pay_id`),
  UNIQUE KEY `pay_code` (`pay_code`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_payment`
--

LOCK TABLES `999_payment` WRITE;
/*!40000 ALTER TABLE `999_payment` DISABLE KEYS */;
INSERT INTO `999_payment` (`pay_id`, `pay_code`, `pay_name`, `pay_fee`, `pay_desc`, `pay_order`, `pay_config`, `enabled`, `is_online`) VALUES (1,'alipay','支付宝','0','',20,'{\"pay_id\":\"1\",\"account\":\"372325095@qq.com\",\"key\":\"123123123\",\"partnerid\":\"123123123123123\",\"pay_order\":\"20\",\"interface\":\"1\",\"enabled\":\"1\"}',1,1),(2,'offlinepay','线下支付','0','',40,'{\"pay_id\":\"2\",\"enabled\":\"1\",\"pay_order\":\"40\"}',1,0),(4,'wechatpay','微信支付','0','',30,'{\"pay_id\":\"4\",\"appid\":\"appid\",\"appsecret\":\"appsecret\",\"wechattype\":\"2\",\"pay_order\":\"30\",\"enabled\":\"1\"}',1,1),(5,'paypal','paypal','0','',0,'{\"pay_id\":\"5\",\"account\":\"2222222222222\",\"huobi\":\"6\",\"pay_order\":\"0\",\"enabled\":\"0\"}',1,1);
/*!40000 ALTER TABLE `999_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_product`
--

DROP TABLE IF EXISTS `999_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,1) NOT NULL,
  `image_link` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `chengben` double(10,1) NOT NULL,
  `goodsnumber` int(11) NOT NULL,
  `goodsn` varchar(100) NOT NULL,
  `product_attribute` text NOT NULL COMMENT '商品屬性(放JSON)',
  `product_time_one` int(11) NOT NULL COMMENT '緊急程度時間_第一步(已分為單位)',
  `product_time_two` int(11) NOT NULL COMMENT '緊急程度時間_第二步(已分為單位)',
  `product_time_three` int(11) NOT NULL COMMENT '緊急程度時間_第三步(已分為單位)',
  `is_online` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上線',
  `limitime` varchar(100) NOT NULL,
  `more_price` text NOT NULL COMMENT '产品其他的价格(json)',
  `setmeal_id` int(11) NOT NULL DEFAULT '0' COMMENT '套餐ID',
  `is_time_price` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否时价',
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=476 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_product`
--

LOCK TABLES `999_product` WRITE;
/*!40000 ALTER TABLE `999_product` DISABLE KEYS */;
INSERT INTO `999_product` (`product_id`, `cat_id`, `description`, `price`, `image_link`, `product_name`, `chengben`, `goodsnumber`, `goodsn`, `product_attribute`, `product_time_one`, `product_time_two`, `product_time_three`, `is_online`, `limitime`, `more_price`, `setmeal_id`, `is_time_price`) VALUES (358,28,'',30.0,'','火腿蛋治',12.0,123123,'A000000358','',660,1320,1980,1,'44','',0,0),(359,28,'',30.0,'','咸牛肉蛋治',12.0,123123,'A000000359','',660,1320,1980,1,'44','',0,0),(352,27,'',40.0,'','吞拿鱼三文治',20.0,12321,'A000000352','',300,600,900,1,'20','',0,0),(353,28,'',20.0,'','猪柳蛋治',10.0,0,'A000000353','',165,330,495,1,'11','',0,0),(354,28,'',30.0,'','芝士火腿治',12.0,1212323,'A000000354','',660,1320,1980,1,'44','',0,0),(355,28,'',30.0,'','芝士餐肉治',12.0,12312,'A000000355','',660,1320,1980,1,'44','',0,0),(356,28,'',30.0,'','芝士蛋治',12.0,12123,'A000000356','',660,1320,1980,1,'44','',0,0),(357,28,'',30.0,'','餐肉蛋治',12.0,123123,'A000000357','',660,1320,1980,1,'44','',0,0),(351,27,'',38.0,'','餐肉三文治',12.0,12312,'A000000351','',300,600,900,1,'20','',0,0),(350,27,'',35.0,'','咸牛肉三文治',29.0,12332,'A000000350','',300,600,900,1,'20','',0,0),(349,27,'',20.0,'','芝士三文治',18.0,12312,'A000000349','',180,360,540,1,'12','',0,0),(348,27,'',40.0,'','腌肉三文治',2.0,12323,'A000000348','',180,360,540,1,'12','',0,0),(347,27,'',30.0,'','火腿三文治',10.0,12313,'A000000347','',300,600,900,1,'20','',0,0),(346,27,'',40.0,'','鸡蛋三文治',12.0,12322,'A000000346','',180,360,540,1,'12','',0,0),(345,27,'',30.0,'','猪扒三文治',11.0,123123,'A000000345','',300,600,900,1,'20','',0,0),(344,26,'',30.0,'','朱古力飞碟',12.0,123123,'A000000344','',300,600,900,1,'20','',0,0),(339,26,'',20.0,'','肠仔飞碟',10.0,123,'A000000339','',300,600,900,1,'20','',0,0),(340,26,'',20.0,'','吞拿鱼飞碟',10.0,123123,'A000000340','',180,360,540,1,'12','',0,0),(341,26,'',20.0,'','芝士飞碟',10.0,1232,'A000000341','',180,360,540,1,'12','',0,0),(342,26,'',30.0,'','火腿飞碟',11.0,123123,'A000000342','',180,360,540,1,'12','',0,0),(343,26,'',39.0,'','果占飞碟',12.0,123123,'A000000343','',180,360,540,1,'12','',0,0),(338,25,'',20.0,'','牛油厚多士',12.0,121231,'A000000338','',180,360,540,1,'12','',0,0),(337,25,'',15.0,'','占酱厚多士',1.0,123,'A000000337','',180,360,540,1,'12','',0,0),(336,25,'',20.0,'','油酱厚多士',10.0,12312,'A000000336','',180,360,540,1,'12','',0,0),(335,25,'',30.0,'','奶油厚多士',12.0,123123,'A000000335','',165,330,495,1,'11','',0,0),(334,25,'',30.0,'','油占厚多士',12.0,123123,'A000000334','',180,360,540,1,'12','',0,0),(333,25,'',30.0,'','花生酱西多士',12.0,123123,'A000000333','',165,330,495,1,'11','',0,0),(332,25,'',30.0,'','咖央酱多士',12.0,123123,'A000000332','',180,360,540,1,'12','',0,0),(331,25,'',20.0,'','果酱西多士',12.0,123123,'A000000331','',180,360,540,1,'12','',0,0),(330,25,'',30.0,'','芝士西多士',12.0,12321,'A000000330','',180,360,540,1,'12','',0,0),(329,25,'',30.0,'','火腿西多士',12.0,123123,'A000000329','',180,360,540,1,'12','',0,0),(328,25,'',30.0,'','法兰西多士',11.0,123116,'A000000328','',165,330,495,1,'11','',0,0),(327,25,'',30.0,'','鲜油多士',12.0,123119,'A000000327','',165,330,495,1,'11','',0,0),(325,25,'',30.0,'','油占多士',15.0,123119,'A000000325','',180,360,540,1,'12','',0,0),(326,25,'',30.0,'','油酱多士',11.0,111120,'A000000326','',165,330,495,1,'11','',0,0),(319,24,'',30.0,'','火腿麦皮',10.0,1110,'A000000319','',165,330,495,1,'11','',0,0),(320,24,'',20.0,'','鲜奶麦皮',10.0,11109,'A000000320','',180,360,540,1,'12','',0,0),(321,25,'',20.0,'','牛油多士',10.0,11101,'A000000321','',180,360,540,1,'12','',0,0),(322,25,'',20.0,'','奶油多士',10.0,11105,'A000000322','',180,360,540,1,'12','',0,0),(323,25,'',20.0,'','奶昔多士',10.0,103,'A000000323','',180,360,540,1,'12','',0,0),(324,25,'',20.0,'','占酱多士',10.0,1109,'A000000324','',180,360,540,1,'12','',0,0),(309,22,'',20.0,'','熟蛋',10.0,1100,'A000000309','',180,360,540,1,'12','',0,0),(310,22,'',20.0,'','碎蛋',10.0,101,'A000000310','',180,360,540,1,'12','',0,0),(311,22,'',20.0,'','什菌炒蛋',10.0,11102,'A000000311','',180,360,540,1,'12','',0,0),(312,23,'',20.0,'','腌肉腌列',10.0,1111,'A000000312','',180,360,540,1,'12','',0,0),(313,23,'',20.0,'','肠仔腌列',10.0,1111,'A000000313','',180,360,540,1,'12','',0,0),(314,23,'',29.0,'','火腿腌列',19.0,11111,'A000000314','',180,360,540,1,'12','',0,0),(315,23,'',20.0,'','鲜牛肉腌列',10.0,1111,'A000000315','',180,360,540,1,'12','',0,0),(316,23,'',20.0,'','餐肉腌列',10.0,111,'A000000316','',180,360,540,1,'12','',0,0),(317,24,'',30.0,'','牛奶麦皮',15.0,109999,'A000000317','',180,360,540,1,'12','',0,0),(318,24,'',30.0,'','窝蛋麦皮',10.0,101110,'A000000318','',180,360,540,1,'12','',0,0),(308,22,'',20.0,'','煎蛋',10.0,1091,'A000000308','',180,360,540,1,'12','',0,0),(307,22,'',20.0,'','太阳蛋',10.0,11100,'A000000307','',180,360,540,1,'12','',0,0),(306,22,'',20.0,'','炒蛋',10.0,111093,'A000000306','',180,360,540,1,'12','',0,0),(360,28,'',30.0,'','鲜碎肉蛋治',12.0,123123,'A000000360','',660,1320,1980,1,'44','',0,0),(361,28,'',30.0,'','餐腿治',12.0,123123,'A000000361','',660,1320,1980,1,'44','',0,0),(362,28,'',30.0,'','鲜茄蛋治',12.0,123123,'A000000362','',660,1320,1980,1,'44','',0,0),(363,28,'',30.0,'','公司三文治',12.0,12312312,'A000000363','',660,1320,1980,1,'44','',0,0),(364,29,'',30.0,'','烘底',12.0,12313,'A000000364','',165,330,495,1,'11','',0,0),(365,30,'',12.0,'','鲜油菠萝包',5.0,123213,'A000000365','',180,360,540,1,'12','',0,0),(366,30,'',12.0,'','猪扒脆包',1.0,123123,'A000000366','',165,330,495,1,'11','',0,0),(367,30,'',12.0,'','鱼柳脆包',1.0,123,'A000000367','',0,0,0,1,'12','',0,0),(368,30,'',12.0,'','热狗脆包',1.0,12312,'A000000368','',0,0,0,1,'12','',0,0),(369,30,'',12.0,'','牛油猪仔脆包',1.0,123123,'A000000369','',0,0,0,1,'12','',0,0),(370,30,'',12.0,'','果占猪仔脆包',1.0,12310,'A000000370','',120,240,360,1,'8','',0,0),(371,30,'',12.0,'','奶酱猪仔脆包',1.0,123,'A000000371','',120,240,360,1,'8','',0,0),(372,30,'',12.0,'','奶油猪仔脆包',1.0,122,'A000000372','',120,240,360,1,'8','',0,0),(373,30,'',12.0,'','鲜油猪仔脆包',1.0,123213,'A000000373','',120,240,360,1,'8','',0,0),(374,30,'',12.0,'','鲜牛油火腿脆包',1.0,1233,'A000000374','',120,240,360,1,'8','',0,0),(375,30,'',12.0,'','沙爹牛肉脆包',1.0,123,'A000000375','',120,240,360,1,'8','',0,0),(376,30,'',12.0,'','咸牛肉芝士脆包',1.0,123,'A000000376','',120,240,360,1,'8','',0,0),(377,30,'',12.0,'','芝士火腿脆包',1.0,123211,'A000000377','',120,240,360,1,'8','',0,0),(378,30,'',12.0,'','鸡扒芝麻包',1.0,12312,'A000000378','',120,240,360,1,'8','',0,0),(379,30,'',12.0,'','沙爹牛肉芝麻包',1.0,0,'A000000379','',120,240,360,1,'8','',0,0),(380,32,'',12.0,'','喊猪仔包',1.0,1232,'A000000380','',120,240,360,1,'8','',0,0),(381,32,'',12.0,'','菠萝包',1.0,122131,'A000000381','',120,240,360,1,'8','',0,0),(382,32,'',22.0,'','鸡尾包',12.0,11123123,'A000000382','',120,240,360,1,'8','',0,0),(383,32,'',22.0,'','肠仔包',10.0,12312312,'A000000383','',120,240,360,1,'8','',0,0),(384,32,'',22.0,'','餐蛋包',10.0,12323,'A000000384','',120,240,360,1,'8','',0,0),(385,32,'',25.0,'','吞拿鱼包',12.0,12323,'A000000385','',120,240,360,1,'8','',0,0),(386,32,'',20.0,'','叉烧包',12.0,123213,'A000000386','',120,240,360,1,'8','',0,0),(387,32,'',20.0,'','蛋挞',10.0,123112,'A000000387','',120,240,360,1,'8','',0,0),(388,32,'',20.0,'','鸡批',10.0,123123,'A000000388','',120,240,360,1,'8','',0,0),(389,31,'',30.0,'','豬扒',25.0,88,'A000000389','',120,240,360,1,'8','',0,0),(390,31,'',30.0,'','雞扒',25.0,94,'A000000390','',120,240,360,1,'8','',0,0),(391,31,'',40.0,'','牛扒',35.0,96,'A000000391','',120,240,360,1,'8','',0,0),(392,31,'',35.0,'','吉列豬扒',30.0,95,'A000000392','',120,240,360,1,'8','',0,0),(393,31,'',45.0,'','西冷牛扒',40.0,99,'A000000393','',120,240,360,1,'8','',0,0),(394,31,'',15.0,'','漢堡扒',10.0,195,'A000000394','',120,240,360,1,'8','',0,0),(395,31,'',15.0,'','豬柳',10.0,195,'A000000395','',120,240,360,1,'8','',0,0),(396,31,'',10.0,'','鮮什菌',5.0,194,'A000000396','',120,240,360,1,'8','',0,0),(397,31,'',35.0,'','吉列魚柳',30.0,97,'A000000397','',120,240,360,1,'8','',0,0),(398,33,'',10.0,'','腸仔',5.0,196,'A000000398','',1200,2400,3600,1,'80','',0,0),(399,33,'',12.0,'','司華力腸',7.0,148,'A000000399','',1200,2400,3600,1,'80','',0,0),(400,33,'',10.0,'','煙肉',5.0,200,'A000000400','',1200,2400,3600,1,'80','',0,0),(401,33,'',10.0,'','火腿',5.0,199,'A000000401','',1200,2400,3600,1,'80','',0,0),(402,33,'',15.0,'','午餐肉',10.0,197,'A000000402','',1200,2400,3600,1,'80','',0,0),(403,33,'',17.0,'','五香肉丁',12.0,98,'A000000403','',1200,2400,3600,1,'80','',0,0),(404,33,'',20.0,'','雞翼',15.0,149,'A000000404','',1200,2400,3600,1,'80','',0,0),(405,33,'',18.0,'','紅腸',13.0,150,'A000000405','',1200,2400,3600,1,'80','',0,0),(406,33,'',20.0,'','煙鴨胸',15.0,99,'A000000406','',1200,2400,3600,1,'80','',0,0),(407,33,'',15.0,'','鮑魚絲',10.0,198,'A000000407','',1200,2400,3600,1,'80','',0,0),(408,33,'',20.0,'','鹹牛肉',15.0,148,'A000000408','',1200,2400,3600,1,'80','',0,0),(409,33,'',20.0,'','雪菜肉絲',15.0,99,'A000000409','',1200,2400,3600,1,'80','',0,0),(410,33,'',20.0,'','炸菜肉絲',15.0,97,'A000000410','',1200,2400,3600,1,'80','',0,0),(411,33,'',23.0,'','沙嗲牛肉',18.0,149,'A000000411','',0,0,0,1,'0','',0,0),(412,33,'',21.0,'','回鍋肉',16.0,199,'A000000412','',1200,2400,3600,1,'80','',0,0),(413,33,'',20.0,'','觧牛肉',15.0,199,'A000000413','',1200,2400,3600,1,'80','',0,0),(414,33,'',23.0,'','豬頸肉',18.0,198,'A000000414','',1200,2400,3600,1,'80','',0,0),(415,33,'',11.0,'','豬肉丸',6.0,247,'A000000415','',1200,2400,3600,1,'80','',0,0),(416,34,'',15.0,'','出前一丁',10.0,299,'A000000416','',1200,2400,3600,1,'80','',0,0),(417,34,'',13.0,'','米粉',8.0,299,'A000000417','',1200,2400,3600,1,'80','',0,0),(418,34,'',11.0,'','米線',6.0,299,'A000000418','',1200,2400,3600,1,'80','',0,0),(419,34,'',11.0,'','河粉',6.0,298,'A000000419','',0,0,0,1,'0','',0,0),(420,34,'',10.0,'','通粉',5.0,299,'A000000420','',1200,2400,3600,1,'80','',0,0),(421,34,'',12.0,'','意粉',7.0,298,'A000000421','',120,240,360,1,'8','',0,0),(422,34,'',13.0,'','烏冬',8.0,248,'A000000422','',120,240,360,1,'8','',0,0),(423,34,'',10.0,'','公仔麵',5.0,297,'A000000423','',120,240,360,1,'8','',0,0),(424,34,'',13.0,'','螺絲粉',8.0,298,'A000000424','',120,240,360,1,'8','',0,0),(425,34,'',20.0,'','蘑菇肉碎通粉',15.0,150,'A000000425','',120,240,360,1,'8','',0,0),(426,34,'',23.0,'','雙蛋公仔麵',18.0,150,'A000000426','',1500,3000,4500,1,'100','',0,0),(427,34,'',23.0,'','沙嗲牛肉公仔麵',18.0,150,'A000000427','',1500,3000,4500,1,'100','',0,0),(428,34,'',25.0,'','豬扒公仔麵',20.0,150,'A000000428','',1500,3000,4500,1,'100','',0,0),(429,34,'',25.0,'','雞翼公仔麵',20.0,150,'A000000429','',1500,3000,4500,1,'100','',0,0),(430,35,'',10.0,'','西冷紅茶',5.0,198,'A000000430','',1500,3000,4500,1,'100','',0,0),(431,35,'',15.0,'','香濃咖啡',10.0,198,'A000000431','',1500,3000,4500,1,'100','',0,0),(432,35,'',18.0,'','香滑鴛鴦',13.0,195,'A000000432','',1500,3000,4500,1,'100','',0,0),(433,35,'',15.0,'','香滑奶茶',10.0,197,'A000000433','',1500,3000,4500,1,'100','',0,0),(434,35,'',15.0,'','檸啡',10.0,194,'A000000434','',1500,3000,4500,1,'100','',0,0),(435,35,'',10.0,'','阿華田',5.0,296,'A000000435','',1500,3000,4500,1,'100','',0,0),(436,35,'',10.0,'','好立克',5.0,299,'A000000436','',1500,3000,4500,1,'100','',0,0),(437,35,'',11.0,'','朱古力',6.0,295,'A000000437','',1500,3000,4500,1,'100','',0,0),(438,35,'',12.0,'','杏仁霜',7.0,197,'A000000438','',1500,3000,4500,1,'100','',0,0),(439,35,'',13.0,'','檸檬茶',8.0,197,'A000000439','',1500,3000,4500,1,'100','',0,0),(440,35,'',11.0,'','檸檬水',6.0,195,'A000000440','',1500,3000,4500,1,'100','',0,0),(441,35,'',13.0,'','西洋菜蜜',8.0,195,'A000000441','',1500,3000,4500,1,'100','',0,0),(442,35,'',10.0,'','利賓立',5.0,198,'A000000442','',0,0,0,1,'00','',0,0),(443,35,'',15.0,'','滾水蛋',10.0,149,'A000000443','',1500,3000,4500,1,'100','',0,0),(444,35,'',8.0,'','鮮奶',3.0,242,'A000000444','',1500,3000,4500,1,'100','',0,0),(445,35,'',18.0,'','鮮奶窩蛋',13.0,149,'A000000445','',1500,3000,4500,1,'100','',0,0),(446,36,'',8.0,'','橙汁',3.0,298,'A000000446','',150,300,450,1,'10','',0,0),(447,36,'',10.0,'','雪碧',5.0,299,'A000000447','',150,300,450,1,'10','',0,0),(448,36,'',10.0,'','七喜',5.0,299,'A000000448','',150,300,450,1,'10','',0,0),(449,36,'',11.0,'','可樂',6.0,298,'A000000449','',150,300,450,1,'10','',0,0),(450,36,'',10.0,'','忌廉',5.0,298,'A000000450','',150,300,450,1,'10','',0,0),(451,37,'',15.0,'','紅豆冰',10.0,149,'A000000451','',150,300,450,1,'10','',0,0),(452,37,'',14.0,'','雜果冰',9.0,149,'A000000452','',150,300,450,1,'10','',0,0),(453,37,'',15.0,'','菠蘿冰',10.0,148,'A000000453','',150,300,450,1,'10','',0,0),(454,37,'',15.0,'','涼粉冰',10.0,150,'A000000454','',150,300,450,1,'10','',0,0),(455,37,'',20.0,'','紅豆涼粉冰',15.0,100,'A000000455','',0,0,0,1,'0','',0,0),(456,37,'',19.0,'','雜果涼粉冰',14.0,100,'A000000456','',150,300,450,1,'10','',0,0),(457,38,'',10.0,'','柚子茶',5.0,148,'A000000457','',0,0,0,1,'3','',0,0),(458,38,'',10.0,'','生薑茶',5.0,149,'A000000458','',0,0,0,1,'3','',0,0),(459,38,'',11.0,'','柚子蜜',6.0,149,'A000000459','',0,0,0,1,'3','',0,0),(460,38,'',11.0,'','柑桔蜜',6.0,148,'A000000460','',0,0,0,1,'3','',0,0),(461,38,'',15.0,'','柑桔檸蜜',10.0,99,'A000000461','',0,0,0,1,'3','',0,0),(462,38,'',13.0,'','檸檬可樂',8.0,100,'A000000462','',120,240,360,1,'8','',0,0),(463,38,'',15.0,'','檸檬菜蜜',10.0,100,'A000000463','',120,240,360,1,'8','',0,0),(464,38,'',15.0,'','雜果利賓立',10.0,100,'A000000464','',120,240,360,1,'8','',0,0),(465,38,'',15.0,'','檸檬利賓立',10.0,100,'A000000465','',120,240,360,1,'8','',0,0),(466,38,'',15.0,'','薑煲檸樂',10.0,100,'A000000466','',120,240,360,1,'8','',0,0),(467,38,'',18.0,'','川貝杏仁茶',13.0,99,'A000000467','',120,240,360,1,'8','',0,0),(468,38,'',13.0,'','話梅可樂',8.0,97,'A000000468','',120,240,360,1,'8','',0,0),(469,38,'',10.0,'','羅漢果',5.0,100,'A000000469','',120,240,360,1,'8','',0,0),(470,39,'',2.0,'','冷飲',1.0,100000000,'A000000470','',150,300,450,1,'10','',0,0),(471,39,'',3.0,'','熱飲',2.0,999999999,'A000000471','',150,300,450,1,'10','',0,0),(472,39,'',1.0,'','少甜',1.0,999999,'A000000472','',150,300,450,1,'10','',0,0),(473,39,'',2.0,'','少冰',1.0,9999993,'A000000473','',150,300,450,1,'10','',0,0),(474,39,'',1.0,'','茶走(煉奶)',1.0,99999999,'A000000474','',150,300,450,1,'10','',0,0),(475,26,'',123.0,'','123',123.0,123,'A000000475','',180,360,540,1,'12','',0,0);
/*!40000 ALTER TABLE `999_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_production_remark`
--

DROP TABLE IF EXISTS `999_production_remark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_production_remark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `order_product_id` int(11) NOT NULL COMMENT 'which order product''s remark',
  `remark_step_id` int(11) NOT NULL COMMENT 'step when taking this remark',
  `remark_staff_id` int(11) NOT NULL COMMENT 'staff who create this remark',
  `remark_msg` text COLLATE utf8_bin COMMENT 'remark message content',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_production_remark`
--

LOCK TABLES `999_production_remark` WRITE;
/*!40000 ALTER TABLE `999_production_remark` DISABLE KEYS */;
INSERT INTO `999_production_remark` (`id`, `order_id`, `order_product_id`, `remark_step_id`, `remark_staff_id`, `remark_msg`) VALUES (1,75,561,1,5,'yeah'),(2,87,539,1,5,'move to step 2 '),(3,87,539,2,5,'move to step 3'),(4,87,539,3,5,'moving to step 4'),(5,87,539,4,9,'product done'),(6,88,539,1,5,'00'),(7,88,539,1,5,'00'),(8,88,539,2,5,'from step 2'),(9,91,320,1,5,'finished'),(10,115,308,1,5,'test'),(11,115,308,1,5,'test'),(12,115,392,1,5,'test'),(13,115,308,1,5,'test'),(14,115,392,1,5,'test'),(15,115,444,1,5,'test'),(16,121,346,1,5,'complete');
/*!40000 ALTER TABLE `999_production_remark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_progress`
--

DROP TABLE IF EXISTS `999_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '進度ID',
  `progress_name` varchar(50) NOT NULL COMMENT '進度名稱',
  `progress_color` varchar(50) NOT NULL COMMENT '進度顏色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_progress`
--

LOCK TABLES `999_progress` WRITE;
/*!40000 ALTER TABLE `999_progress` DISABLE KEYS */;
/*!40000 ALTER TABLE `999_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_ruletime`
--

DROP TABLE IF EXISTS `999_ruletime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_ruletime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `startdate` int(11) NOT NULL COMMENT '开始日期',
  `starttime` varchar(20) NOT NULL COMMENT '开始时间',
  `enddate` int(11) NOT NULL COMMENT '结束日期',
  `endtime` varchar(20) NOT NULL COMMENT '结束时间',
  `dayshow` varchar(100) NOT NULL COMMENT '日期显示',
  `is_use` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_ruletime`
--

LOCK TABLES `999_ruletime` WRITE;
/*!40000 ALTER TABLE `999_ruletime` DISABLE KEYS */;
INSERT INTO `999_ruletime` (`id`, `startdate`, `starttime`, `enddate`, `endtime`, `dayshow`, `is_use`) VALUES (4,1458576000,'12:00 AM',1464883200,'11:30 PM','[\"1\",\"1\",\"1\",\"1\",\"1\",\"1\",\"1\"]',1);
/*!40000 ALTER TABLE `999_ruletime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_ruletime_hitmeal`
--

DROP TABLE IF EXISTS `999_ruletime_hitmeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_ruletime_hitmeal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ruletime_id` int(11) NOT NULL COMMENT '时间ID',
  `hitmeal_id` int(11) NOT NULL COMMENT '规则ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_ruletime_hitmeal`
--

LOCK TABLES `999_ruletime_hitmeal` WRITE;
/*!40000 ALTER TABLE `999_ruletime_hitmeal` DISABLE KEYS */;
/*!40000 ALTER TABLE `999_ruletime_hitmeal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_setmeal`
--

DROP TABLE IF EXISTS `999_setmeal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_setmeal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setmeal_name` varchar(200) NOT NULL COMMENT '套餐名',
  `setmeal_price` decimal(10,2) NOT NULL COMMENT '套餐价格',
  `setmeal_options` text NOT NULL COMMENT '套餐设置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_setmeal`
--

LOCK TABLES `999_setmeal` WRITE;
/*!40000 ALTER TABLE `999_setmeal` DISABLE KEYS */;
INSERT INTO `999_setmeal` (`id`, `setmeal_name`, `setmeal_price`, `setmeal_options`) VALUES (8,'刺身套餐',0.00,'');
/*!40000 ALTER TABLE `999_setmeal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_setmeal_category`
--

DROP TABLE IF EXISTS `999_setmeal_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_setmeal_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `setmeal_category_name` varchar(200) NOT NULL,
  `setmeal_category_select_count` int(11) NOT NULL,
  `sort_order` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_setmeal_category`
--

LOCK TABLES `999_setmeal_category` WRITE;
/*!40000 ALTER TABLE `999_setmeal_category` DISABLE KEYS */;
INSERT INTO `999_setmeal_category` (`id`, `setmeal_category_name`, `setmeal_category_select_count`, `sort_order`) VALUES (11,'刺身2',3,100),(10,'刺身1',1,100);
/*!40000 ALTER TABLE `999_setmeal_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_setmeal_category_product`
--

DROP TABLE IF EXISTS `999_setmeal_category_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_setmeal_category_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `price` decimal(10,1) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `setmeal_id` int(11) NOT NULL COMMENT '套餐类别id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_setmeal_category_product`
--

LOCK TABLES `999_setmeal_category_product` WRITE;
/*!40000 ALTER TABLE `999_setmeal_category_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `999_setmeal_category_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_setmeal_category_select`
--

DROP TABLE IF EXISTS `999_setmeal_category_select`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_setmeal_category_select` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setmeal_id` int(11) NOT NULL COMMENT '套餐ID',
  `setmeal_category_id` int(11) NOT NULL COMMENT '套餐类别ID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_setmeal_category_select`
--

LOCK TABLES `999_setmeal_category_select` WRITE;
/*!40000 ALTER TABLE `999_setmeal_category_select` DISABLE KEYS */;
INSERT INTO `999_setmeal_category_select` (`id`, `setmeal_id`, `setmeal_category_id`) VALUES (20,8,10),(19,8,11);
/*!40000 ALTER TABLE `999_setmeal_category_select` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_setting`
--

DROP TABLE IF EXISTS `999_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_setting` (
  `indexlogo` varchar(200) NOT NULL COMMENT '首页LOGO',
  `daohangbackground` varchar(100) NOT NULL COMMENT '导航栏背景色',
  `companybackground` varchar(100) NOT NULL,
  `categorybackground` varchar(200) NOT NULL,
  `daohangtext` varchar(7) NOT NULL,
  `companytext` varchar(7) NOT NULL,
  `categorytext` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_setting`
--

LOCK TABLES `999_setting` WRITE;
/*!40000 ALTER TABLE `999_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `999_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_staff`
--

DROP TABLE IF EXISTS `999_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '職員ID',
  `staff_name` varchar(50) NOT NULL COMMENT '職員用戶名',
  `staff_password` varchar(50) NOT NULL COMMENT '登錄密碼',
  `staff_step` varchar(100) NOT NULL COMMENT '職員程序步驟（放JSON）',
  `name` varchar(200) NOT NULL,
  `logout_limit` int(2) NOT NULL COMMENT 'auto logout time (0 = never, x = hour)',
  `update_notification` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_staff`
--

LOCK TABLES `999_staff` WRITE;
/*!40000 ALTER TABLE `999_staff` DISABLE KEYS */;
INSERT INTO `999_staff` (`id`, `staff_name`, `staff_password`, `staff_step`, `name`, `logout_limit`, `update_notification`) VALUES (5,'staff1','4297f44b13955235245b2497399d7a93','1,2,3','',0,0),(6,'staff2','4297f44b13955235245b2497399d7a93','1','',0,0),(7,'staff3','e10adc3949ba59abbe56e057f20f883e','2,3','',0,1),(10,'staff5','4297f44b13955235245b2497399d7a93','1,2,3,4','',0,1),(9,'staff4','a6507d22fc95521e8fde503e1c032528','1,3,4','s4',0,1),(11,'test','96e79218965eb72c92a549dd5a330112','1,2,3,4','',0,1);
/*!40000 ALTER TABLE `999_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_step`
--

DROP TABLE IF EXISTS `999_step`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_step` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_step`
--

LOCK TABLES `999_step` WRITE;
/*!40000 ALTER TABLE `999_step` DISABLE KEYS */;
INSERT INTO `999_step` (`id`, `name`) VALUES (1,' 下单'),(2,' 程序-2'),(3,'程序3'),(4,'送出');
/*!40000 ALTER TABLE `999_step` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `999_test`
--

DROP TABLE IF EXISTS `999_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `999_test` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `name` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `999_test`
--

LOCK TABLES `999_test` WRITE;
/*!40000 ALTER TABLE `999_test` DISABLE KEYS */;
INSERT INTO `999_test` (`id`, `name`) VALUES (1,'1111'),(2,'1111'),(3,'1111'),(4,'1111'),(5,'1111'),(6,'1111'),(7,'1111'),(8,'1111'),(9,'1111'),(10,'1111'),(11,'1111'),(12,'0'),(13,'1'),(14,'2'),(15,'3'),(16,'4'),(17,'5'),(18,'6'),(19,'7'),(20,'8'),(21,'9'),(22,'10'),(23,'11'),(24,'12'),(25,'13'),(26,'14'),(27,'15'),(28,'16'),(29,'17'),(30,'18'),(31,'19'),(32,'20'),(33,'21'),(34,'22'),(35,'23'),(36,'24'),(37,'25'),(38,'26'),(39,'27'),(40,'28'),(41,'29'),(42,'30'),(43,'31'),(44,'32'),(45,'33'),(46,'34'),(47,'35'),(48,'36'),(49,'37'),(50,'38'),(51,'39'),(52,'40'),(53,'41'),(54,'42'),(55,'43'),(56,'44'),(57,'45'),(58,'46'),(59,'47'),(60,'48'),(61,'49'),(62,'50'),(63,'51'),(64,'52'),(65,'53'),(66,'54'),(67,'55'),(68,'56'),(69,'57'),(70,'58'),(71,'59'),(72,'60'),(73,'61'),(74,'62'),(75,'63'),(76,'64'),(77,'65'),(78,'66'),(79,'67'),(80,'68'),(81,'69'),(82,'70'),(83,'71'),(84,'72'),(85,'73'),(86,'74'),(87,'75'),(88,'76'),(89,'77'),(90,'78'),(91,'79'),(92,'80'),(93,'81'),(94,'82'),(95,'83'),(96,'84'),(97,'85'),(98,'86'),(99,'87'),(100,'88'),(101,'89'),(102,'90'),(103,'91'),(104,'92'),(105,'93'),(106,'94'),(107,'95'),(108,'96'),(109,'97'),(110,'98'),(111,'99'),(112,'100'),(113,'101'),(114,'102'),(115,'103'),(116,'104'),(117,'105'),(118,'106'),(119,'107'),(120,'108'),(121,'109'),(122,'110'),(123,'111'),(124,'112'),(125,'113'),(126,'114'),(127,'115');
/*!40000 ALTER TABLE `999_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ALL_DIRECTORY`
--

DROP TABLE IF EXISTS `ALL_DIRECTORY`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ALL_DIRECTORY` (
  `allID` int(10) NOT NULL AUTO_INCREMENT,
  `allName` varchar(50) CHARACTER SET latin1 NOT NULL,
  `allParent` varchar(100) CHARACTER SET latin1 NOT NULL,
  `allType` varchar(10) CHARACTER SET latin1 NOT NULL,
  `allMode` int(3) NOT NULL,
  `allDirectoryType` int(10) NOT NULL,
  `alluID` varchar(10) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`allID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ALL_DIRECTORY`
--

LOCK TABLES `ALL_DIRECTORY` WRITE;
/*!40000 ALTER TABLE `ALL_DIRECTORY` DISABLE KEYS */;
/*!40000 ALTER TABLE `ALL_DIRECTORY` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DA_USER`
--

DROP TABLE IF EXISTS `DA_USER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DA_USER` (
  `uID` int(10) NOT NULL AUTO_INCREMENT,
  `uName` varchar(50) CHARACTER SET latin1 NOT NULL,
  `uPassword` varchar(20) CHARACTER SET latin1 NOT NULL,
  `uLocation` varchar(10) CHARACTER SET latin1 NOT NULL,
  `uPermission` varchar(10) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`uID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DA_USER`
--

LOCK TABLES `DA_USER` WRITE;
/*!40000 ALTER TABLE `DA_USER` DISABLE KEYS */;
INSERT INTO `DA_USER` (`uID`, `uName`, `uPassword`, `uLocation`, `uPermission`) VALUES (1,'modern','abc123','Wan Chai','Admin');
/*!40000 ALTER TABLE `DA_USER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appone_quotation_list`
--

DROP TABLE IF EXISTS `appone_quotation_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appone_quotation_list` (
  `quotation_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `quotation_no` varchar(40) DEFAULT NULL,
  `quotation_infomation` text,
  `quotation_total_price` decimal(10,2) NOT NULL,
  `quotation_paid_price` decimal(10,2) NOT NULL,
  `quotation_discount` decimal(10,2) NOT NULL,
  `user_name` varchar(60) DEFAULT NULL,
  `user_companyname` varchar(60) DEFAULT NULL,
  `user_tel` varchar(60) DEFAULT NULL,
  `user_companyaddress` varchar(200) DEFAULT NULL,
  `user_content` text,
  `quotation_time` int(11) NOT NULL,
  `quotation_state` int(11) NOT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=MyISAM AUTO_INCREMENT=418 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appone_quotation_list`
--

LOCK TABLES `appone_quotation_list` WRITE;
/*!40000 ALTER TABLE `appone_quotation_list` DISABLE KEYS */;
INSERT INTO `appone_quotation_list` (`quotation_id`, `quotation_no`, `quotation_infomation`, `quotation_total_price`, `quotation_paid_price`, `quotation_discount`, `user_name`, `user_companyname`, `user_tel`, `user_companyaddress`, `user_content`, `quotation_time`, `quotation_state`, `user_email`) VALUES (332,'LD000000332','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"info@appone.hk\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','123123','',1486008578,1,'info@appone.hk'),(333,'LD000000333','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"web_type\":\"xiangyingshi\",\"web_language\":[\"tw\",\"cn\",\"en\"],\"app_type\":[\"ios\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"123123@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123213\",\"tel\":\"22222222\",\"companyaddress\":\"2222222222\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123213','22222222','2222222222','',1486015570,1,'123123@gmail.com'),(334,'LD000000334','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"123123@gmail.com\",\"username\":\"123\",\"companyname\":\"13121212\",\"tel\":\"22222222\",\"companyaddress\":\"1212212212\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'123','13121212','22222222','1212212212','',1486016305,1,'123123@gmail.com'),(335,'LD000000335','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"cyrus@appone.hk\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','123123','',1486024497,1,'cyrus@appone.hk'),(336,'LD000000336','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"cyrus@appone.hk\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"12312322\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','12312322','123123','',1486025303,1,'cyrus@appone.hk'),(337,'LD000000337','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"cyrus@appone.hk\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','123123','',1486025351,1,'cyrus@appone.hk'),(338,'LD000000338','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"cyrus@appone.hk\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"address\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','address','',1486025519,1,'cyrus@appone.hk'),(339,'LD000000339','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"address\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','address','',1486025614,1,'wutianhua87@gmail.com'),(340,'LD000000340','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','123123','',1486025765,1,'wutianhua87@gmail.com'),(341,'LD000000341','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"admin@admin.com\",\"username\":\"admin\",\"companyname\":\"123213\",\"tel\":\"22222222\",\"companyaddress\":\"dasd\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'admin','123213','22222222','dasd','',1486025848,1,'admin@admin.com'),(342,'LD000000342','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"web_type\":\"xiangyingshi\",\"app_type\":[\"ios\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"admin@admin.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123213\",\"tel\":\"22222222\",\"companyaddress\":\"dasd\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123213','22222222','dasd','',1486026126,1,'admin@admin.com'),(343,'LD000000343','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','123123','',1486027347,1,'wutianhua87@gmail.com'),(344,'Q344','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"address\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','address','',1486027399,1,'wutianhua87@gmail.com'),(345,'Q345','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".com\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"admin@admin.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123213\",\"tel\":\"22222222\",\"companyaddress\":\"dasd\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123213','22222222','dasd','',1486027487,1,'admin@admin.com'),(346,'Q346','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"android\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"20GB\",\"app_cms_domain\":\".com.hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"19_1\",\"3\",\"10\",\"14\",\"24\"],\"referenceapp_customer\":\"\",\"email\":\"michael_mt_lau@manulife.com.hk\",\"username\":\"Michael Ming-Tao Lau\",\"companyname\":\"Manulife (International) Limited\",\"tel\":\"22151952\",\"companyaddress\":\"15/F., Manulife Tower, One Bay East, 83 Hoi Bun Road, Kwun Tong, Kowloon, Hong Kong\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'Michael Ming-Tao Lau','Manulife (International) Limited','22151952','15/F., Manulife Tower, One Bay East, 83 Hoi Bun Road, Kwun Tong, Kowloon, Hong Kong','',1486366146,1,'michael_mt_lau@manulife.com.hk'),(347,'Q347','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".com\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"1_5\",\"3\",\"14\"],\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','123123','',1486366306,1,'wutianhua87@gmail.com'),(348,'Q348','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"1_1\",\"3\",\"9\",\"14\"],\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','123123','',1486366339,1,'wutianhua87@gmail.com'),(349,'Q349','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"19_1\"],\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','123123','22222222','123123','',1486366619,1,'wutianhua87@gmail.com'),(350,'Q350','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"19_1\"],\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"info@appone.hk\",\"companyname\":\"appone\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'info@appone.hk','appone','22222222','123123','',1486366802,1,'wutianhua87@gmail.com'),(351,'Q351','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\",\"android\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"20GB\",\"app_cms_domain\":\".com.hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"func\",\"app_func\":[\"19_1\",\"3\",\"10\",\"14\",\"24\"],\"referenceapp_customer\":\"\",\"email\":\"michael_mt_lau@manulife.com.hk\",\"username\":\"Michael Ming-Tao Lau\",\"companyname\":\"Manulife (International) Limited\",\"tel\":\"22151952\",\"companyaddress\":\"15/F., Manulife Tower, One Bay East, 83 Hoi Bun Road, Kwun Tong, Kowloon, Hong Kong\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'Michael Ming-Tao Lau','Manulife (International) Limited','22151952','15/F., Manulife Tower, One Bay East, 83 Hoi Bun Road, Kwun Tong, Kowloon, Hong Kong','',1486367050,1,'michael_mt_lau@manulife.com.hk'),(352,'Q352','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"web\",\"web_type\":\"xiangyingshi\",\"web_language\":[\"tw\"],\"web_cms\":\"no\",\"web_cms_hosting\":\"wuxian\",\"web_cms_domain\":\".com\",\"web_cms_server\":\"microsoft\",\"web_content\":\"page\",\"web_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"Ysendemail@gmail.com\",\"username\":\"Psaa\",\"companyname\":\"Hsss\",\"tel\":\"96005138\",\"companyaddress\":\"A\",\"user_content\":\"Yesu\",\"qid\":\"\"}',0.00,0.00,0.00,'Psaa','Hsss','96005138','A','Yesu',1486473902,1,'Ysendemail@gmail.com'),(353,'Q353','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ios\"],\"app_language\":[\"tw\"],\"app_cms\":\"yes\",\"app_cms_hosting\":\"10GB\",\"app_cms_domain\":\".hk\",\"app_cms_server\":\"microsoft\",\"app_content\":\"page\",\"app_page\":\"0~10\",\"referenceapp_customer\":\"\",\"email\":\"123@qq.com\",\"username\":\"123123123\",\"companyname\":\"123123123\",\"tel\":\"22222222\",\"companyaddress\":\"12312323\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'123123123','123123123','22222222','12312323','',1486717260,1,'123@qq.com'),(354,'Q354','{\"app\":\"quotation\",\"f\":\"createQuotation\",\"type\":\"app\",\"app_type\":[\"ipad\"],\"app_language\":[\"cn\"],\"app_cms\":\"no\",\"app_content\":\"page\",\"app_page\":\"11~20\",\"referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"nutrasumma\",\"companyname\":\"123123\",\"tel\":\"22222222\",\"companyaddress\":\"123123\",\"user_content\":\"\",\"qid\":\"\"}',0.00,0.00,0.00,'nutrasumma','123123','22222222','123123','',1487293814,1,'wutianhua87@gmail.com'),(355,'Q355','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294150_58a64ec60237d.jpg\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec24082a.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec23caab.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec238f7a.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec249b76.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec252118.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294146_58a64ec2a2639.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294149_58a64ec5ee7b3.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294149_58a64ec5ea0b2.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294151_58a64ec800025.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec809065.jpg\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec82d69f.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec811e08.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec81a286.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec851c94.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec85c7d0.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec860fef.png\",\"upload/app/20170217/7km3aic7lubcj7mbmfrsh456d1_1487294152_58a64ec86520b.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"8db4613137a257edbe7d3ce5f9d981baa9643e39\"}',0.00,0.00,0.00,'info@appone.hk','info@appone.hk','22222222','123123','',1487294178,1,'wutianhua87@gmail.com'),(356,'Q356','{\"type\":\"web\",\"web_type\":\"xiangyingshi\",\"web_language\":[\"tw\"],\"web_cms\":\"no\",\"web_content_type\":\"concept\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"cyrus@appone.hk\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"e717d85621ff2de8fcfb9bed48798bd33918d3c4\",\"img\":[\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111ee44.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111ef6f.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f046.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f105.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f1be.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f279.jpg\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f47f.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f53d.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f5ff.png\",\"upload/web/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304209_58a676111f6b9.png\"]}',0.00,0.00,0.00,'info@appone.hk','info@appone.hk','22222222','123123','',1487304209,1,'cyrus@appone.hk'),(357,'Q357','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"acf574e7be394bd5d3bf84803ac65d5fc9b45794\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487304477,1,'wutianhua87@gmail.com'),(358,'Q358','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304754_58a67832ee8ac.jpg\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304751_58a6782f63c24.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304751_58a6782f6e8d6.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304751_58a6782f80ac1.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304751_58a6782f67f98.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304751_58a6782f757be.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304752_58a678307b68c.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304753_58a6783127413.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304753_58a678312c3e2.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304753_58a6783131d2e.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304753_58a6783138d0f.jpg\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304758_58a678360bbd4.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304758_58a6783604dee.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304757_58a67835e98ed.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304757_58a67835ef1df.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304758_58a6783616801.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304758_58a678362a2ed.png\",\"upload/app/20170217/1vgbr7ejsvf1uml7qdp692rhg7_1487304758_58a678362e52a.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c7cc41f03a35aebb114ca97cf15832dda5eea96f\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487304777,1,'wutianhua87@gmail.com'),(359,'Q359','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\"],\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c7b13ef4c736742d489e158ef23bbf60afcbdee3\",\"img\":[]}',0.00,0.00,0.00,'Hshshsh','Hshshsh','22222222','Hehshshsnedhurke','',1487315807,1,'wutianhua87@gmail.com'),(360,'Q360','{\"type\":\"web\",\"web_type\":\"feixiangyingshi\",\"web_language\":[\"tw\",\"cn\",\"en\"],\"web_cms\":\"no\",\"web_content_type\":\"concept\",\"web_func_desc\":\"HDhshdhshdjjds\",\"web_referenceapp_customer\":\"\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"Wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"055b7b77a30ee908d6df207cbe732d483babef8f\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487315929,1,'Wutianhua87@gmail.com'),(361,'Q361','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"tw\",\"cn\"],\"app_cms\":\"no\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"Hhsh@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"fd395fedefeae7b3155546bb011aa4456901f05b\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487315981,1,'Hhsh@gmail.com'),(362,'Q362','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"cn\"],\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"Jsjshshhsshs\",\"app_referenceapp_customer\":\"\",\"email\":\"Ndhshs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"36f8ba3dcbf738fa18f569a4667f186abe7d8f2d\",\"img\":[]}',0.00,0.00,0.00,'Hshsgfss','Hshsgfss','22222222','Hshsyss','',1487322229,1,'Ndhshs@gmail.com'),(363,'Q363','{\"type\":\"app\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_cms\":\"yes\",\"app_content_type\":\"nothing\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"Dp\",\"app_referenceapp_value\":\"customer\",\"email\":\"Wujdjsh@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"7069bf21219744565e40af3ed159a1b4f4902d8f\",\"img\":[]}',0.00,0.00,0.00,'Http://appone.hk','Http://appone.hk','22222222','Hshgsyss','',1487323318,1,'Wujdjsh@gmail.com'),(364,'Q364','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\",\"other\"],\"app_other_language\":\"j d h d\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"今生今世也是个愤世嫉俗\",\"app_referenceapp_customer\":\"\",\"email\":\"wujsjsh@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"462a8c7e55000f041e66f2910e7400a414ea91a2\",\"img\":[]}',0.00,0.00,0.00,'Jjsshhs','Jjsshhs','22222222','Usuhsbshsns','',1487555868,1,'wujsjsh@gmail.com'),(365,'Q365','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\",\"en\",\"other\"],\"app_other_language\":\"Shhsh\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"Hshsgsgs\",\"app_referenceapp_customer\":\"\",\"email\":\"Uhhshs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"5956f6fe5fa6feb3c3c90d9c7d449e9f053352a6\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487556073,1,'Uhhshs@gmail.com'),(366,'Q366','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\",\"other\"],\"app_other_language\":\"Hzshs\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"Hdhshdgsdgs\",\"app_referenceapp_customer\":\"\",\"email\":\"Jhahs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"146dac3e7eb98d86c63c39fdb13abbb9a4df119c\",\"img\":[]}',0.00,0.00,0.00,'Hshshsg','Hshshsg','22222222','Hahshsss','',1487562432,1,'Jhahs@gmail.com'),(367,'Q367','{\"type\":\"web\",\"web_type\":\"feixiangyingshi\",\"web_language\":[\"tw\",\"cn\",\"en\",\"other\"],\"web_other_language\":\"Hshshs.jshs\",\"web_cms\":\"yes\",\"web_content_type\":\"design\",\"web_func_desc\":\"\",\"web_page\":\"31~40\",\"web_referenceapp_customer\":\"\",\"app_other_language\":\"\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"Hshshs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"3d851a4fc6a5f2c77f3bf896a107c98931e0b74d\",\"img\":[]}',0.00,0.00,0.00,'Jshshs','Jshshs','22222222','Hshshsgss','',1487562623,1,'Hshshs@gmail.com'),(368,'Q368','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"Hshsh@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"ff3c27b324a2e8b9fe6671becd0c4ba199c17e37\",\"img\":[\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562947_58aa68c3946c0.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562950_58aa68c673f54.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562950_58aa68c674a5e.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562952_58aa68c819af9.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562952_58aa68c81a61d.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562952_58aa68c81b273.JPG\",\"upload/app/20170220/kk8nioa2rl747kkpvm9c5jpq77_1487562952_58aa68c8236b5.JPG\"]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487562952,1,'Hshsh@gmail.com'),(369,'Q369','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"Hshsgs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"f458bedfba21fe55301780b31a1631c20ec63f8f\",\"img\":[\"u\",\"u\",\"u\",\"u\",\"u\",\"u\",\"u\"]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487576812,1,'Hshsgs@gmail.com'),(370,'Q370','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"asdasd@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"2e8a05277b8433bbf1036d7be0f606c9abc03983\",\"img\":[\"u\",\"u\",\"u\",\"u\",\"u\"]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487576925,1,'asdasd@gmail.com'),(371,'Q371','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ios\",\"ipad\",\"android\",\"tablet\"],\"app_language\":[\"tw\",\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"51~60\",\"app_referenceapp_customer\":\"\",\"email\":\"Ysendemail@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"ecc945b45126803d55c5886b0e8ace4847b4178b\",\"img\":[]}',0.00,0.00,0.00,'Name','Name','98753637','Y','D',1487577236,1,'Ysendemail@gmail.com'),(372,'Q372','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua@gmail.co\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"afda9c67944442f199422c16ebfc983569d192dd\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487643877,1,'wutianhua@gmail.co'),(373,'Q373','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"a056922723c1c4be4714a34dd01e4199619f8d9a\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487646659,1,'wutianhua87@gmail.com'),(374,'Q374','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"asdasdasdsad\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"f2ae2d65cbdb4c603e1894c79d6e4b30d526331c\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487646683,1,'wutianhua@gmail.com'),(375,'Q375','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"asdasds@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"42f455bda296a378d68782129d0bf08530848ce7\",\"img\":[\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646714_58abaffa07611_100_100.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe5930a_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe5af5a_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe61459_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe6bbee_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe70983_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe723ea_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe73f00_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe776f7_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffe79378_100_100.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffea3146_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffea6d3c_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffea89bf_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffeaa71d_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffeace5b_100_100.png\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487646718_58abaffeb4dd1_100_100.png\"]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487646718,1,'asdasds@gmail.com'),(376,'Q376','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"hshsd@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"0db8dd4b0b016c2533d01fa1be0d9417b64564ec\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487649462,1,'hshsd@gmail.com'),(377,'Q377','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"Jshdhd@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"1427c46a82173db003858c302f907dcda4f9ae55\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487649710,1,'Jshdhd@gmail.com'),(378,'Q378','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"Hushshs@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"72f8aa4124bc547e4f92397e0719f8378a992f33\",\"img\":[\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649793_58abbc01ea87d.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649793_58abbc01eb107.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649793_58abbc01eba2d.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649794_58abbc02da3f4.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649794_58abbc02dadd4.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649795_58abbc03030c8.JPG\",\"upload/app/20170221/b62i30omioc1g3lqo8me4ve620_1487649795_58abbc0303c86.JPG\"]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487649795,1,'Hushshs@gmail.com'),(379,'Q379','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c88987f5cfb87689644fc824d977908cc6d918a8\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487651585,1,'wutianhua87@gmail.com'),(380,'Q380','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"0c5ce8e2f5d6e5c01605e1639d85139300b34ed1\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487651900,1,'wutianhua87@gmail.com'),(381,'Q381','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"5bfc1db2090e84c45cdc985c11ff3f1aa3f483cb\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487652015,1,'wutianhua87@gmail.com'),(382,'Q382','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"4bfa192a6b90df9de8a94cb5ad2f16f15183c13c\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487652131,1,'wutianhua87@gmail.com'),(383,'Q383','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"916ac41ac5ef9448757debe31a09b62ea4cdc940\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487652795,1,'wutianhua87@gmail.com'),(384,'Q384','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"ca34d4b56d9e8be9eaf301565270c0ce39ef99e0\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487652908,1,'wutianhua87@gmail.com'),(385,'Q385','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"301808417ff7c471c4a7df22e1f66cf19ca80e81\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487653128,1,'wutianhua87@gmail.com'),(386,'Q386','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"0~10\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"19884c9fa81571e566c526e9b2ef45f6c5f2652a\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487653755,1,'wutianhua87@gmail.com'),(387,'Q387','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"21~30\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"1591c46de6e565b95b3a6f3c15c7ddf15804fe20\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487658398,1,'wutianhua87@gmail.com'),(388,'Q388','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"640c3543a3b5950c5fcbcbed9d8d46a4051b46c8\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487658445,1,'wutianhua87@gmail.com'),(389,'Q389','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"8a4baa80bec6c94e336b35d7879d01eda921df78\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487658674,1,'wutianhua87@gmail.com'),(390,'Q390','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"4e70c837e61c94cc2c50748aa803be85550b8803\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487658864,1,'wutianhua87@gmail.com'),(391,'Q391','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"2b8c5f7826bcbb87c258a298d7f8effaa9842b3e\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487659068,1,'wutianhua87@gmail.com'),(392,'Q392','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"3c35ff98fbd91b14805bd6cdaee4af28e6da576b\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487659861,1,'wutianhua87@gmail.com'),(393,'Q393','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"android\",\"tablet\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"d9a952b1d07e78409ba5dc36756163101a10c8b3\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487660230,1,'wutianhua87@gmail.com'),(394,'Q394','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"6215958dcba093d12622d318a5a5942c203791b8\",\"img\":[]}',0.00,0.00,0.00,'info@appone.hk','info@appone.hk','22222222','1231231323123123','',1487660469,1,'wutianhua87@gmail.com'),(395,'Q395','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66ec9ac8_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66eaadbe_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66e9e3d1_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66e94e46_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66ed9826_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660654_58abe66eb754b_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660655_58abe66f081cc_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660655_58abe66f0f564_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660655_58abe66f17713_200_200.jpg\",\"upload/app/20170221/momn2k8f0e0vaobv86n3prvcr7_1487660661_58abe675327c0_200_200.jpg\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"33ac4d05f38850bac0ec1997d17666492937a60a\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487660886,1,'wutianhua87@gmail.com'),(396,'Q396','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734626_58ad07625ca5d_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734626_58ad07628d30d_200_200.jpg\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad076300bf2_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad076323f0a_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad07634b427_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad07636ea93_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad0763947fb_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad0763bdc16_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734627_58ad0763e3046_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734781_58ad07fd86e7d_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734781_58ad07fda7386_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c2e7cc198f1f5d60e2bd95fd88bd6d46f011a12a\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487734845,1,'wutianhua87@gmail.com'),(397,'Q397','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734900_58ad08747904f_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734900_58ad08749c1ba_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734900_58ad0874c2690_200_200.jpg\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad08751aa7c_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad087538c05_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad087556835_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad087579124_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad08759e65e_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad0875c47f6_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734901_58ad0875e7380_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734905_58ad08798a4d0_200_200.jpg\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734909_58ad087d72b7e_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734909_58ad087d8dbb7_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734909_58ad087daa9dc_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734909_58ad087dc644c_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734909_58ad087de3a2a_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734910_58ad087e0ca94_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487734910_58ad087e2b54d_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c18a1a975cc82e08417dde9fbff45f4a3af1fcf8\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487734922,1,'wutianhua87@gmail.com'),(398,'Q398','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735648_58ad0b60084b7_200_200.jpg\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735653_58ad0b656c2f6_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735653_58ad0b6589618_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735653_58ad0b65a5902_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735653_58ad0b65c1de3_200_200.png\",\"upload/app/20170222/d55q28ojkjrb617cutsrj8nt17_1487735653_58ad0b65dec90_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"aa365aeb6af41525c35ffa941ac9a87cffe9d447\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487735663,1,'wutianhua87@gmail.com'),(399,'Q399','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"tablet\"],\"app_language\":[\"cn\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487746957_58ad378d3a1f5_200_200.jpg\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"49f84af23f175b2da73b6cab0bbc857fa7213afa\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487746993,1,'wutianhua87@gmail.com'),(400,'Q400','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747076_58ad3804170fb_200_200.jpg\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747076_58ad3804867db_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747076_58ad3804a59ed_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747076_58ad3804ca0a5_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747076_58ad3804eac5d_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487747077_58ad380515851_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"a20174c0af5918cc9ab199aa397723da2885a97f\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487747109,1,'wutianhua87@gmail.com'),(401,'Q401','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487749836_58ad42cc24298_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"6be2f45b6ffe9ebb63c9312e3d8818c65a4d8ac2\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487749874,1,'wutianhua87@gmail.com'),(402,'Q402','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750181_58ad44252be84_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"57560c0292eb52a51c93409e70aa8354ae942329\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487750208,1,'wutianhua87@gmail.com'),(403,'Q403','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750232_58ad445867ef1_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750232_58ad44589048d_200_200.jpg\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750232_58ad4458ef7d8_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750233_58ad445924ca1_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750233_58ad445951792_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"7b7e86e75220045974f0dba4e722dea34bc2e0e9\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487750253,1,'wutianhua87@gmail.com'),(404,'Q404','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750275_58ad44831171d_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"4c6c5d9d7fb0cfb05ed00c8e21ad653aa8541033\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487750288,1,'wutianhua87@gmail.com'),(405,'Q405','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750477_58ad454d7fa6f_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487750479_58ad454fe72dd_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"fe878cebdae4ebfd0ae839c6d9e5ac1f3bd30619\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487750502,1,'wutianhua87@gmail.com'),(406,'Q406','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753285_58ad504511b36_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753285_58ad5045333ca_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753285_58ad50455bec2_200_200.jpg\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753285_58ad5045bab4b_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753285_58ad5045e1c49_200_200.png\",\"upload/app/20170222/tqjoch8st63ljvof736qpgck94_1487753286_58ad50461425b_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"c359833ad82c96d5341daefa690ad73abbe6d19c\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487753297,1,'wutianhua87@gmail.com'),(407,'Q407','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"1ead478dde87213fbf617b5179a6d1361748eeb3\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487816664,1,'wutianhua87@gmail.com'),(408,'Q408','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816685_58ae47ed663bb_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816685_58ae47edc306f_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816686_58ae47ee199ba_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816686_58ae47ee6774c_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816686_58ae47eeba3f0_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816687_58ae47ef1e925_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816687_58ae47ef7a553_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816687_58ae47efdaa01_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487816688_58ae47f038020_200_200.jpg\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"da6bb6e82b17a4a43a7a0aa8adc09f98afd90766\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487816701,1,'wutianhua87@gmail.com'),(409,'Q409','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821919_58ae5c5f7ce09_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821919_58ae5c5f5ecd6_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821919_58ae5c5f8eab8_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821919_58ae5c5fbb13f_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821919_58ae5c5fcee86_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821920_58ae5c60733ae_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821920_58ae5c607bbe2_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821920_58ae5c60cadca_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821921_58ae5c6114e76_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821921_58ae5c61206bf_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821921_58ae5c6178a65_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487821921_58ae5c6154205_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"8aa4667c996387127ba88b81c15999df1f0b894f\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487821961,1,'wutianhua87@gmail.com'),(410,'Q410','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822036_58ae5cd402798_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822034_58ae5cd2ecbcb_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd3010c8_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd334056_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd340b90_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd36bc46_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd3873bc_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822035_58ae5cd3c5e4a_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822036_58ae5cd45e7a6_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822036_58ae5cd46994b_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822036_58ae5cd4985d4_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822036_58ae5cd4a0e91_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"acd9ab35e470df4e4926a2a5aadd0b5f0bb32644\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487822046,1,'wutianhua87@gmail.com'),(411,'Q411','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822292_58ae5dd494ca5_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822291_58ae5dd3747d4_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822291_58ae5dd37dba7_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822291_58ae5dd3ac46f_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822291_58ae5dd3ba4d9_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822292_58ae5dd4231ac_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822292_58ae5dd44e1b8_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822292_58ae5dd4469fd_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822293_58ae5dd513d37_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822293_58ae5dd522ca5_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822293_58ae5dd550a44_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487822293_58ae5dd562686_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"174ddc84e87fc8d68c3ae635b84675b2fc3e2c68\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487822303,1,'wutianhua87@gmail.com'),(412,'Q412','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ipad\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"email\":\"wutianhua87@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487825703_58ae6b2740685_200_200.jpg\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487825703_58ae6b2734eaf_200_200.png\",\"upload/app/20170223/kadc3rmkvfumtgukcadn58nr64_1487825703_58ae6b2792101_200_200.png\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"039149cbb844b5f586b77fa4d2f59c5b91ade1d7\"}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1487825751,1,'wutianhua87@gmail.com'),(413,'Q413','{\"type\":\"app\",\"web_type\":\"xiangyingshi\",\"web_language\":[\"en\"],\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"ios\",\"android\"],\"app_language\":[\"cn\",\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"Testing \",\"app_referenceapp_customer\":\"\",\"email\":\"info@appone.hk\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"3b84754b36b25763de404e09f3f77157a1486934\",\"img\":[]}',0.00,0.00,0.00,'info@appone.hk','info@appone.hk','21520198','','',1488942208,1,'info@appone.hk'),(414,'Q414','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"design\",\"app_func_desc\":\"\",\"app_page\":\"11~20\",\"app_referenceapp_customer\":\"\",\"email\":\"info@appone.hk\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"img\":[\"upload/app/20170308/7sf1smb8ucl2ugsa9hogjlb0h3_1488943287_58bf78b73cf50_200_200.jpg\"],\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"7eb0ce31e2d4f0bf995f5922f04af4ba5c0030c3\"}',0.00,0.00,0.00,'info@appone.hk','info@appone.hk','21520198','','test remark',1488943391,1,'info@appone.hk'),(415,'Q415','{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"concept\",\"app_func_desc\":\"55\",\"app_referenceapp_customer\":\"\",\"email\":\"info@appone.hk\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"dc61ddf543f50879fad1d21bfaef23b407e2ac04\",\"img\":[]}',0.00,0.00,0.00,'val','val','22222222','','',1488943596,1,'info@appone.hk'),(416,NULL,'{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"nothing\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"app_referenceapp_value\":\"1\",\"email\":\"fayappone@gmail.com\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"525d165ae10ea16e48be8c5e29e6af5e92e390d1\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1490945305,1,'fayappone@gmail.com'),(417,NULL,'{\"type\":\"app\",\"web_other_language\":\"\",\"web_func_desc\":\"\",\"web_referenceapp_customer\":\"\",\"app_type\":[\"android\"],\"app_language\":[\"en\"],\"app_other_language\":\"\",\"app_cms\":\"yes\",\"app_content_type\":\"nothing\",\"app_func_desc\":\"\",\"app_referenceapp_customer\":\"\",\"app_referenceapp_value\":\"1\",\"email\":\"faycheng@appone.hk\",\"username\":\"\",\"companyname\":\"\",\"tel\":\"\",\"companyaddress\":\"\",\"user_content\":\"\",\"app\":\"quotation\",\"f\":\"createQuotation\",\"qid\":\"\",\"csrf\":\"37cca13cd079e425e6e9fb55f597ed05963f4193\",\"img\":[]}',0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,1490945433,1,'faycheng@appone.hk');
/*!40000 ALTER TABLE `appone_quotation_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_locations`
--

DROP TABLE IF EXISTS `mb_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_locations`
--

LOCK TABLES `mb_locations` WRITE;
/*!40000 ALTER TABLE `mb_locations` DISABLE KEYS */;
INSERT INTO `mb_locations` (`id`, `name`) VALUES (1,'Wan Chai');
/*!40000 ALTER TABLE `mb_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_roles`
--

DROP TABLE IF EXISTS `mb_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_roles`
--

LOCK TABLES `mb_roles` WRITE;
/*!40000 ALTER TABLE `mb_roles` DISABLE KEYS */;
INSERT INTO `mb_roles` (`id`, `name`) VALUES (1,'admin'),(2,'user');
/*!40000 ALTER TABLE `mb_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mb_users`
--

DROP TABLE IF EXISTS `mb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mb_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1',
  `remember_token` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_id` (`role_id`),
  KEY `role_id_2` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mb_users`
--

LOCK TABLES `mb_users` WRITE;
/*!40000 ALTER TABLE `mb_users` DISABLE KEYS */;
INSERT INTO `mb_users` (`id`, `username`, `password`, `role_id`, `location_id`, `name`, `email`, `created_at`, `updated_at`, `active`, `remember_token`) VALUES (1,'admin','$2y$10$iG.E/BylL2EPZ6l7yrc07umrSv/8S9eobfr.V4eLkiyPGcRxKVjnW',0,0,'Siyana','siyana@appone.hk','2016-08-03 09:07:06','2016-08-03 01:07:06',1,'b1hwfM8wgu3VL3Uf100DPUuXwm2NeH49ZGAUABuGoTfq11QM9YdU44qtKgqG'),(5,'cyrus','$2y$10$iG.E/BylL2EPZ6l7yrc07umrSv/8S9eobfr.V4eLkiyPGcRxKVjnW',0,0,'Cyrus','cyrus@appone.hk','2016-07-08 09:31:34','2016-07-08 09:31:34',1,'3nV8Ob509SfzkrHvOr8OJLUxZ2n3zRSO6lMrXXbAH1uLVCxrbCWTxmtnquvm'),(24,'billy','$2y$10$eyF8zzQYEZ4DoQbVese.we0s6QRsx/stIgD3AABJmnm1dMnTPiW.y',0,0,'Billy','billy@appone.hk','2016-07-12 09:15:36','2016-07-12 09:15:36',1,''),(25,'edward','$2y$10$ziFCsqAaq/ulI31qBzd15eCSyUFZDwcPMZFLIHMAmPI/W86gZBW8m',0,0,'Edward','edward@appone.hk','2016-08-12 03:41:00','2016-08-12 03:41:00',1,'');
/*!40000 ALTER TABLE `mb_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rc_editor`
--

DROP TABLE IF EXISTS `rc_editor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rc_editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `c` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rc_editor`
--

LOCK TABLES `rc_editor` WRITE;
/*!40000 ALTER TABLE `rc_editor` DISABLE KEYS */;
INSERT INTO `rc_editor` (`id`, `c`) VALUES (1,'<p style=\"text-align:center\"><img src=\"/rc/php/upload/image/20170217/1487324484781660.png\" alt=\"1487324484781660.png\"/></p><h1 class=\"heading-title\" style=\"-webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; margin: 0px 0px 17px; padding: 0px 0px 0px 10px; border: 0px; outline: 0px; line-height: 38px; height: 40px; font-size: 15px; font-weight: 400; text-transform: uppercase; overflow: hidden; text-overflow: ellipsis; background-color: rgb(63, 87, 101); font-family: Oswald; color: rgb(250, 250, 250); box-sizing: border-box;\">ABOUT US</h1><p style=\"-webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; margin-top: 0px; margin-bottom: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; color: rgb(255, 255, 255); font-family: Helvetica, Arial, sans-serif; font-size: 13px; white-space: normal; color: rgb(56, 56, 56);\"><span style=\"-webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; font-family: Helvetica, Arial, &quot;lucida grande&quot;, tahoma, verdana, arial, sans-serif; font-size: 15px; line-height: 18px;\">RC-Castle operated by CO-Tronic Enterprise (H.K.) Co., Limited - a registered business based in Hong Kong which is founded b</span><span class=\"text_exposed_show\" style=\"-webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; margin: 0px; padding: 0px; border: 0px; outline: 0px; box-sizing: border-box; display: inline; font-family: Helvetica, Arial, &quot;lucida grande&quot;, tahoma, verdana, arial, sans-serif; font-size: 15px; line-height: 18px;\">y several energetic hobbyists who are in the RC Hobby industry for over 10 years. RC-Castle operates under the horizontal hierarchy that gives us an extremely efficient position for facing any challenges.&nbsp;<br/><br/>With the direct support from our neighbor factories in China &amp; Taiwan, RC-Castle benefits from the lowest logistic cost that allow us to bring the best products with the most competitive prices to our buyers. As the major logistic hub of the world, Hong Kong post office always delivers our orders to your door in the safest, most accurate and efficient way.<br/><br/>We keep on carrying full range of RC products and spare parts supports. RC-Castle is listing thousands of various RC industrial products. It is not a matter if you want to upgrade, repair or to buy a new RC aircraft, those products and spare parts are here ready for you as well as the professional advises from our CS and Tech teams.<br/><br/>Some Other on-line shops will put your items in a thin envolope without any protection. But we concern good packaging to avoid any damage during transportation. It is surely no good to pay less on shipping and take the risk on breakage.<br/><br/>We sell our stocked products only! What you see in our site are all in stock. All out of stock items will be removed on the list as soon as possibile. Some goods may run out of stock temporarily after deducting the quantities from orders. But, we will do our best to re-stock all products right away ! RC-Castle will continuse to increase our stock level and varieties to keep pace with our growth !<br/><br/>We can ship your orders within 2 business days in most cases. Wish you all a nice shopping experience with us !</span></p><p><br/></p><p><br/></p>');
/*!40000 ALTER TABLE `rc_editor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_categories`
--

DROP TABLE IF EXISTS `saiwan_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `has_sub_cat` int(1) NOT NULL,
  `parent_cat_id` int(11) NOT NULL DEFAULT '0',
  `img` varchar(200) NOT NULL,
  `name_chin` varchar(200) NOT NULL,
  `desc_chin` varchar(200) NOT NULL,
  `name_eng` varchar(200) NOT NULL,
  `desc_eng` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_frontpage` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_categories`
--

LOCK TABLES `saiwan_categories` WRITE;
/*!40000 ALTER TABLE `saiwan_categories` DISABLE KEYS */;
INSERT INTO `saiwan_categories` (`id`, `has_sub_cat`, `parent_cat_id`, `img`, `name_chin`, `desc_chin`, `name_eng`, `desc_eng`, `status`, `sort_order`, `created_at`, `updated_at`, `is_frontpage`) VALUES (56,0,0,'/upload/images/IMG_4909.png','主打菜','','To Day Special','',1,1,'2017-01-02 00:17:29','2017-01-03 10:51:08',1),(60,0,0,'/upload/images/IMG_4909.png','有營菜式','','Eatsmart Food','',1,5,'2016-12-22 17:10:20','2017-01-03 11:09:18',1),(6,0,0,'/upload/images/abc.png','湯類','cat6_desc','Soup','',1,6,'2016-07-24 08:00:00','2016-07-24 08:00:00',0),(7,1,0,'/upload/images/abc.png','飲品','cat7_desc','Beverage','',1,7,'2016-07-24 08:00:00','2016-07-24 08:00:00',0),(8,0,0,'/upload/images/abc.png','豬','cat8_desc','Pork','',1,8,'2016-07-24 08:00:00','2016-07-24 08:00:00',0),(9,0,0,'/upload/images/abc.png','牛','cat9_desc','Beef','',1,9,'2016-07-24 08:00:00','2016-07-24 08:00:00',0),(10,0,0,'/upload/images/abc.png','雞','','Chicken','',1,11,'0000-00-00 00:00:00','2017-01-09 21:44:21',0),(12,0,0,'/upload/images/abc.png','素菜類','','Vegetable','',1,2,'0000-00-00 00:00:00','2017-01-23 02:21:22',1),(13,0,0,'/upload/images/abc.png','主食(粉麵飯)','','Noodle&Rice','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(14,0,0,'/upload/images/IMG_4909.png','套餐','','Set','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',1),(15,1,0,'/upload/images/IMG_4892.png','海鮮總會','','Featured Seafood','',1,12,'0000-00-00 00:00:00','2017-01-09 21:47:43',1),(16,1,7,'/upload/images/abc.png','酒精類','','Beer&Wine','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(17,0,16,'/upload/images/abc.png','啤酒類','','Beer','',0,2,'0000-00-00 00:00:00','2017-01-16 04:13:35',0),(18,1,16,'/upload/images/abc.png','紅酒類','','Red&white wine','',0,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(19,0,16,'/upload/images/abc.png','酒精類','','China Wine&Brandy','',0,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(20,0,18,'/upload/images/abc.png','(杯)紅,白酒','','House Red & White','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(21,0,18,'/upload/images/abc.png','白酒','','White','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(22,0,18,'/upload/images/abc.png','紅酒','','Red','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(23,0,18,'/upload/images/abc.png','香檳','','Champagne','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(25,0,7,'/upload/images/abc.png','飲品類','','Soft Drinks','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(26,0,7,'/upload/images/abc.png','特飲類','','Health Yakult Drinks','',1,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(27,0,15,'/upload/images/abc.png','海貝','','Shellfish','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(28,0,15,'/upload/images/abc.png','海蝦類','','Shrimps','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(29,0,15,'/upload/images/abc.png','魚','','Fish','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(30,0,15,'/upload/images/abc.png','象拔蚌類','','Geoduck','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(31,0,15,'/upload/images/abc.png','鮑魚','','Abalone','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(32,0,15,'/upload/images/abc.png','龍蝦類','','Lobster','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(33,0,15,'/upload/images/abc.png','瀨尿蝦類','','Big Maints Shrimps','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(34,0,15,'/upload/images/abc.png','蟹類','','Crab','',0,0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0),(59,0,0,'/upload/images/IMG_4909.png','小食','','Snacks','',1,2,'2017-01-02 00:18:32','2017-01-09 21:49:19',1),(58,0,0,'','海產類','','Seafood','',1,3,'2017-01-02 00:20:56','2017-01-02 00:20:56',1);
/*!40000 ALTER TABLE `saiwan_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_categories_old`
--

DROP TABLE IF EXISTS `saiwan_categories_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_categories_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `has_SubCat` tinyint(1) NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `img` varchar(200) NOT NULL,
  `name_chin` varchar(200) NOT NULL,
  `desc_chin` varchar(200) NOT NULL,
  `name_eng` varchar(200) NOT NULL,
  `desc_eng` varchar(200) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` date NOT NULL,
  `update_time` date NOT NULL,
  `is_frontpage` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_categories_old`
--

LOCK TABLES `saiwan_categories_old` WRITE;
/*!40000 ALTER TABLE `saiwan_categories_old` DISABLE KEYS */;
INSERT INTO `saiwan_categories_old` (`id`, `has_SubCat`, `parent_id`, `img`, `name_chin`, `desc_chin`, `name_eng`, `desc_eng`, `status`, `sort`, `create_time`, `update_time`, `is_frontpage`) VALUES (1,1,0,'/img/abc.png','主打','cat1_desc','Unique Dishes','',1,1,'2016-07-25','2016-07-25',1),(2,0,0,'/img/abc.png','小食','cat2_desc','Snacks','',1,2,'2016-07-25','2016-07-25',1),(3,0,1,'/img/abc.png','Subcat3','cat3_desc','','',1,3,'2016-07-25','2016-07-25',0),(4,0,1,'/img/abc.png','Subcat4','cat4_desc','','',1,4,'2016-07-25','2016-07-25',0),(5,0,1,'/img/abc.png','SubCat5','cat5_desc','','',1,5,'2016-07-25','2016-07-25',0),(6,0,0,'/img/abc.png','湯類','cat6_desc','Soup','',1,6,'2016-07-25','2016-07-25',0),(7,1,0,'/img/abc.png','飲品','cat7_desc','Drinks','',1,7,'2016-07-25','2016-07-25',1),(8,0,0,'/img/abc.png','豬','cat8_desc','Pork','',1,8,'2016-07-25','2016-07-25',1),(9,0,0,'/img/abc.png','牛','cat9_desc','Beef','',1,9,'2016-07-25','2016-07-25',1),(10,1,0,'/img/abc.png','雞','','Chicken','',1,0,'0000-00-00','0000-00-00',0),(11,1,0,'/img/abc.png','海產類','','Seafood','',1,0,'0000-00-00','0000-00-00',0),(12,1,0,'/img/abc.png','素菜類','','Vegetables','',1,0,'0000-00-00','0000-00-00',0),(13,1,0,'/img/abc.png','主食(粉麵飯)','','Noodle&Rice','',1,0,'0000-00-00','0000-00-00',0),(14,1,0,'/img/abc.png','套餐','','Set Menu','',1,0,'0000-00-00','0000-00-00',0),(15,1,0,'/img/abc.png','海鮮總會','','Featured Seafood','',1,0,'0000-00-00','0000-00-00',0),(16,1,7,'/img/abc.png','酒精類','','Beer&Wine','',1,0,'0000-00-00','0000-00-00',0),(17,0,16,'/img/abc.png','啤酒類','','Beer','',0,1,'0000-00-00','0000-00-00',0),(18,1,16,'/img/abc.png','紅酒類','','Red&white wine','',0,1,'0000-00-00','0000-00-00',0),(19,0,16,'/img/abc.png','酒精類','','China Wine&Brandy','',0,1,'0000-00-00','0000-00-00',0),(20,0,18,'/img/abc.png','(杯)紅,白酒','','House Red & White','',1,0,'0000-00-00','0000-00-00',0),(21,0,18,'/img/abc.png','白酒','','White','',1,0,'0000-00-00','0000-00-00',0),(22,0,18,'/img/abc.png','紅酒','','Red','',1,0,'0000-00-00','0000-00-00',0),(23,0,18,'/img/abc.png','香檳','','Champagne','',1,0,'0000-00-00','0000-00-00',0);
/*!40000 ALTER TABLE `saiwan_categories_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_items`
--

DROP TABLE IF EXISTS `saiwan_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos_id` varchar(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `img` varchar(200) NOT NULL,
  `use_big_img` int(1) NOT NULL DEFAULT '0',
  `name_chin` varchar(200) NOT NULL,
  `desc_chin` varchar(200) NOT NULL,
  `name_eng` varchar(200) NOT NULL,
  `desc_eng` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=241 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_items`
--

LOCK TABLES `saiwan_items` WRITE;
/*!40000 ALTER TABLE `saiwan_items` DISABLE KEYS */;
INSERT INTO `saiwan_items` (`id`, `pos_id`, `category_id`, `img`, `use_big_img`, `name_chin`, `desc_chin`, `name_eng`, `desc_eng`, `price`, `status`, `sort_order`, `created_at`, `updated_at`) VALUES (138,'',56,'/upload/images/DSC01049.png',1,'花竹蝦','豉油皇乾煎<br>\r\n茄汁乾煎<br>\r\n生者胡椒焗<br>\r\n蒜茸開邊蒸<br>\r\n椒鹽<br>\r\n白灼<br>','Japanese King Prawn','Pan-Fried w/Soy Sauce<br>\r\nPan-Fried w/Fresh Tomato Sauce<br>\r\nPepper in Stone Casserole<br>\r\nSteamed w/Garlic<br>\r\nSalty Pepper<br>\r\nBoiled<br>',0,1,20,'2017-01-10 07:37:22','2017-01-09 23:37:22'),(137,'',28,'/upload/images/DSC01049.png',0,'中蝦仔','豉油皇乾煎<br>\r\n茄汁乾煎<br>\r\n生者胡椒焗<br>\r\n蒜茸開邊蒸<br>\r\n椒鹽<br>\r\n白灼<br>','Shrimps','Pan-Fried w/Soy Sauce<br>\r\nPan-Fried w/Fresh Tomato Sauce<br>\r\nPepper in Stone Casserole<br>\r\nSteamed w/Garlic<br>\r\nSalty Pepper<br>\r\nBoiled<br>',0,0,1,'2017-01-09 10:29:35','2017-01-09 02:29:35'),(136,'',28,'/upload/images/DSC01049.png',0,'中蝦','豉油皇乾煎<br>\r\n茄汁乾煎<br>\r\n生者胡椒焗<br>\r\n蒜茸開邊蒸<br>\r\n椒鹽<br>\r\n白灼<br>','Prawns','Pan-Fried w/Soy Sauce<br>\r\nPan-Fried w/Fresh Tomato Sauce<br>\r\nPepper in Stone Casserole<br>\r\nSteamed w/Garlic<br>\r\nSalty Pepper<br>\r\nBoiled<br>',0,0,0,'2016-12-22 11:18:24','2016-12-22 11:18:24'),(135,'',27,'/upload/images/abc.png',0,'蜆','豉椒炒<br>\r\n油鹽水浸<br>\r\n隔水蒸<br>','Clams','Black Bean Sauce<br>\r\nBraised<br>\r\nSteamed<br>',0,0,5,'2017-01-16 11:46:34','2017-01-16 03:46:34'),(134,'',27,'/upload/images/abc.png',0,'砂蜆','豉椒炒<br>\r\n油鹽水浸<br>\r\n隔水蒸<br>','Sand Clams','Black Bean Sauce<br>\r\nBraised<br>\r\nSteamed<br>',0,0,6,'2017-01-16 11:46:53','2017-01-16 03:46:53'),(133,'',27,'/upload/images/abc.png',0,'珍珠蛤','清蒸','Pearl Clams','Steamed',0,0,7,'2017-01-16 11:47:10','2017-01-16 03:47:10'),(132,'',27,'/upload/images/DSC01011.png',0,'花螺','白灼<br>\r\n辣酒煮<br>','Snail','Boiled<br>\r\nSpicy Liqour<br>',0,0,8,'2017-01-16 11:47:38','2017-01-16 03:47:38'),(131,'',27,'/upload/images/DSC01036.png',0,'花蛤','豉椒炒<br>\r\n油鹽水浸<br>\r\n隔水蒸<br>','Venus Clams','Black Bean Sauce<br>\r\nBraised<br>\r\nSteamed<br>',0,0,9,'2017-01-16 11:47:57','2017-01-16 03:47:57'),(236,'',56,'/upload/images/DSC00961.jpg',1,'鮮帶子芝士沙拉菜','','','',98,1,0,'2017-01-09 02:56:07','2017-01-09 02:56:07'),(130,'',56,'/upload/images/DSC01022.png',1,'蒜茸粉絲蒸元貝','豉椒炒<br>\r\n蒜茸粉絲蒸<br>\r\n清蒸<br>\r\n白汁香草焗<br>','Scallop','Black Bean Sauce<br>\r\nSteamed w/Garlic<br>\r\nSteamed<br>\r\nCream Sauce w/Herbs<br>',0,1,0,'2017-01-09 11:03:37','2017-01-09 03:03:37'),(129,'',56,'/upload/images/IMG_48782.png',1,'豉椒炒聖子皇','豉椒炒<br>\r\n蒜茸粉絲蒸<br>\r\n白灼<br>\r\n白汁香草焗<br>','Razor Clam','Black Bean Sauce<br>\r\nSteamed w/Garlic<br>\r\nBoiled<br>\r\nCream Sauce w/Herbs<br>',0,1,50,'2017-01-23 10:17:57','2017-01-23 02:17:57'),(128,'5386',13,'/upload/images/IMG_4926.JPG',0,'龍皇脆泡飯','','Medley of Seafood with Crispy Rice in Seafood Broth','',118,1,0,'2016-12-22 11:20:27','2016-12-22 11:20:27'),(127,'5180',13,'/upload/images/DSC01153.jpg',0,'鮑魚汁海皇炆飯','','Seafood Rice with Abalone Sauce','',118,1,0,'2016-12-22 11:20:36','2016-12-22 11:20:36'),(126,'5436',13,'/upload/images/IMG_4934.JPG',0,'濃雞湯海皇湯烏冬','','Udon with Seafood in Soup','',118,1,10,'2017-01-16 11:33:59','2017-01-16 03:33:59'),(125,'5616',13,'/upload/images/DSC01168.jpg',0,'頂上麻油素菜炒烏冬','','Udon Fried with Fresh Vegetable in Superior Sesame Oil','',88,1,0,'2016-12-22 11:20:52','2016-12-22 11:20:52'),(124,'5382',13,'/upload/images/1148.jpg',0,'豉油皇炒麵','','Sauteed Egg Noodles with Leek in Soy Sauce','',78,1,0,'2016-12-22 11:20:58','2016-12-22 11:20:58'),(123,'5617',13,'/upload/images/DSC01186.jpg',0,'馬拉炒米粉','','Fried Rice Vermicelli in Malaysian Style','',98,1,0,'2016-12-22 11:21:05','2016-12-22 11:21:05'),(122,'5387',13,'/upload/images/IMG_4931.JPG',0,'小碼頭炒飯','','Fried Rice with Minced Pork & Prawn Dry Shell  Baby','',98,1,0,'2016-12-22 11:21:12','2016-12-22 11:21:12'),(121,'5615',13,'/upload/images/DSC01172.jpg',0,'XO醬頭抽炒牛河','','XO Sauce with Beef Rice Noodles','',98,1,0,'2016-12-22 11:21:19','2016-12-22 11:21:19'),(119,'5333',12,'/upload/images/blackBeanCurd.png',0,'黑松露醬燴豆腐','','Wok Braised Tofu with Wild Mushroom & Black Truffle Paste','',108,0,0,'2016-12-22 11:21:38','2016-12-22 11:21:38'),(235,'',56,'/upload/images/DSC00843.jpg',1,'意大利黑醋柚子爽豬手','','','',148,1,2,'2017-01-09 02:51:15','2017-01-09 02:51:15'),(118,'',12,'/upload/images/DSC01225.png',0,'啫啫時蔬','','Sections of Vegetables with Saltedfish & XO Sauce in Stone Casserole','',88,0,0,'2016-12-22 11:21:46','2016-12-22 11:21:46'),(165,'',1,'/upload/images/DSC00709.jpg',0,'嘩娃搖擺雞(半隻)','','Thai Style Chicken with Hot & Sour Sauce(Half)','',188,1,0,'2016-12-22 11:14:21','2016-12-22 11:14:21'),(167,'',1,'/upload/images/IMG_48782.png',0,'豉汁炒聖子皇','時價','Razor Clam with Black Bean Sauce','Seasonal Price',148,1,0,'2016-12-22 11:14:08','2016-12-22 11:14:08'),(116,'5303',12,'/upload/images/DSC01189.jpg',0,'海皇雜菜煲','','Seafood & Mixed Vegetable in Casserole','',128,1,0,'2016-12-22 11:21:55','2016-12-22 11:21:55'),(114,'2095',12,'/upload/images/DSC01200.jpg',0,'田園地三鮮','','Stir-fried Eggplant, Potato & Red Pepper','',88,1,0,'2016-12-22 11:22:04','2016-12-22 11:22:04'),(163,'',9,'/upload/images/DSC01275.jpg',0,'鐵壺水火炙韓式燒牛頸脊','','Fire Burning Corher Beef with Cheese Korean Veg & Tofu in Soup','',198,1,0,'2016-12-22 11:14:36','2016-12-22 11:14:36'),(113,'2082',12,'/upload/images/DSC01192.jpg',0,'日式芥末炒芥蘭','','Chinese Kale with Japan Wasabi','',88,1,0,'2016-12-22 11:22:13','2016-12-22 11:22:13'),(112,'5373',58,'/upload/images/IMG_4843.JPG',0,'鮮茄醬乾燒蝦球','','Sauteed Prawn Balls with Organic Tomato Sauce','',138,1,0,'2017-01-02 08:22:02','2017-01-02 00:22:02'),(232,'',59,'/upload/images/DSC00965.jpg',1,'鮮蝦胡麻芝士沙拉菜','','','',98,1,0,'2017-01-09 01:21:21','2017-01-09 01:21:21'),(110,'2557',58,'/upload/images/DSC00798.jpg',0,'避風塘九肚魚','','Deep-fried Kau Fish with Chili & Garlic','',128,1,0,'2017-01-02 08:22:28','2017-01-02 00:22:28'),(109,'',58,'/upload/images/20160925_155117.jpg',0,'薑蔥焗桶蠔','','Baked Oyster with Ginger and Scallion','',168,1,0,'2017-01-02 08:23:16','2017-01-02 00:23:16'),(107,'',58,'/upload/images/DSC01072.jpg',0,'碼頭香辣魚','','Habour Tasty & Spicy Fish','',488,1,0,'2017-01-02 08:25:32','2017-01-02 00:25:32'),(106,'',55,'/upload/images/DSC01283.jpg',0,'蒜香酥炸海魚','','Garlic & Deep-fried Fish','',288,1,0,'2016-12-30 10:40:12','2016-12-30 02:40:12'),(105,'6047',58,'/upload/images/DSC00753.jpg',0,'椒鹽鮮魷','','Deep-fried Squid','',128,1,0,'2017-01-02 08:26:11','2017-01-02 00:26:11'),(104,'',58,'/upload/images/DSC01268.jpg',0,'浦燒日本冰蠔(6隻)','','Deep-fried Japanese Oyster with Japanese Sauce','',138,1,0,'2017-01-02 08:27:01','2017-01-02 00:27:01'),(103,'',58,'/upload/images/20161007_144605.jpg',0,'蜜味胡椒焗海蝦','','Pepper Shrimp in Stone Casserole','',208,1,0,'2017-01-02 08:28:07','2017-01-02 00:28:07'),(102,'5370',58,'/upload/images/DSC00603.png',0,'杏片芥末蝦球','','Fried Prawns Ball with Toasted Almonds & Wasabi','',138,0,0,'2017-01-02 08:28:37','2017-01-02 00:28:37'),(101,'',58,'/upload/images/20160925_154848.jpg',0,'冰鎮鮑魚(2隻起)','','Iced Fresh Abalone(two pieces up)','',88,1,0,'2017-01-02 08:29:37','2017-01-02 00:29:37'),(100,'5362',10,'/upload/images/IMG_4807.JPG',0,'霸氣辣子雞','','Sauteed Diced Chicken with Red Chilli','',138,0,0,'2016-12-22 11:32:49','2016-12-22 11:32:49'),(99,'5608',10,'/upload/images/DSC00991.jpg',0,'雞糧煮雞露','鮮雞湯烹調煮健康谷米(健康谷米包含藜麥,薏仁,小黃米)\r\n含有豐富纖維生素','Steamed Chicken Cooked in Chicken Stock with Chicken Dew','',138,1,0,'2016-12-22 11:32:55','2016-12-22 11:32:55'),(98,'5607',10,'/upload/images/DSC00709.jpg',0,'嘩娃搖擺雞(半隻)','','Thai Style Chicken with Hot & Sour Sauce(Half)','',188,1,0,'2016-12-22 11:33:02','2016-12-22 11:33:02'),(97,'5242',10,'/upload/images/DSC00787.jpg',0,'芝麻脆皮雞(半隻)','','Crispy Chicken with Seasame(Half)','',188,0,0,'2016-12-22 11:33:09','2016-12-22 11:33:09'),(96,'5606',10,'/upload/images/DSC00776.jpg',0,'吹脹鑼豉雞(半隻)','','Wind Dried Style Wine Marinade Chicken(Half)','',188,1,0,'2016-12-22 11:33:16','2016-12-22 11:33:16'),(95,'5605',10,'/upload/images/DSC00721.jpg',0,'小辣椒呷醋雞','','Sze Chuwan Style Spicy Sour Chicken','',108,0,0,'2016-12-22 11:33:29','2016-12-22 11:33:29'),(93,'919',9,'/upload/images/DSC01212.jpg',0,'薑皇蔥蒜爆鮮牛肩脊','','Beef with Ginger, Garlic & Onion','',138,1,0,'2016-12-22 11:33:36','2016-12-22 11:33:36'),(92,'942',9,'/upload/images/DSC00684.jpg',0,'濱紛紅酒雪梨經典牛扒','','Steak with Pear and Red Wine Vinegar on Side','',168,0,0,'2016-12-22 11:33:44','2016-12-22 11:33:44'),(90,'890',9,'/upload/images/DSC00742.png',0,'特選牛肋排醬帥','','Prime Rib with House Special & XO Sauce','',168,1,0,'2016-12-22 11:33:52','2016-12-22 11:33:52'),(89,'918',9,'/upload/images/DSC01215.jpg',0,'法式和牛粒','','French Style Cubed Wagyu Beef','',148,0,0,'2016-12-22 11:34:01','2016-12-22 11:34:01'),(88,'917',9,'/upload/images/DSC00970.jpg',0,'老巷熗黃牛崩腩','','Stewed Beef Brisket with Chili in Chuan Style','',138,1,0,'2016-12-22 11:34:08','2016-12-22 11:34:08'),(86,'6172',8,'/upload/images/DSC00996.jpg',0,'飄風豆鹵肉','','Pan-fried Chinese Bacon with Bean Curd Sauce','',108,0,0,'2016-12-22 11:34:16','2016-12-22 11:34:16'),(85,'6171',8,'/upload/images/DSC00844.jpg',0,'意大利黑醋柚子爽豬手','','Pork Knuckle with Italian Vinegar & Grapefruit Sauce','',148,0,0,'2016-12-22 11:34:23','2016-12-22 11:34:23'),(84,'2622',8,'/upload/images/DSC00673.png',0,'意大利果醋黑毛豬','','Crisp Iberico Bellota with Italian Fruit Vinegar','',138,0,0,'2016-12-22 11:34:30','2016-12-22 11:34:30'),(83,'6173',8,'/upload/images/DSC00977.jpg',0,'酥香黃芥骨','','Yellow Mustard with Crispy Spare Ribs','',138,0,0,'2016-12-22 11:34:38','2016-12-22 11:34:38'),(81,'6168',8,'/upload/images/DSC00813.jpg',0,'冰鎮咕嚕肉','','Cold Pork Ribs in Sweet & Sour Sauce','',148,0,0,'2016-12-22 11:34:46','2016-12-22 11:34:46'),(80,'5340',8,'/upload/images/tai_o_fried_ribs.png',0,'大澳海山骨','','Marinated Spare Ribs in Ribs Preserved Shrimp','',118,0,0,'2016-12-22 11:34:54','2016-12-22 11:34:54'),(79,'',26,'/upload/images/DSC00919.png',0,'藍莓益力多芭菲','','Blueberry&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:03','2016-12-22 11:35:03'),(78,'',26,'/upload/images/DSC00936.png',0,'檸檬益力多芭菲','','Lemon&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:13','2016-12-22 11:35:13'),(77,'',26,'/upload/images/DSC00922.png',0,'綠茶益力多芭菲','','Green Tea&Yakult Sorbet','',36,1,0,'2016-12-22 11:35:21','2016-12-22 11:35:21'),(75,'',26,'/upload/images/DSC00911.png',0,'菠蘿益力多芭菲','','Pineapple&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:29','2016-12-22 11:35:29'),(74,'',26,'/upload/images/strawberrySorbet.png',0,'草莓益力多芭菲','','Staeberry&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:36','2016-12-22 11:35:36'),(73,'',26,'/upload/images/DSC01009.png',0,'咸柑桔益力多芭菲','','Salted Kumquat&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:43','2016-12-22 11:35:43'),(71,'',26,'/upload/images/kiwiforbet.png',0,'奇異果益力多芭菲','','Kiwi Fruit&Yakult Sorbet','',36,0,0,'2016-12-22 11:35:51','2016-12-22 11:35:51'),(69,'',42,'/upload/images/wpsorbet.png',1,'西瓜菠蘿益力多芭菲','','Watermeion&Pineapple Yakult Sorbet','',36,1,0,'2017-01-02 13:11:00','2017-01-02 05:11:00'),(68,'',26,'/upload/images/watermelonsorbet.png',0,'西瓜益力多芭菲','','Watermelon Yakult Sorbet','',36,1,0,'2016-12-22 11:36:12','2016-12-22 11:36:12'),(67,'',26,'/upload/images/DSC00903.png',0,'火龍果菠蘿益力多芭菲','','Dragon Fruil&Pineapple Yakult Sorbet','',36,1,0,'2016-12-22 11:36:18','2016-12-22 11:36:18'),(66,'',26,'/upload/images/DSC00890.png',0,'(熱)柚子檸檬','','Hony Pomlow Lemon(Hot)','',36,1,0,'2016-12-22 11:36:28','2016-12-22 11:36:28'),(65,'',26,'/upload/images/20161109_141727.jpg',0,'(熱)台灣黑糖薑母茶','','Ginger Tea with Black Sugar(Hot)','',40,1,0,'2016-12-22 11:36:35','2016-12-22 11:36:35'),(64,'',26,'/upload/images/DSC00893.png',0,'(凍)柚子檸檬','Hony Pomlow Lemon(Cold)','','',36,1,0,'2016-12-22 11:36:42','2016-12-22 11:36:42'),(62,'',25,'/upload/images/DSC00854.png',0,'無糖可樂','','Coke Zero','',12,1,0,'2016-12-22 11:36:51','2016-12-22 11:36:51'),(63,'',25,'/upload/images/DSC00888.png',0,'蒸餾水','','Water','',15,1,0,'2016-12-22 11:36:59','2016-12-22 11:36:59'),(60,'',25,'/upload/images/DSC00883.png',0,'梳打水(Soda Water)$15','','Soda Water','',15,1,0,'2016-12-22 11:37:06','2016-12-22 11:37:06'),(61,'',25,'/upload/images/DSC00863.png',0,'雪碧','','Sprite','',12,1,0,'2016-12-22 11:37:13','2016-12-22 11:37:13'),(58,'',25,'/upload/images/DSC00881.png',0,'法國礦泉水','','Perrier Water','',28,0,0,'2016-12-22 11:37:21','2016-12-22 11:37:21'),(59,'',25,'/upload/images/DSC00859.png',0,'芬達橙汁','','Fanta','',12,0,0,'2016-12-22 11:37:29','2016-12-22 11:37:29'),(57,'',25,'/upload/images/DSC00861.png',0,'玉泉忌廉','','Cream','',12,0,0,'2016-12-22 11:37:39','2016-12-22 11:37:39'),(56,'',25,'/upload/images/DSC00860.png',0,'可樂','','Coke','',12,0,0,'2016-12-22 11:37:51','2016-12-22 11:37:51'),(54,'',19,'/upload/images/DSC00661.png',0,'皖酒王','','','',0,0,0,'2016-12-22 11:38:11','2016-12-22 11:38:11'),(55,'',19,'/upload/images/DSC00659.png',0,'瀘州老窖','','','',0,0,0,'2016-12-22 11:38:19','2016-12-22 11:38:19'),(53,'',19,'/upload/images/DSC00653.png',0,'茅台鎮小瓶酒','','','',0,0,0,'2016-12-22 11:38:28','2016-12-22 11:38:28'),(49,'',19,'/upload/images/DSC00663.png',0,'北京二鍋頭白酒','','','',0,0,0,'2016-12-22 11:38:37','2016-12-22 11:38:37'),(50,'',19,'/upload/images/DSC00662.png',0,'玉山八年陳高','','','',0,0,0,'2016-12-22 11:38:47','2016-12-22 11:38:47'),(51,'',19,'/upload/images/abc.png',0,'男山尾張清酒(壺)','','','',0,0,0,'2016-12-22 11:38:56','2016-12-22 11:38:56'),(52,'',19,'/upload/images/DSC00667.png',0,'男山尾張清酒(支)','','','',0,0,0,'2016-12-22 11:39:03','2016-12-22 11:39:03'),(46,'',19,'/upload/images/DSC00645.png',0,'Whisky','','Whisky','',0,0,0,'2016-12-22 11:39:14','2016-12-22 11:39:14'),(47,'',19,'/upload/images/DSC00664.png',0,'十年紹興酒(加飯)','','','',0,0,0,'2016-12-22 11:39:22','2016-12-22 11:39:22'),(48,'',19,'/upload/images/DSC00669.png',0,'大呤釀','','','',0,1,0,'2016-12-22 11:40:39','2016-12-22 11:40:39'),(43,'8138',23,'/upload/images/DSC00670.png',0,'Hello kitty香檳','','','',588,0,0,'2016-12-22 11:40:46','2016-12-22 11:40:46'),(44,'',19,'/upload/images/DSC00651.png',0,'Cordon Blue','','Cordon Blue','',0,0,0,'2016-12-22 11:40:53','2016-12-22 11:40:53'),(45,'',19,'/upload/images/DSC00652.png',0,'Hennesy XO','','Hennesy XO','',0,0,0,'2016-12-22 11:41:00','2016-12-22 11:41:00'),(41,'8130',22,'/upload/images/DSC00638.png',0,'(F)蒙泰堡','','(F)Chateau Montaigne','',388,0,0,'2016-12-22 11:41:06','2016-12-22 11:41:06'),(42,'8131',22,'/upload/images/DSC00604.png',0,'(G)卡迪亞紅酒','','(G)Carta Vieja Merlot Red Wine','',328,0,0,'2016-12-22 11:41:13','2016-12-22 11:41:13'),(39,'8127',22,'/upload/images/DSC00644.png',0,'(C)Nexus Crizana 2009','','(C)Nexus Crizana 2009','',488,0,0,'2016-12-22 11:41:19','2016-12-22 11:41:19'),(40,'8129',22,'/upload/images/DSC00852.png',0,'(E)拉新度珍藏','','(E)Licenciado Reserva','',698,0,0,'2016-12-22 11:41:40','2016-12-22 11:41:40'),(229,'',59,'/upload/images/DSC00759.jpg',1,'淚汪汪棒棒雞','','','',58,1,0,'2017-01-09 01:19:19','2017-01-09 01:19:19'),(237,'',56,'/upload/images/DSC01179.jpg',1,'鐵壺水火炙燒牛頸脊','','','',178,1,0,'2017-01-09 02:56:42','2017-01-09 02:56:42'),(34,'8132',21,'/upload/images/20161207_150022.jpg',0,'(H)卡迪亞白酒','','(H)Carta Vieja Merlot White Wine','',328,1,0,'2016-12-22 11:41:46','2016-12-22 11:41:46'),(35,'8133',21,'/upload/images/DSC00615.png',0,'(I)薩維尼2011','','(I)Savigny Les-beaune 2011','',488,0,0,'2016-12-22 11:41:53','2016-12-22 11:41:53'),(31,'8142',20,'/upload/images/DSC00948.png',0,'餐紅酒','','House White Wine','',78,0,0,'2016-12-22 11:42:00','2016-12-22 11:42:00'),(226,'',59,'/upload/images/DSC01150.jpg',1,'冰鎮胡麻醬芥蘭','','','',68,1,0,'2017-01-09 01:17:18','2017-01-09 01:17:18'),(227,'',59,'/upload/images/DSC01235.jpg',1,'冰鎮話梅涼瓜','','','',68,1,0,'2017-01-09 01:18:18','2017-01-09 01:18:18'),(28,'',17,'/upload/images/DSC00867.png',0,'嘉士伯啤','','Carisberg','',42,1,0,'2016-12-22 11:42:07','2016-12-22 11:42:07'),(29,'',17,'/upload/images/DSC00878.png',0,'藍妹啤','','Blue Girl','',42,0,0,'2016-12-22 11:42:15','2016-12-22 11:42:15'),(30,'8141',20,'/upload/images/DSC00944.png',0,'餐白酒','','House Red Wine','',78,0,0,'2016-12-22 11:42:22','2016-12-22 11:42:22'),(25,'',17,'/upload/images/DSC00889.png',0,'細藍妹啤','','Small Blue Girl','',28,1,0,'2016-12-22 11:42:31','2016-12-22 11:42:31'),(26,'',17,'/upload/images/DSC00866.png',0,'喜力啤','','Heineken','',42,0,0,'2016-12-22 11:42:38','2016-12-22 11:42:38'),(27,'',17,'/upload/images/DSC00872.png',0,'朝日啤','','Asahi','',42,0,0,'2016-12-22 11:42:45','2016-12-22 11:42:45'),(22,'',17,'/upload/images/DSC00869.png',0,'生力啤','','San Miguel','',42,0,0,'2016-12-22 11:42:52','2016-12-22 11:42:52'),(23,'',17,'/upload/images/DSC00876.png',0,'青島啤','','TsingTao','',42,0,0,'2016-12-22 11:42:59','2016-12-22 11:42:59'),(24,'',17,'/upload/images/DSC00874.png',0,'健力士啤','','Guinness Stout','',48,0,0,'2016-12-22 11:43:08','2016-12-22 11:43:08'),(231,'',59,'/upload/images/DSC00961.jpg',1,'鮮帶子芝士沙拉菜','','','',98,1,0,'2017-01-09 01:20:52','2017-01-09 01:20:52'),(215,'',60,'/upload/images/amd-civilizationVI-key-art-game-detail-9642.jpg',0,'海皇雜菜煲','菜式以較少脂肪或油分,鹽分及糖分烹調或製作,符合[3少之選]的要求','Fried Mixed Vegetable','The dish has less fat or oil,salt and sugar,meeting the[3 Less]requirement',128,1,0,'2017-01-03 10:58:42','2017-01-03 10:58:42'),(21,' ',17,'/upload/images/DSC00879.png',0,'1664啤(花香味)','','1664Blang','',34,0,0,'2016-12-22 11:43:16','2016-12-22 11:43:16'),(18,'5316',6,'/upload/images/20160926_151348.jpg',0,'(四位)瓦撐燉湯','','Day Soup','',138,1,0,'2016-12-22 11:43:26','2016-12-22 11:43:26'),(16,'5613',2,'/upload/images/DSC00964.jpg',0,'鮮蝦胡麻芝士沙拉菜','','Shrimp Salad with Japanese Shabu Sauce','',98,0,0,'2016-12-22 11:43:32','2016-12-22 11:43:32'),(15,'5612',2,'/upload/images/DSC00961.jpg',0,'鮮帶子芝士沙拉菜','','Fresh Scallop Cheese Salad with Italian Vinegar','',98,0,0,'2016-12-22 11:43:39','2016-12-22 11:43:39'),(166,'',1,'/upload/images/DSC00673.png',0,'意大利果醋黑毛豬','','Crispy Lberico Bellota with Ltalian Fruit Vinegar','',138,1,0,'2016-12-22 11:14:15','2016-12-22 11:14:15'),(14,'2552',2,'/upload/images/DSC01230.jpg',0,'冰鎮話梅涼瓜','','Cold Bitter Melon in Salty Plum Sauce','',68,0,0,'2016-12-22 11:43:46','2016-12-22 11:43:46'),(11,'5307',2,'/upload/images/DSC00773.png',0,'晾衣白肉','','Sliced Pork Belly with Tasty Shanghai Vinaigrette','',68,0,0,'2016-12-22 11:43:53','2016-12-22 11:43:53'),(12,'5301',2,'/upload/images/DSC00763.png',0,'黃金沙豆腐','','Deep-fried Cubed Tofu with Garlic','',68,0,0,'2016-12-22 11:44:01','2016-12-22 11:44:01'),(8,'5614',2,'/upload/images/DSC_0117.png',0,'芝士粒粒','','Deep-fried Cheese Ball','',78,0,0,'2016-12-22 11:44:08','2016-12-22 11:44:08'),(10,'5609',2,'/upload/images/DSC00760.jpg',0,'淚汪汪棒棒雞','','Shredded Chicken with Spicy & Peanut Butter Sauce','',58,0,0,'2016-12-22 11:44:23','2016-12-22 11:44:23'),(7,'2589',2,'/upload/images/20160925_143527.jpg',0,'西班牙黑毛豬火腿片','','Iberico Ham-bellota (48 Months)','',148,1,0,'2016-12-22 11:44:31','2016-12-22 11:44:31'),(230,'',59,'/upload/images/DSC_0117.jpg',1,'芝士粒粒','','','',78,1,1,'2017-01-09 10:50:46','2017-01-09 02:50:46'),(6,'5491',2,'/upload/images/DSC01150.jpg',0,'冰鎮胡麻醬芥蘭','','Cold Chinese Broccoli with Shabu Sauce','',68,1,0,'2016-12-22 11:44:41','2016-12-22 11:44:41'),(228,'',59,'/upload/images/DSC00773.jpg',1,'晾衣白肉','','','',68,1,0,'2017-01-09 01:18:46','2017-01-09 01:18:46'),(91,'941',9,'/upload/images/IMG_4816.JPG',0,'意式蕃茄燴牛尾','','Italian Style Braised OX Tail with Red Wine ','',148,0,0,'2016-12-22 11:44:57','2016-12-22 11:44:57'),(82,'6170',8,'/upload/images/DSC00835.png',0,'蘇杭東坡肉','','Braised Porak Belly with Sweety Dark Vinegar','',108,1,0,'2016-12-26 08:13:35','2016-12-26 00:13:35'),(76,'',26,'/upload/images/abc.png',0,'楺子益力多芭菲','','Tangerine&Yakult Sorbet','',36,0,0,'2016-12-22 11:45:12','2016-12-22 11:45:12'),(72,'',26,'/upload/images/DSC00896.png',0,'青檸榭','','Honey-made Lemonade','',36,0,0,'2016-12-22 11:45:18','2016-12-22 11:45:18'),(70,'',26,'/upload/images/DSC00906.png',0,'芒果益力多芭菲','','Mango&Yakult Sorbet','',36,0,0,'2016-12-22 11:45:25','2016-12-22 11:45:25'),(120,'2100',12,'/upload/images/DSC01244.jpg',0,'鮮蕃茄茸露筍西蘭花','','Stir-fried Asperge & Brocoli in Fresh Tomato Sauce','',98,1,0,'2016-12-22 11:45:32','2016-12-22 11:45:32'),(139,'',29,'/upload/images/abc.png',0,'杉斑','海鹽蒸<br>\r\n清蒸<br>\r\n古法炆<br>\r\n煎封<br>','Camouflage Grouper','Steamed w/Sea Salt<br>\r\nSteamed<br>\r\nSimmer w/Bean Curd & Vegetables<br>\r\nPan-fried<br>',0,0,0,'2016-12-22 11:17:57','2016-12-22 11:17:57'),(140,'',29,'/upload/images/abc.png',0,'東星斑','海鹽蒸<br>\r\n清蒸<br>\r\n古法炆<br>\r\n煎封<br>','Leopard Coral Grouper','Steamed w/Sea Salt<br>\r\nSteamed<br>\r\nSimmer w/Bean Curd & Vegetables<br>\r\nPan-fried<br>',0,0,0,'2016-12-22 11:17:51','2016-12-22 11:17:51'),(141,'',29,'/upload/images/DSC01064.png',0,'碼頭香辣魚','','','',0,0,0,'2016-12-22 11:17:44','2016-12-22 11:17:44'),(142,'',30,'/upload/images/whiteGeoduck.png',0,'加州蚌','剌身<br>\r\n堂灼<br>\r\nXO醬炒<br>\r\n油泡<br>','Californian Geoduck','Sashimi<br>\r\nBoiled<br>\r\nFried w/XO Sauce<br>\r\nStir-fried<br>',0,0,0,'2016-12-22 11:17:37','2016-12-22 11:17:37'),(143,'',30,'/upload/images/whiteGeoduck.png',0,'加拿大蚌','剌身<br>\r\n堂灼<br>\r\nXO醬炒<br>\r\n油泡<br>','Canadian Geoduck','Sashimi<br>\r\nBoiled<br>\r\nFried w/XO Sauce<br>\r\nStir-fried<br>',0,0,0,'2016-12-22 11:17:20','2016-12-22 11:17:20'),(144,'',31,'/upload/images/IMG_4892.png',0,'啫啫鮑魚','堂灼<br>\r\nXO醬炒<br>\r\n石鍋炒<br>\r\n果皮蒸<br>\r\n椒鹽<br>\r\n冰鎮<br>','','Boiled<br>\r\nFried w/XO Sauce<br>\r\nFried w/Ginger & Scallion<br>\r\nSteamed w/ Dried Tangerine Peel<br>\r\nSalty Pepper<br>\r\nCold w/Wine & Sauce<br>',0,0,0,'2016-12-22 11:17:13','2016-12-22 11:17:13'),(145,'',32,'/upload/images/lobsterSashimi.png',0,'本地龍蝦','堂灼<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n上湯焗<br>\r\n芝士牛油焗<br>\r\n剌身<br>\r\n薑蔥炒<br>','','Boiled<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nSupreme Soup<br>\r\nBaked Cheese & Butter<br>\r\nSashimi<br>\r\nFried w/ Ginger & Scallion<br>',0,0,0,'2016-12-22 11:17:05','2016-12-22 11:17:05'),(146,'',32,'/upload/images/lobsterSashimi.png',0,'杉龍','堂灼<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n上湯焗<br>\r\n芝士牛油焗<br>\r\n剌身<br>\r\n薑蔥炒<br>','','Boiled<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nSupreme Soup<br>\r\nBaked Cheese & Butter<br>\r\nSashimi<br>\r\nFried w/ Ginger & Scallion<br>\r\n',0,0,0,'2016-12-22 11:16:57','2016-12-22 11:16:57'),(147,'',32,'/upload/images/lobsterSashimi.png',0,'法國藍龍','堂灼<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n上湯焗<br>\r\n芝士牛油焗<br>\r\n剌身<br>\r\n薑蔥炒<br>','','Boiled<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nSupreme Soup<br>\r\nBaked Cheese & Butter<br>\r\nSashimi<br>\r\nFried w/ Ginger & Scallion<br>',0,0,0,'2016-12-22 11:16:37','2016-12-22 11:16:37'),(148,'',32,'/upload/images/lobsterSashimi.png',0,'剌身','堂灼<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n上湯焗<br>\r\n芝士牛油焗<br>\r\n剌身<br>\r\n薑蔥炒<br>','','\r\nBoiled<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nSupreme Soup<br>\r\nBaked Cheese & Butter<br>\r\nSashimi<br>\r\nFried w/ Ginger & Scallion<br>',0,0,0,'2016-12-22 11:16:31','2016-12-22 11:16:31'),(149,'',32,'/upload/images/lobsterSashimi.png',0,'澳洲龍蝦','堂灼<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n上湯焗<br>\r\n芝士牛油焗<br>\r\n剌身<br>\r\n薑蔥炒<br>','','Boiled<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nSupreme Soup<br>\r\nBaked Cheese & Butter<br>\r\nSashimi<br>\r\nFried w/ Ginger & Scallion<br>',0,0,0,'2016-12-22 11:16:24','2016-12-22 11:16:24'),(150,'',33,'/upload/images/IMG_4909.png',0,'泰國尿蝦皇','白灼<br>\r\n椒鹽<br>\r\n花雕蛋白蒸<br>','Big Maints Shrimps','Boiled<br>\r\nSalty Pepper<br>\r\nSteamed w/Egg White &Yellow Wine<br>',0,0,0,'2016-12-22 11:16:17','2016-12-22 11:16:17'),(151,'',33,'/upload/images/IMG_4909.png',0,'斑馬尿蝦皇','白灼<br>\r\n椒鹽<br>\r\n花雕蛋白蒸<br>\r\n','','Boiled<br>\r\nSalty Pepper<br>\r\nSteamed w/Egg White &Yellow Wine<br>',0,0,0,'2016-12-22 11:16:08','2016-12-22 11:16:08'),(152,'',34,'/upload/images/DSC01082.png',0,'肉蟹','避風塘炒<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n薑蔥炒<br>\r\n花雕蛋白蒸<br>','','Fried Chili & Garlic<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nFried w/ Ginger & Scallion<br>\r\nSteamed Egg White & Yellow Wine<br>',0,0,0,'2016-12-22 11:16:00','2016-12-22 11:16:00'),(153,'',34,'/upload/images/DSC01082.png',0,'奄仔蟹','避風塘炒<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n薑蔥炒<br>\r\n花雕蛋白蒸<br>','Om Aberdeen Kuwana','Fried Chili & Garlic<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nFried w/ Ginger & Scallion<br>\r\nSteamed Egg White & Yellow Wine<br>',0,0,0,'2016-12-22 11:15:51','2016-12-22 11:15:51'),(154,'',34,'/upload/images/DSC01082.png',0,'重皮蟹','避風塘炒<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n薑蔥炒<br>\r\n花雕蛋白蒸<br>\r\n','Heavy Leather Kuwana','Fried Chili & Garlic<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nFried w/ Ginger & Scallion<br>\r\nSteamed Egg White & Yellow Wine<br>',0,0,0,'2016-12-22 11:15:42','2016-12-22 11:15:42'),(155,'',34,'/upload/images/DSC01082.png',0,'羔蟹','避風塘炒<br>\r\nXO醬炒<br>\r\n椒鹽<br>\r\n薑蔥炒<br>\r\n花雕蛋白蒸<br>','','Fried Chili & Garlic<br>\r\nFried w/XO Sauce<br>\r\nSalty Pepper<br>\r\nFried w/ Ginger & Scallion<br>\r\nSteamed Egg White & Yellow Wine<br>',0,0,0,'2016-12-22 11:15:34','2016-12-22 11:15:34'),(156,'',14,'/upload/images/setfor1east.png',1,'中式套餐 (每位 $588)','','Chinese Style Set ($588/ Person)','',0,0,0,'2016-12-22 11:15:26','2016-12-22 11:15:26'),(157,'',14,'/upload/images/114.JPG',1,'二人套餐','','two person set menu','',1088,1,0,'2016-12-22 11:15:18','2016-12-22 11:15:18'),(158,'',14,'/upload/images/setfor4soup.png',1,'柴鑊濃湯海鮮總匯','','Seafood Combination with Soup in Wok','',1688,0,0,'2017-01-24 11:29:09','2017-01-24 03:29:09'),(159,'',14,'/upload/images/setfor1west.png',1,'西式套餐 (每位 $588)','','Western Style Set ($588/person)','',0,0,0,'2016-12-22 11:14:50','2016-12-22 11:14:50'),(160,'',14,'/upload/images/setfor4steam.png',1,'海鮮總匯蒸鍋','','Seafood Combination with Steamed Pot','',2088,0,0,'2016-12-22 11:14:43','2016-12-22 11:14:43'),(164,'',56,'/upload/images/DSC01275.jpg',0,'鐵壺水火炙韓式燒牛頸脊','','Fire Burning Corher Beef with Cheese Korean Veg & Tofu in Soup','',198,1,0,'2017-01-02 08:42:50','2017-01-02 00:42:50'),(168,'',1,'/upload/images/DSC01072.jpg',0,'碼頭香辣煮海魚','','Habour Taty & Spicy Fish ','',488,1,5,'2016-12-22 11:14:02','2016-12-22 11:14:02'),(169,'',1,'/upload/images/DSC00961.jpg',0,'鮮帶子芝士沙拉菜','','Fresh Scallop Cheese Salad with Ltalian Vinegar','',98,1,0,'2016-12-22 11:13:37','2016-12-22 11:13:37'),(170,'',1,'/upload/images/DSC01300.jpg',0,'法式羅勒忌廉焗龍蝦','','Lobster with French Pernod & Cream Sauce','',298,1,0,'2016-12-22 11:13:30','2016-12-22 11:13:30'),(171,'',58,'/upload/images/DSC01283.jpg',0,'蒜香酥炸海魚','','Garlic & Deep-fried Fish','',288,1,0,'2017-01-02 08:30:31','2017-01-02 00:30:31'),(172,'',8,'/upload/images/20160921_151927.jpg',0,'天然蔬菜汁咕嚕肉','','Sweet & Sour Pork with Natural Vegtable Sauce','',118,1,0,'2016-12-22 11:13:02','2016-12-22 11:13:02'),(174,'',11,'/upload/images/20160926_152913.jpg',0,'滑蛋炒蝦球','','Surambled Egg with Prawn Balls','',138,1,0,'2016-12-22 11:12:47','2016-12-22 11:12:47'),(175,'',9,'/upload/images/20160926_153452.jpg',0,'芝士金菇和牛粒','','Cubed Wagyu Beef with Japanese Mushrooms & Cream Chees in Stone Cassrole','',148,1,0,'2016-12-22 11:12:26','2016-12-22 11:12:26'),(176,'',2,'/upload/images/20160927_210618.jpg',0,'黑松露醬蝦多士','','Shrimp Toast with Black Truffle Paste','',128,1,1,'2016-12-22 11:12:18','2016-12-22 11:12:18'),(233,'',59,'/upload/images/DSC00763.jpg',1,'黃金沙豆腐','','','',68,1,0,'2017-01-09 01:21:53','2017-01-09 01:21:53'),(178,'',6,'/upload/images/20160927_210848.jpg',0,'西湖牛肉羹','','Minced Beef Soup with Egg White & Chinese Parsley','',118,1,10,'2017-01-16 12:18:46','2017-01-16 04:18:46'),(179,'',11,'/upload/images/20160927_214001.jpg',0,'粟米脆蝦球','','Sweet Corn with Crisy Prawns','',138,1,0,'2016-12-22 11:11:56','2016-12-22 11:11:56'),(180,'',6,'/upload/images/20160928_144841.jpg',0,'雞茸露筍蕃茄羹','','Minced Chicken and Asparagus with Tomato','',118,1,11,'2017-01-16 12:18:53','2017-01-16 04:18:53'),(181,'',8,'/upload/images/20160928_144316.jpg',0,'黃金黑毛豬','','Iberico Bellota with Salted Egg Yolk','',108,1,0,'2016-12-22 11:11:43','2016-12-22 11:11:43'),(182,'',9,'/upload/images/20160927_214827.jpg',0,'粒粒脆牛肉粒','','Fried Cubed Wagyu Beef with Japanese Sauce','',128,1,0,'2016-12-22 11:11:35','2016-12-22 11:11:35'),(183,'',9,'/upload/images/20160927_214153.jpg',0,'蒜香薯仔和牛粒','','Poato & Cubed Wagyu Beef with Garic','',148,1,0,'2016-12-22 11:11:29','2016-12-22 11:11:29'),(186,'',11,'/upload/images/IMG_4885.jpg',0,'砵酒脆桶蠔','','Deep-fried Mached Oysters with Port Wine Sauce','',168,1,0,'2016-12-22 11:11:10','2016-12-22 11:11:10'),(184,'',1,'/upload/images/20160928_145824.jpg',0,'脆皮豬手','','Crispy Pork Knuckles with Sour Sticy Sauce','',148,1,0,'2016-12-22 11:11:22','2016-12-22 11:11:22'),(185,'',8,'/upload/images/20160928_145824.jpg',0,'脆皮豬手','','Crispy Pork Knuckles with Sour Sticy Sauce','',148,1,1,'2016-12-22 11:11:16','2016-12-22 11:11:16'),(187,'',13,'/upload/images/IMG_4940.JPG',0,'下龍灣炒米','','Fried Rice Noodles in Vietnam Style','',88,1,0,'2016-12-22 11:11:03','2016-12-22 11:11:03'),(188,'',10,'/upload/images/IMG_4805.JPG',0,'濃湯野菌泡鮮雞','','Shredder Chicken & Assorted Mushroom with Soup','',108,1,0,'2016-12-22 11:10:57','2016-12-22 11:10:57'),(189,'',12,'/upload/images/IMG_4800.JPG',0,'梅菜豬油渣蒸豆腐','','Steamed Tofu with Crisp Pork & Pickled Mustard','',88,1,0,'2016-12-22 11:10:50','2016-12-22 11:10:50'),(197,'',10,'/upload/images/222.jpg',0,'霸皇七品雞(半隻)','','Chicken with Ginger & Scallion(Half)','',188,1,0,'2016-12-22 11:10:15','2016-12-22 11:10:15'),(191,'',12,'/upload/images/20160930_142524.jpg',0,'豉汁帶子蒸豆腐','','Steamed Tofu with Scallop & Black Bean Sauce','',148,1,0,'2016-12-22 11:10:45','2016-12-22 11:10:45'),(192,'',58,'/upload/images/20160927_211257.jpg',0,'鮮貝蛋豆撈','',' Steamed Egg With Clam','',148,1,0,'2017-01-02 08:29:59','2017-01-02 00:29:59'),(193,'',55,'/upload/images/DSC01273.jpg',0,'綠茶柚子脆斑塊','','Stir-fried Fillet Garoupa with Green Tea & Honey-Citron Sauce','',128,1,0,'2016-12-30 10:45:25','2016-12-30 02:45:25'),(195,'',13,'/upload/images/20161004_130306.jpg',0,'自選生滾海鮮粥(時價)','','Optional Seafood Congee(Seasonal Price)','',0,1,0,'2016-12-22 11:10:26','2016-12-22 11:10:26'),(196,'',6,'/upload/images/20161004_130408.jpg',0,'各類海鮮滾湯','','Boiled Seafood Soup','',0,1,12,'2017-01-16 12:18:59','2017-01-16 04:18:59'),(198,'',55,'/upload/images/IMG-20161021-WA0020.jpg',0,'蜜餞風鱔','','Crispy eel with Honey Sauce','',188,1,0,'2016-12-30 10:45:39','2016-12-30 02:45:39'),(234,'',56,'/upload/images/小碼頭炒飯7.jpg',1,'小碼頭炒飯','','','',98,1,1,'2017-01-09 10:50:27','2017-01-09 02:50:27'),(216,'',60,'/upload/images/amd-civilizationVI-key-art-game-detail-9642.jpg',0,'海皇雜菜煲','菜式以較少脂肪或油分,鹽分及糖分烹調或製作,符合[3少之選]的要求','Seafood & Mixed Vegetable in Casserole','The dish nas less fat or oil, salt and sugar,meeting the[3 less]requirement',128,1,0,'2017-01-03 10:58:37','2017-01-03 10:58:37'),(238,'',56,'/upload/images/DSC00683.jpg',1,'濱紛紅酒雪梨經典牛扒','','','',168,1,0,'2017-01-09 02:57:06','2017-01-09 02:57:06'),(239,'',56,'/upload/images/DSC00710.jpg',1,'嘩娃搖擺雞','','','',188,1,0,'2017-01-09 02:58:38','2017-01-09 02:58:38');
/*!40000 ALTER TABLE `saiwan_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_items_old`
--

DROP TABLE IF EXISTS `saiwan_items_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_items_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pos_id` varchar(11) NOT NULL,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `img` varchar(200) NOT NULL,
  `name_chin` varchar(200) NOT NULL,
  `desc_chin` varchar(200) NOT NULL,
  `name_eng` varchar(200) NOT NULL,
  `desc_eng` varchar(200) NOT NULL,
  `price` int(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `sort` int(11) NOT NULL,
  `create_time` date NOT NULL,
  `update_time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_items_old`
--

LOCK TABLES `saiwan_items_old` WRITE;
/*!40000 ALTER TABLE `saiwan_items_old` DISABLE KEYS */;
INSERT INTO `saiwan_items_old` (`id`, `pos_id`, `cat_id`, `img`, `name_chin`, `desc_chin`, `name_eng`, `desc_eng`, `price`, `status`, `sort`, `create_time`, `update_time`) VALUES (1,'0',2,'/img/abc.png','中文名稱1','item1_desc','','',10,1,1,'2016-07-25','2016-07-25'),(2,'0',2,'/img/abc.png','item2','item2_desc','','',20,1,2,'2016-07-25','2016-07-25'),(3,'0',6,'/img/abc.png','item3','item3_desc','','',30,1,3,'2016-07-25','2016-07-25'),(4,'0',7,'/img/abc.png','item4','item4_desc','','',40,1,4,'2016-07-25','2016-07-25'),(5,'0',3,'/img/abc.png','SubCat3 Item','cat3_desc','','',50,1,5,'2016-07-25','2016-07-25'),(6,'5491',2,'/img/DSC01150.png','冰鎮胡麻醬芥蘭','','','',68,1,0,'0000-00-00','0000-00-00'),(7,'2589',2,'/img/abc.png','西班牙黑毛豬火腿片','','','',148,0,0,'0000-00-00','0000-00-00'),(8,'5614',2,'/img/DSC_0117.png','芝士粒粒','','','',78,0,0,'0000-00-00','0000-00-00'),(9,'5611',2,'/img/abc.png','洋蔥炸薯蕃茄沙','','','',68,0,0,'0000-00-00','0000-00-00'),(10,'5609',2,'/img/DSC00759.png','淚汪汪棒棒雞','','','',58,0,0,'0000-00-00','0000-00-00'),(11,'5307',2,'/img/DSC00773.png','晾衣白肉','','','',68,0,0,'0000-00-00','0000-00-00'),(12,'5301',2,'/img/DSC00763.png','黃金沙豆腐','','','',68,0,0,'0000-00-00','0000-00-00'),(13,'5610',2,'/img/DSC01093.png','話梅秋葵','','','',68,0,0,'0000-00-00','0000-00-00'),(14,'2552',2,'/img/abc.png','話梅涼瓜','','','',68,0,0,'0000-00-00','0000-00-00'),(15,'5612',2,'/img/DSC00961.png','鮮帶子芝士沙拉菜','','','',98,0,0,'0000-00-00','0000-00-00'),(16,'5613',2,'/img/DSC00965.png','鮮蝦胡麻芝士沙拉菜','','','',98,0,0,'0000-00-00','0000-00-00'),(17,'5432',3,'/img/DSC00957.png','(位)廚師(有營)靚湯','','','',38,0,0,'0000-00-00','0000-00-00'),(18,'5316',3,'/img/DSC00955.png','(例)廚師(有營)靚湯','','','',138,0,0,'0000-00-00','0000-00-00'),(19,'166',3,'/img/abc.png','海皇白玉冬瓜盅','','','',168,0,0,'0000-00-00','0000-00-00'),(20,' ',17,'/img/DSC00884.png','1664啤','','1664','',28,0,0,'0000-00-00','0000-00-00'),(21,' ',17,'/img/DSC00879.png','1664啤(花香味)','','1664Blang','',34,0,0,'0000-00-00','0000-00-00'),(22,'',17,'/img/DSC00869.png','生力啤','','San Miguel','',42,0,0,'0000-00-00','0000-00-00'),(23,'',17,'/img/DSC00879.png','青島啤','','TsingTao','',42,0,0,'0000-00-00','0000-00-00'),(24,'',17,'/img/DSC00874.png','健力士啤','','Guinness Stout','',48,0,0,'0000-00-00','0000-00-00'),(25,'',17,'/img/DSC00889.png','細藍妹啤','','Small Blue Girl','',42,0,0,'0000-00-00','0000-00-00'),(26,'',17,'/img/DSC00866.png','喜力啤','','Heineken','',42,0,0,'0000-00-00','0000-00-00'),(27,'',17,'/img/DSC00872.png','朝日啤','','Asahi','',42,0,0,'0000-00-00','0000-00-00'),(28,'',17,'/img/DSC00867.png','嘉士伯啤','','Carisberg','',42,0,0,'0000-00-00','0000-00-00'),(29,'',17,'/img/DSC00878.png','藍妹啤','','Blue Girl','',42,0,0,'0000-00-00','0000-00-00'),(30,'8141',20,'/img/DSC00944.png','餐白酒','','House Red Wine','',78,0,0,'0000-00-00','0000-00-00'),(31,'8142',20,'/img/DSC00948.png','餐紅酒','','House White Wine','',78,0,0,'0000-00-00','0000-00-00'),(32,'8125',21,'/img/DSC00622.png','(A)Place de La Comedie Sauvignon 2012','','(A)Place de La Comedie Sauvignon 2012','',288,0,0,'0000-00-00','0000-00-00'),(33,'8128',21,'/img/abc.png','(D)胡安白酒','','(D)Vina San Juan Blanco','',288,0,0,'0000-00-00','0000-00-00'),(34,'8132',21,'/img/abc.png','(H)卡迪亞白酒','','(H)Carta Vieja Merlot White Wine','',328,0,0,'0000-00-00','0000-00-00'),(35,'8133',21,'/img/abc.png','(I)薩維尼2011','','(I)Savigny Les-beaune 2011','',488,0,0,'0000-00-00','0000-00-00'),(36,'8134',21,'/img/abc.png','(J)Paso del Sol','','(J)Paso del Sol','',288,0,0,'0000-00-00','0000-00-00'),(37,'8135',21,'/img/abc.png','(K)Vinsobres','','(K)Vinsobres','',388,0,0,'0000-00-00','0000-00-00'),(38,'8126',22,'/img/DSC00610.png','(B)Place de La Comedie Merlot 2013','','(B)Place de La Comedie Merlot 2013','',288,0,0,'0000-00-00','0000-00-00'),(39,'8127',22,'/img/DSC00644.png','(C)Nexus Crizana 2009','','(C)Nexus Crizana 2009','',488,0,0,'0000-00-00','0000-00-00'),(40,'8129',22,'/img/DSC00852.png','(E)拉新度珍藏','','(E)Licenciado Reserva','',698,0,0,'0000-00-00','0000-00-00'),(41,'8130',22,'/img/DSC00638.png','(F)蒙泰堡','','(F)Chateau Montaigne','',388,0,0,'0000-00-00','0000-00-00'),(42,'8131',22,'/img/abc.png','(G)卡迪亞紅酒','','(G)Carta Vieja Merlot Red Wine','',328,0,0,'0000-00-00','0000-00-00'),(43,'8138',23,'/img/DSC00670.png','Hello kitty香檳','','','',588,0,0,'0000-00-00','0000-00-00'),(44,'',19,'/img/abc.png','Cordon Blue','','Cordon Blue','',0,0,0,'0000-00-00','0000-00-00'),(45,'',19,'/img/DSC00652.png','Hennesy XO','','Hennesy XO','',0,0,0,'0000-00-00','0000-00-00'),(46,'',19,'/img/abc.png','Whisky','','Whisky','',0,0,0,'0000-00-00','0000-00-00'),(47,'',19,'/img/DSC00664.png','十年紹興酒(加飯)','','','',0,0,0,'0000-00-00','0000-00-00'),(48,'',19,'/img/DSC00669.png','大呤釀','','','',0,1,0,'0000-00-00','0000-00-00'),(49,'',19,'/img/DSC00663.png','北京二鍋頭白酒','','','',0,0,0,'0000-00-00','0000-00-00'),(50,'',19,'/img/DSC00662.png','玉山八年陳高','','','',0,0,0,'0000-00-00','0000-00-00'),(51,'',19,'/img/abc.png','男山尾張清酒(壺)','','','',0,0,0,'0000-00-00','0000-00-00'),(52,'',19,'/img/DSC00667.png','男山尾張清酒(支)','','','',0,0,0,'0000-00-00','0000-00-00'),(53,'',19,'/img/DSC00653.png','茅台鎮小瓶酒','','','',0,0,0,'0000-00-00','0000-00-00'),(54,'',19,'/img/DSC00661.png','皖酒王','','','',0,0,0,'0000-00-00','0000-00-00'),(55,'',19,'/img/DSC00659.png','瀘州老窖','','','',0,0,0,'0000-00-00','0000-00-00');
/*!40000 ALTER TABLE `saiwan_items_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_logos`
--

DROP TABLE IF EXISTS `saiwan_logos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_logos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_logos`
--

LOCK TABLES `saiwan_logos` WRITE;
/*!40000 ALTER TABLE `saiwan_logos` DISABLE KEYS */;
INSERT INTO `saiwan_logos` (`id`, `img`) VALUES (1,'/img/logo.jpg');
/*!40000 ALTER TABLE `saiwan_logos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_termassigned`
--

DROP TABLE IF EXISTS `saiwan_termassigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_termassigned` (
  `id` int(11) NOT NULL,
  `term_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_termassigned`
--

LOCK TABLES `saiwan_termassigned` WRITE;
/*!40000 ALTER TABLE `saiwan_termassigned` DISABLE KEYS */;
INSERT INTO `saiwan_termassigned` (`id`, `term_id`, `cat_id`) VALUES (0,1,0);
/*!40000 ALTER TABLE `saiwan_termassigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_termpopup`
--

DROP TABLE IF EXISTS `saiwan_termpopup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_termpopup` (
  `id` int(11) NOT NULL,
  `is_popup` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_termpopup`
--

LOCK TABLES `saiwan_termpopup` WRITE;
/*!40000 ALTER TABLE `saiwan_termpopup` DISABLE KEYS */;
INSERT INTO `saiwan_termpopup` (`id`, `is_popup`) VALUES (0,1);
/*!40000 ALTER TABLE `saiwan_termpopup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_terms`
--

DROP TABLE IF EXISTS `saiwan_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_terms` (
  `id` int(11) NOT NULL,
  `text_chin` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `text_eng` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `show_at_bottom` int(1) NOT NULL,
  `show_at_popup` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_terms`
--

LOCK TABLES `saiwan_terms` WRITE;
/*!40000 ALTER TABLE `saiwan_terms` DISABLE KEYS */;
INSERT INTO `saiwan_terms` (`id`, `text_chin`, `text_eng`, `show_at_bottom`, `show_at_popup`, `created_at`, `updated_at`) VALUES (1,'本店烹調時不加味精','NO M.S.G While Cooking',0,0,'2016-08-29 06:10:25','2016-08-31 02:13:09'),(2,'圖片只供參考','Photos For Referce Only',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00'),(3,'所有海鮮一律時價','All Seafood are Seasonal Price',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00'),(4,'開瓶費(每支) $100','$100 for Corkage (per bottle)',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00'),(5,'茶/ 熱水 (每位) $10','$10 For Sauce Charge (per person)',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00'),(6,'外賣盒及膠袋每套 $1','Take away box and plastic bag $1/set',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00'),(7,'本店不設自來加工','No process food bring from guests',0,0,'2016-08-25 05:52:42','2016-12-19 23:36:04'),(8,'客人如有店內飲用或進食外來食品或食物, 本店將收取飲品每杯 $50, 食品每碟 $100','If guests enjoy outside food and drinks will be charged $50/cup for drinks and $100/dish for food',0,0,'2016-08-25 05:52:42','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `saiwan_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saiwan_users`
--

DROP TABLE IF EXISTS `saiwan_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saiwan_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` int(1) NOT NULL DEFAULT '1',
  `remember_token` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saiwan_users`
--

LOCK TABLES `saiwan_users` WRITE;
/*!40000 ALTER TABLE `saiwan_users` DISABLE KEYS */;
INSERT INTO `saiwan_users` (`id`, `username`, `password`, `name`, `email`, `created_at`, `updated_at`, `active`, `remember_token`) VALUES (1,'admin','$2y$10$8/DWesEDVteF1RnuEIYdc..Sdhx5tSRp3vss8ebpRWL53gcf3Ddvq','Siyana','siyana@appone.hk','2016-09-02 07:33:58','2016-09-01 23:33:58',1,'b1hwfM8wgu3VL3Uf100DPUuXwm2NeH49ZGAUABuGoTfq11QM9YdU44qtKgqG'),(5,'cyrus','$2y$10$YImJTZTi/7ENIvSAmkzGM.YQTJgi7N3ofOr12fpIBS4JPZ6byTFNi','Cyrus','cyrus@appone.hk','2016-12-19 03:22:56','2016-07-08 09:31:34',1,'3nV8Ob509SfzkrHvOr8OJLUxZ2n3zRSO6lMrXXbAH1uLVCxrbCWTxmtnquvm'),(24,'billy','$2y$10$eyF8zzQYEZ4DoQbVese.we0s6QRsx/stIgD3AABJmnm1dMnTPiW.y','Billy','billy@appone.hk','2016-07-12 09:15:36','2016-07-12 09:15:36',1,''),(25,'edward','$2y$10$ziFCsqAaq/ulI31qBzd15eCSyUFZDwcPMZFLIHMAmPI/W86gZBW8m','Edward','edward@appone.hk','2016-08-12 03:41:00','2016-08-12 03:41:00',1,''),(26,'admin','$2y$10$iG.E/BylL2EPZ6l7yrc07umrSv/8S9eobfr.V4eLkiyPGcRxKVjnW','admin','admin@appone.hk','2016-08-12 09:16:28','2016-08-12 09:16:28',1,''),(27,NULL,'$2y$10$sbjW0zgRSBQNGKh/PWfHZ.CZjQ4.qRf/YNgNn9mzRcE3ykVn6SRge','admin','info@appone.hk','2016-09-01 01:06:14','2016-09-01 01:06:14',1,''),(28,NULL,'$2y$10$zx0vItWbelAhOYk6wz3sdu4uQ9ozADV5ud.1q8ZsuhMfB1szR.Jhu',NULL,'vicor','2016-09-07 22:38:38','2016-09-07 22:38:38',1,''),(29,NULL,'$2y$10$A6cYQk0Du5Cb5a32nwjXe.L7uoJi7Vu2xaOO28suNjU01MxEacxMC',NULL,'victor','2016-09-07 23:08:36','2016-09-07 23:08:36',1,''),(30,NULL,'$2y$10$YLAtqD/GR08R6dmwbzUdYeLqL4CMbyhdZ32wSWYjMy.73XH5RRhhq',NULL,'victor@gmail.com','2016-09-07 23:09:12','2016-09-07 23:09:12',1,'');
/*!40000 ALTER TABLE `saiwan_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_client'
--

--
-- Dumping routines for database 'apponehk_client'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:11
