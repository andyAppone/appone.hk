-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_adwifi
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_cmsuser`
--

DROP TABLE IF EXISTS `tb_cmsuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_cmsuser` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(45) DEFAULT NULL,
  `hashpass` varchar(512) DEFAULT NULL,
  `email` varchar(128) DEFAULT NULL,
  `firstname` varchar(64) DEFAULT NULL,
  `lastname` varchar(64) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL,
  `updatedate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cmsuser`
--

LOCK TABLES `tb_cmsuser` WRITE;
/*!40000 ALTER TABLE `tb_cmsuser` DISABLE KEYS */;
INSERT INTO `tb_cmsuser` (`id`, `login`, `hashpass`, `email`, `firstname`, `lastname`, `active`, `createdate`, `updatedate`) VALUES (2,'testing','dc724af18fbdd4e59189f5fe768a5f8311527050','ray.lam@edeas.hk','Sarah','Fung',1,'2015-08-19 18:19:00','2015-08-19 18:20:00'),(5,'testThree','f21730624151b97ea2f17e292e305649fff6513d',NULL,NULL,NULL,NULL,NULL,NULL),(6,'testfour','b2ee60370ad57d9bc3877e9024c507ab99303a64',NULL,NULL,NULL,NULL,NULL,NULL),(7,'testFive','74b6e03975602439931f5c6117d7d53441984927',NULL,NULL,NULL,1,NULL,NULL);
/*!40000 ALTER TABLE `tb_cmsuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_adwifi'
--

--
-- Dumping routines for database 'apponehk_adwifi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:08
