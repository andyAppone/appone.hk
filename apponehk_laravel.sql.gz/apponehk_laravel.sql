-- MySQL dump 10.13  Distrib 5.6.35, for Linux (x86_64)
--
-- Host: localhost    Database: apponehk_laravel
-- ------------------------------------------------------
-- Server version	5.6.35-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `la_categories`
--

DROP TABLE IF EXISTS `la_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `la_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `parent_cat_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `la_categories`
--

LOCK TABLES `la_categories` WRITE;
/*!40000 ALTER TABLE `la_categories` DISABLE KEYS */;
INSERT INTO `la_categories` (`id`, `name`, `parent_cat_id`, `created_at`, `updated_at`) VALUES (1,'ABC',0,'2016-08-11 00:50:31','2016-08-11 00:50:31');
/*!40000 ALTER TABLE `la_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `la_items`
--

DROP TABLE IF EXISTS `la_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `la_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `la_items`
--

LOCK TABLES `la_items` WRITE;
/*!40000 ALTER TABLE `la_items` DISABLE KEYS */;
INSERT INTO `la_items` (`id`, `name`, `category_id`, `created_at`, `updated_at`) VALUES (1,'Item test',1,'2016-08-11 21:38:09','2016-08-11 21:38:09');
/*!40000 ALTER TABLE `la_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `la_users`
--

DROP TABLE IF EXISTS `la_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `la_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(64) NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `role_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `remember_token` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `la_users`
--

LOCK TABLES `la_users` WRITE;
/*!40000 ALTER TABLE `la_users` DISABLE KEYS */;
INSERT INTO `la_users` (`id`, `password`, `name`, `email`, `active`, `role_id`, `created_at`, `updated_at`, `remember_token`) VALUES (1,'$2y$10$CUr5yC1pfsWzbEIuazIh1uGGPv5ccwH1swBvYH2BfFB4iS4fOp0ai','Siyana','siyana@appone.hk',1,0,'2016-08-10 00:23:37','2016-08-10 00:23:37',''),(2,'$2y$10$ziFCsqAaq/ulI31qBzd15eCSyUFZDwcPMZFLIHMAmPI/W86gZBW8m','Edward','edward@appone.hk',1,0,'2016-08-11 19:38:40','2016-08-11 19:38:40','');
/*!40000 ALTER TABLE `la_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'apponehk_laravel'
--

--
-- Dumping routines for database 'apponehk_laravel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-09 17:08:16
